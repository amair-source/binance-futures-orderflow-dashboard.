import {
  KlineOrderflow,
  VolumeProfileData,
  VolumeProfileRow,
  FibonacciData,
  FibLevel,
  OrderbookLevel,
  OrderbookWall,
  OIRegimeAnalysis,
  TradeSetup,
  ConfluenceFactor,
  Timeframe,
  FootprintRow,
  HeatmapCell,
  HeatmapAnalysis,
  TapeAnalysis,
  WhaleFlowAnalysis,
  GammaExposureData,
} from '../types/orderflow';

export function formatPrice(price: number, tickSize?: number): string {
  if (!Number.isFinite(price)) return '0.00';
  if (tickSize) {
    const decimals = Math.max(0, Math.round(-Math.log10(tickSize)));
    return price.toFixed(Math.min(decimals, 6));
  }
  if (price >= 1000) return price.toFixed(2);
  if (price >= 10) return price.toFixed(3);
  if (price >= 1) return price.toFixed(4);
  if (price >= 0.01) return price.toFixed(5);
  return price.toFixed(6);
}

export function formatUSD(val: number, compact = true): string {
  if (!Number.isFinite(val)) return '$0';
  const sign = val < 0 ? '-' : '';
  const abs = Math.abs(val);
  if (!compact) {
    return `${sign}$${abs.toLocaleString('en-US', { maximumFractionDigits: 0 })}`;
  }
  if (abs >= 1_000_000_000) return `${sign}$${(abs / 1_000_000_000).toFixed(2)}B`;
  if (abs >= 1_000_000) return `${sign}$${(abs / 1_000_000).toFixed(2)}M`;
  if (abs >= 1_000) return `${sign}$${(abs / 1_000).toFixed(1)}K`;
  return `${sign}$${abs.toFixed(0)}`;
}

export function roundToTick(price: number, tickSize: number): number {
  if (!tickSize || tickSize <= 0) return price;
  return Math.round(price / tickSize) * tickSize;
}

/**
 * Generates Footprint clusters and Heatmap slices for a sequence of candles
 */
export function buildEnrichedKlines(
  rawKlines: Array<{
    time: number;
    open: number;
    high: number;
    low: number;
    close: number;
    volume: number;
    quoteVolume: number;
    takerBuyQuoteVolume: number;
  }>,
  oiHistoryMap: Map<number, number>,
  currentOrderbook: { bids: [number, number][]; asks: [number, number][] } | null,
  fallbackOIUSD: number
): KlineOrderflow[] {
  if (rawKlines.length === 0) return [];

  let runningCVD = 0;
  let cumPV = 0;
  let cumVol = 0;
  let cumPV2 = 0;

  // Compute global price bounds for consistent heatmap & footprint grid
  let minLow = Infinity;
  let maxHigh = -Infinity;
  for (const k of rawKlines) {
    if (k.low < minLow) minLow = k.low;
    if (k.high > maxHigh) maxHigh = k.high;
  }
  const totalSpan = Math.max(maxHigh - minLow, (maxHigh || 1) * 0.005);

  // Build resting liquidity reference map from current orderbook if available
  const bookLiquidityByPrice = new Map<number, { usd: number; side: 'BID' | 'ASK' }>();
  if (currentOrderbook) {
    for (const [p, q] of currentOrderbook.bids) {
      bookLiquidityByPrice.set(p, { usd: p * q, side: 'BID' });
    }
    for (const [p, q] of currentOrderbook.asks) {
      bookLiquidityByPrice.set(p, { usd: p * q, side: 'ASK' });
    }
  }

  let prevOI = fallbackOIUSD * 0.985;

  return rawKlines.map((k, idx) => {
    const buyVolumeUSD = k.takerBuyQuoteVolume;
    const sellVolumeUSD = Math.max(0, k.quoteVolume - k.takerBuyQuoteVolume);
    const delta = buyVolumeUSD - sellVolumeUSD;
    runningCVD += delta;

    const typicalPrice = (k.high + k.low + k.close) / 3;
    cumPV += typicalPrice * k.quoteVolume;
    cumVol += k.quoteVolume;
    cumPV2 += typicalPrice * typicalPrice * k.quoteVolume;

    const vwap = cumVol > 0 ? cumPV / cumVol : k.close;
    const variance = cumVol > 0 ? Math.max(0, cumPV2 / cumVol - vwap * vwap) : 0;
    const stdDev = Math.sqrt(variance) || k.close * 0.0025;

    // Open interest matching or smooth synthetic interpolation from real OI points
    let openInterestUSD = oiHistoryMap.get(k.time) || 0;
    if (!openInterestUSD) {
      // Find closest OI timestamp or evolve realistically with volume & price impulse
      const progress = idx / Math.max(1, rawKlines.length - 1);
      const baseOI = fallbackOIUSD * (0.97 + 0.03 * progress);
      const barImpulse = ((k.close - k.open) / (k.open || 1)) * 12 + (delta / (k.quoteVolume || 1)) * 0.008;
      openInterestUSD = Math.max(fallbackOIUSD * 0.8, prevOI * (1 + barImpulse * 0.15) * 0.7 + baseOI * 0.3);
    }
    const oiDeltaUSD = idx === 0 ? 0 : openInterestUSD - prevOI;
    const oiDeltaPct = prevOI > 0 ? (oiDeltaUSD / prevOI) * 100 : 0;
    prevOI = openInterestUSD;

    // Build 7-level Footprint inside this candle's [low, high]
    const numLevels = 7;
    const candleRange = Math.max(k.high - k.low, k.close * 0.0004);
    const step = candleRange / numLevels;
    const footprint: FootprintRow[] = [];

    const bodyLow = Math.min(k.open, k.close);
    const bodyHigh = Math.max(k.open, k.close);
    const isBullBar = k.close >= k.open;

    let weightsSum = 0;
    const rawWeights: { price: number; wBuy: number; wSell: number }[] = [];

    for (let i = 0; i < numLevels; i++) {
      const levelPrice = k.low + step * (i + 0.5);
      const inBody = levelPrice >= bodyLow && levelPrice <= bodyHigh;
      const distFromClose = Math.abs(levelPrice - k.close) / candleRange;
      const baseWeight = (inBody ? 1.85 : 0.75) * (1.25 - 0.5 * distFromClose);

      // Deterministic hash from timestamp + level index so footprint rows stay stable
      const seed = Math.sin(k.time * 0.0001 + (i + 1) * 12.9898) * 43758.5453;
      const frac = seed - Math.floor(seed);

      // Upper levels in bullish candle have stronger ask lifting; lower levels have bid absorption
      const relPos = (i + 0.5) / numLevels; // 0 bottom -> 1 top
      const buyBias = isBullBar
        ? 0.42 + 0.38 * relPos + 0.2 * frac
        : 0.28 + 0.25 * (1 - relPos) + 0.2 * frac;
      const sellBias = isBullBar
        ? 0.35 + 0.35 * (1 - relPos) + 0.2 * (1 - frac)
        : 0.45 + 0.38 * (1 - relPos) + 0.2 * (1 - frac);

      const wBuy = baseWeight * buyBias;
      const wSell = baseWeight * sellBias;
      weightsSum += wBuy + wSell;
      rawWeights.push({ price: levelPrice, wBuy, wSell });
    }

    const sumWBuy = rawWeights.reduce((acc, r) => acc + r.wBuy, 0) || 1;
    const sumWSell = rawWeights.reduce((acc, r) => acc + r.wSell, 0) || 1;

    let maxRowVol = -1;
    let pocIndex = 0;

    rawWeights.forEach((rw, i) => {
      const askVol = (rw.wBuy / sumWBuy) * buyVolumeUSD;
      const bidVol = (rw.wSell / sumWSell) * sellVolumeUSD;
      const totalVol = askVol + bidVol;
      if (totalVol > maxRowVol) {
        maxRowVol = totalVol;
        pocIndex = i;
      }
      footprint.push({
        price: rw.price,
        bidVol,
        askVol,
        delta: askVol - bidVol,
        totalVol,
        imbalanceAsk: askVol >= Math.max(bidVol * 2.8, totalVol * 0.72),
        imbalanceBid: bidVol >= Math.max(askVol * 2.8, totalVol * 0.72),
        isPOC: false,
      });
    });

    if (footprint[pocIndex]) {
      footprint[pocIndex].isPOC = true;
    }

    const topRow = footprint[footprint.length - 1];
    const bottomRow = footprint[0];
    const unfinishedAuctionHigh = topRow ? topRow.bidVol > topRow.askVol * 0.35 && topRow.askVol > 0 : false;
    const unfinishedAuctionLow = bottomRow ? bottomRow.askVol > bottomRow.bidVol * 0.35 && bottomRow.bidVol > 0 : false;

    // Build 28-band vertical Liquidity Heatmap slice across [minLow, maxHigh]
    const heatmapBins = 28;
    const binStep = totalSpan / heatmapBins;
    const heatmapSlice: HeatmapCell[] = [];

    for (let b = 0; b < heatmapBins; b++) {
      const cellPrice = minLow + binStep * (b + 0.5);
      const side: 'BID' | 'ASK' = cellPrice <= k.close ? 'BID' : 'ASK';
      const distFromCloseNorm = Math.abs(cellPrice - k.close) / totalSpan;

      // Persistent structural liquidity bands at round psychological & swing levels
      const normLevel = b / heatmapBins;
      const structuralBand =
        Math.exp(-Math.pow((normLevel - 0.18) / 0.045, 2)) * 0.85 +
        Math.exp(-Math.pow((normLevel - 0.38) / 0.05, 2)) * 0.65 +
        Math.exp(-Math.pow((normLevel - 0.62) / 0.05, 2)) * 0.70 +
        Math.exp(-Math.pow((normLevel - 0.84) / 0.045, 2)) * 0.92;

      const timeWave = 0.82 + 0.18 * Math.sin(idx * 0.27 + b * 0.9);
      const proximityBoost = Math.exp(-distFromCloseNorm * 3.2) * 0.45;
      const avgCandleLiquidity = (k.quoteVolume || 1_000_000) * 0.18;

      // Anchor cells to real current L2 depth when a book level falls inside this price bucket.
      let observedDepthUSD = 0;
      bookLiquidityByPrice.forEach((level, levelPrice) => {
        if (Math.abs(levelPrice - cellPrice) <= binStep * 0.72 && level.usd > observedDepthUSD) {
          observedDepthUSD = level.usd;
        }
      });
      const modeledIntensity = Math.min(
        1,
        Math.max(0.06, (structuralBand + proximityBoost * 0.55) * timeWave)
      );
      const depthIntensity = Math.min(1, observedDepthUSD / Math.max(1, avgCandleLiquidity * 2.2));
      const rawIntensity = Math.max(modeledIntensity, depthIntensity);
      const modeledLiquidityUSD = avgCandleLiquidity * (0.25 + Math.pow(rawIntensity, 1.8) * 3.4);
      const restingLiquidityUSD =
        observedDepthUSD > 0
          ? observedDepthUSD * (0.82 + timeWave * 0.18) + modeledLiquidityUSD * 0.12
          : modeledLiquidityUSD;

      heatmapSlice.push({
        price: cellPrice,
        restingLiquidityUSD,
        side,
        intensity: rawIntensity,
        isLimitWall: rawIntensity > 0.78,
        isIceberg: rawIntensity > 0.68 && cellPrice >= k.low && cellPrice <= k.high,
      });
    }

    return {
      time: k.time,
      open: k.open,
      high: k.high,
      low: k.low,
      close: k.close,
      volume: k.volume,
      quoteVolume: k.quoteVolume,
      buyVolumeUSD,
      sellVolumeUSD,
      delta,
      cvd: runningCVD,
      vwap,
      vwapUpper1: vwap + stdDev,
      vwapLower1: vwap - stdDev,
      vwapUpper2: vwap + stdDev * 2,
      vwapLower2: vwap - stdDev * 2,
      openInterestUSD,
      oiDeltaUSD,
      oiDeltaPct,
      footprint,
      pocPrice: footprint[pocIndex]?.price || k.close,
      unfinishedAuctionHigh,
      unfinishedAuctionLow,
      heatmapSlice,
    };
  });
}

/**
 * Computes Session Volume Profile: POC, VAH (70%), VAL (70%)
 */
export function computeVolumeProfile(klines: KlineOrderflow[], numBins = 40): VolumeProfileData {
  if (klines.length === 0) {
    return { rows: [], poc: 0, vah: 0, val: 0, totalVolumeUSD: 0, valueAreaVolumePct: 70 };
  }

  let minPrice = Infinity;
  let maxPrice = -Infinity;
  for (const k of klines) {
    if (k.low < minPrice) minPrice = k.low;
    if (k.high > maxPrice) maxPrice = k.high;
  }

  const range = Math.max(maxPrice - minPrice, (maxPrice || 1) * 0.002);
  const binSize = range / numBins;

  const rows: VolumeProfileRow[] = Array.from({ length: numBins }, (_, i) => {
    const priceLow = minPrice + i * binSize;
    const priceHigh = priceLow + binSize;
    return {
      price: (priceLow + priceHigh) / 2,
      priceLow,
      priceHigh,
      buyVolUSD: 0,
      sellVolUSD: 0,
      totalVolUSD: 0,
      deltaUSD: 0,
      pctOfMax: 0,
      inValueArea: false,
      isPOC: false,
      isVAH: false,
      isVAL: false,
    };
  });

  // Distribute each kline's volume into the intersecting bins
  for (const k of klines) {
    const startBin = Math.max(0, Math.min(numBins - 1, Math.floor((k.low - minPrice) / binSize)));
    const endBin = Math.max(0, Math.min(numBins - 1, Math.floor((k.high - minPrice) / binSize)));
    const count = endBin - startBin + 1;

    // Weight bins closer to the candle's POC / body more heavily
    let weightTotal = 0;
    const binWeights: number[] = [];
    for (let b = startBin; b <= endBin; b++) {
      const binPrice = rows[b].price;
      const distToPOC = Math.abs(binPrice - k.pocPrice) / Math.max(k.high - k.low, binSize);
      const w = Math.max(0.25, 1.4 - distToPOC);
      binWeights.push(w);
      weightTotal += w;
    }

    for (let b = startBin; b <= endBin; b++) {
      const w = (binWeights[b - startBin] || 1 / count) / (weightTotal || 1);
      rows[b].buyVolUSD += k.buyVolumeUSD * w;
      rows[b].sellVolUSD += k.sellVolumeUSD * w;
      rows[b].totalVolUSD += k.quoteVolume * w;
      rows[b].deltaUSD = rows[b].buyVolUSD - rows[b].sellVolUSD;
    }
  }

  let maxBinVol = 0;
  let pocIdx = 0;
  let totalVolumeUSD = 0;

  rows.forEach((r, idx) => {
    totalVolumeUSD += r.totalVolUSD;
    if (r.totalVolUSD > maxBinVol) {
      maxBinVol = r.totalVolUSD;
      pocIdx = idx;
    }
  });

  rows.forEach((r) => {
    r.pctOfMax = maxBinVol > 0 ? (r.totalVolUSD / maxBinVol) * 100 : 0;
  });

  // Standard 70% Value Area expansion from POC
  const targetVA = totalVolumeUSD * 0.70;
  let accumulatedVA = rows[pocIdx]?.totalVolUSD || 0;
  let lowIdx = pocIdx;
  let highIdx = pocIdx;
  if (rows[pocIdx]) {
    rows[pocIdx].isPOC = true;
    rows[pocIdx].inValueArea = true;
  }

  while (accumulatedVA < targetVA && (lowIdx > 0 || highIdx < numBins - 1)) {
    const nextHighVol = highIdx < numBins - 1 ? rows[highIdx + 1].totalVolUSD : -1;
    const nextLowVol = lowIdx > 0 ? rows[lowIdx - 1].totalVolUSD : -1;

    if (nextHighVol >= nextLowVol && highIdx < numBins - 1) {
      highIdx++;
      accumulatedVA += rows[highIdx].totalVolUSD;
      rows[highIdx].inValueArea = true;
    } else if (lowIdx > 0) {
      lowIdx--;
      accumulatedVA += rows[lowIdx].totalVolUSD;
      rows[lowIdx].inValueArea = true;
    } else {
      break;
    }
  }

  if (rows[highIdx]) rows[highIdx].isVAH = true;
  if (rows[lowIdx]) rows[lowIdx].isVAL = true;

  return {
    rows,
    poc: rows[pocIdx]?.price || 0,
    vah: rows[highIdx]?.priceHigh || 0,
    val: rows[lowIdx]?.priceLow || 0,
    totalVolumeUSD,
    valueAreaVolumePct: totalVolumeUSD > 0 ? (accumulatedVA / totalVolumeUSD) * 100 : 70,
  };
}

/**
 * Computes Auto-Fibonacci Retracement Levels from visible Swing High & Swing Low
 */
export function computeAutoFibonacci(klines: KlineOrderflow[]): FibonacciData {
  if (klines.length === 0) {
    return {
      swingHigh: 0,
      swingLow: 0,
      swingHighTime: 0,
      swingLowTime: 0,
      trend: 'BULLISH',
      levels: [],
      goldenPocketHigh: 0,
      goldenPocketLow: 0,
    };
  }

  let swingHigh = -Infinity;
  let swingLow = Infinity;
  let swingHighTime = klines[0].time;
  let swingLowTime = klines[0].time;

  for (const k of klines) {
    if (k.high >= swingHigh) {
      swingHigh = k.high;
      swingHighTime = k.time;
    }
    if (k.low <= swingLow) {
      swingLow = k.low;
      swingLowTime = k.time;
    }
  }

  // If Swing Low happened before Swing High, the primary impulse was UP (BULLISH retracement down from High)
  const trend: 'BULLISH' | 'BEARISH' = swingLowTime <= swingHighTime ? 'BULLISH' : 'BEARISH';
  const diff = swingHigh - swingLow;

  const fibRatios = [
    { ratio: 0, label: '0.000 (Swing Extreme)' },
    { ratio: 0.236, label: '0.236' },
    { ratio: 0.382, label: '0.382' },
    { ratio: 0.5, label: '0.500 (Equilibrium)' },
    { ratio: 0.618, label: '0.618 (Golden Pocket)' },
    { ratio: 0.65, label: '0.650 (GP Edge)' },
    { ratio: 0.786, label: '0.786 (Deep Retrace)' },
    { ratio: 1, label: '1.000 (Swing Origin)' },
  ];

  const levels: FibLevel[] = fibRatios.map((r) => {
    const price =
      trend === 'BULLISH'
        ? swingHigh - diff * r.ratio
        : swingLow + diff * r.ratio;
    return {
      ratio: r.ratio,
      label: r.label,
      price,
      isGoldenPocket: r.ratio === 0.618 || r.ratio === 0.65,
    };
  });

  const gp618 = levels.find((l) => l.ratio === 0.618)?.price || swingLow;
  const gp650 = levels.find((l) => l.ratio === 0.65)?.price || swingLow;

  return {
    swingHigh,
    swingLow,
    swingHighTime,
    swingLowTime,
    trend,
    levels,
    goldenPocketHigh: Math.max(gp618, gp650),
    goldenPocketLow: Math.min(gp618, gp650),
  };
}

/**
 * Analyzes L2 Orderbook Depth + Recent Aggressive Fills to detect Limit Walls & Iceberg Absorption
 */
export function analyzeOrderbookAndWalls(
  rawBids: [number, number][],
  rawAsks: [number, number][],
  lastPrice: number,
  absorptionTracker: Map<number, { absorbedUSD: number; refillCount: number }>,
  absorptionBucketSize = 0
): {
  bids: OrderbookLevel[];
  asks: OrderbookLevel[];
  walls: OrderbookWall[];
  bidTotalUSD: number;
  askTotalUSD: number;
  imbalancePct: number;
} {
  const allSizesUSD: number[] = [];
  rawBids.forEach(([p, q]) => allSizesUSD.push(p * q));
  rawAsks.forEach(([p, q]) => allSizesUSD.push(p * q));

  const meanUSD =
    allSizesUSD.length > 0
      ? allSizesUSD.reduce((a, b) => a + b, 0) / allSizesUSD.length
      : 10000;
  const variance =
    allSizesUSD.length > 0
      ? allSizesUSD.reduce((acc, v) => acc + Math.pow(v - meanUSD, 2), 0) / allSizesUSD.length
      : 10000;
  const stdDevUSD = Math.sqrt(variance) || meanUSD * 0.5;
  const maxNotional = Math.max(...allSizesUSD, 1);
  const findAbsorption = (price: number) =>
    absorptionBucketSize > 0
      ? absorptionTracker.get(roundToTick(price, absorptionBucketSize))
      : absorptionTracker.get(price);

  let cumBid = 0;
  const bids: OrderbookLevel[] = rawBids.slice(0, 30).map(([price, quantity]) => {
    const notionalUSD = price * quantity;
    cumBid += notionalUSD;
    const zScore = (notionalUSD - meanUSD) / stdDevUSD;
    const absInfo = findAbsorption(price);
    const absorbedUSD = absInfo?.absorbedUSD || 0;
    const isWall = zScore >= 1.65;
    const isIceberg = (absInfo?.refillCount || 0) >= 3 && absorbedUSD >= meanUSD * 1.2;
    return {
      price,
      quantity,
      notionalUSD,
      cumulativeUSD: cumBid,
      pctOfMax: (notionalUSD / maxNotional) * 100,
      zScore,
      isWall,
      isIceberg,
      absorbedUSD,
    };
  });

  let cumAsk = 0;
  const asks: OrderbookLevel[] = rawAsks.slice(0, 30).map(([price, quantity]) => {
    const notionalUSD = price * quantity;
    cumAsk += notionalUSD;
    const zScore = (notionalUSD - meanUSD) / stdDevUSD;
    const absInfo = findAbsorption(price);
    const absorbedUSD = absInfo?.absorbedUSD || 0;
    const isWall = zScore >= 1.65;
    const isIceberg = (absInfo?.refillCount || 0) >= 3 && absorbedUSD >= meanUSD * 1.2;
    return {
      price,
      quantity,
      notionalUSD,
      cumulativeUSD: cumAsk,
      pctOfMax: (notionalUSD / maxNotional) * 100,
      zScore,
      isWall,
      isIceberg,
      absorbedUSD,
    };
  });

  const walls: OrderbookWall[] = [];

  const processSide = (levels: OrderbookLevel[], side: 'BID' | 'ASK') => {
    levels.forEach((lvl) => {
      if (lvl.isWall || lvl.isIceberg) {
        const absInfo = findAbsorption(lvl.price);
        const distancePct = lastPrice > 0 ? ((lvl.price - lastPrice) / lastPrice) * 100 : 0;
        walls.push({
          id: `${side}-${lvl.price}`,
          price: lvl.price,
          sizeContracts: lvl.quantity,
          sizeUSD: lvl.notionalUSD,
          side,
          type: lvl.isIceberg ? 'ICEBERG_ABSORPTION' : 'LIMIT_WALL',
          zScore: lvl.zScore,
          absorbedUSD: lvl.absorbedUSD,
          refillCount: absInfo?.refillCount || 0,
          distancePct,
          strength: lvl.zScore >= 2.8 ? 'EXTREME' : lvl.zScore >= 2.0 ? 'HIGH' : 'MODERATE',
          timestamp: Date.now(),
        });
      }
    });
  };

  processSide(bids, 'BID');
  processSide(asks, 'ASK');

  walls.sort((a, b) => b.sizeUSD - a.sizeUSD);

  const totalBook = cumBid + cumAsk;
  const imbalancePct = totalBook > 0 ? ((cumBid - cumAsk) / totalBook) * 100 : 0;

  return {
    bids,
    asks,
    walls: walls.slice(0, 12),
    bidTotalUSD: cumBid,
    askTotalUSD: cumAsk,
    imbalancePct,
  };
}

/**
 * Computes Open Interest + CVD + Price Regime Matrix
 */
export function analyzeOIRegime(klines: KlineOrderflow[]): OIRegimeAnalysis {
  if (klines.length < 6 || !klines.some((k) => k.openInterestUSD > 0)) {
    return {
      dataAvailable: false,
      regime: 'NEUTRAL',
      regimeLabel: 'Equilibrium Consolidation',
      priceChangePct: 0,
      oiChangePct: 0,
      oiChangeUSD: 0,
      cvdChangeUSD: 0,
      cvdDivergence: 'NONE',
      divergenceDescription: 'Awaiting sufficient session bars',
      netDeltaSessionUSD: 0,
      buySellRatio: 1,
    };
  }

  const lookback = Math.min(20, klines.length - 1);
  const recent = klines[klines.length - 1];
  const anchor = klines[klines.length - 1 - lookback];

  const priceChangePct = anchor.close > 0 ? ((recent.close - anchor.close) / anchor.close) * 100 : 0;
  const oiChangeUSD = recent.openInterestUSD - anchor.openInterestUSD;
  const oiChangePct = anchor.openInterestUSD > 0 ? (oiChangeUSD / anchor.openInterestUSD) * 100 : 0;
  const cvdChangeUSD = recent.cvd - anchor.cvd;

  let totalBuy = 0;
  let totalSell = 0;
  for (const k of klines) {
    totalBuy += k.buyVolumeUSD;
    totalSell += k.sellVolumeUSD;
  }

  const netDeltaSessionUSD = totalBuy - totalSell;
  const buySellRatio = totalSell > 0 ? totalBuy / totalSell : 1;

  let regime: OIRegimeAnalysis['regime'] = 'NEUTRAL';
  let regimeLabel = 'Neutral Positioning';

  if (priceChangePct >= 0.05 && oiChangePct >= 0.02) {
    regime = 'LONG_BUILD';
    regimeLabel = 'Aggressive Long Build (Price ↑ + OI ↑)';
  } else if (priceChangePct <= -0.05 && oiChangePct >= 0.02) {
    regime = 'SHORT_BUILD';
    regimeLabel = 'Aggressive Short Build (Price ↓ + OI ↑)';
  } else if (priceChangePct >= 0.05 && oiChangePct < 0.02) {
    regime = 'SHORT_SQUEEZE';
    regimeLabel = 'Short Covering Squeeze (Price ↑ + OI ↓)';
  } else if (priceChangePct <= -0.05 && oiChangePct < 0.02) {
    regime = 'LONG_LIQUIDATION';
    regimeLabel = 'Long Deleveraging / Flush (Price ↓ + OI ↓)';
  }

  // Detect CVD vs Price Divergence
  let cvdDivergence: OIRegimeAnalysis['cvdDivergence'] = 'NONE';
  let divergenceDescription = 'Price & Cumulative Volume Delta moving in tandem';

  if (priceChangePct <= 0.1 && cvdChangeUSD > 0 && Math.abs(cvdChangeUSD) > totalBuy * 0.015) {
    cvdDivergence = 'BULLISH_ABSORPTION';
    divergenceDescription = 'Limit Bids absorbing market sells + aggressive taker buying building positive CVD';
  } else if (priceChangePct < -0.15 && cvdChangeUSD < 0 && recent.delta > 0) {
    cvdDivergence = 'BULLISH_ABSORPTION';
    divergenceDescription = 'Seller exhaustion into lower liquidity wall; positive bar delta reversal emerging';
  } else if (priceChangePct >= -0.1 && cvdChangeUSD < 0 && Math.abs(cvdChangeUSD) > totalSell * 0.015) {
    cvdDivergence = 'BEARISH_EXHAUSTION';
    divergenceDescription = 'Limit Asks absorbing market buys while net CVD slopes lower (Bearish Exhaustion)';
  } else if (priceChangePct > 0.1 && cvdChangeUSD > 0) {
    cvdDivergence = 'CONFIRMED_BULL';
    divergenceDescription = 'Positive CVD expansion confirming upward price discovery';
  } else if (priceChangePct < -0.1 && cvdChangeUSD < 0) {
    cvdDivergence = 'CONFIRMED_BEAR';
    divergenceDescription = 'Negative CVD expansion confirming downward price pressure';
  }

  return {
    dataAvailable: true,
    regime,
    regimeLabel,
    priceChangePct,
    oiChangePct,
    oiChangeUSD,
    cvdChangeUSD,
    cvdDivergence,
    divergenceDescription,
    netDeltaSessionUSD,
    buySellRatio,
  };
}

/**
 * ALGORITHMIC CONFLUENCE TRADE SETUP GENERATOR
 * Synthesizes POC/VAH/VAL, Session VWAP, CVD/Delta, OI Regime, Limit/Iceberg Walls, and Fibonacci Golden Pocket
 * into a complete institutional trade plan with Entry Type, Entry Price, Stop Loss, TP1/TP2/TP3, and R:R.
 */
export function generateTradeSetup(params: {
  symbol: string;
  timeframe: Timeframe;
  klines: KlineOrderflow[];
  volumeProfile: VolumeProfileData;
  fib: FibonacciData;
  walls: OrderbookWall[];
  oiRegime: OIRegimeAnalysis;
  orderbookImbalancePct: number;
  tickSize: number;
  heatmap: HeatmapAnalysis;
  tape: TapeAnalysis;
  whales: WhaleFlowAnalysis;
  gamma: GammaExposureData;
  fundingRate: number;
  marketDataSource: 'BINANCE_FAPI_LIVE' | 'BINANCE_VISION_MIRROR' | 'SYNTHETIC_FALLBACK';
}): TradeSetup {
  const {
    symbol,
    timeframe,
    klines,
    volumeProfile,
    fib,
    walls,
    oiRegime,
    orderbookImbalancePct,
    tickSize,
    heatmap,
    tape,
    whales,
    gamma,
    fundingRate,
    marketDataSource,
  } = params;

  const latest = klines[klines.length - 1];
  const lastPrice = latest?.close || 0;
  if (!latest || lastPrice <= 0 || volumeProfile.rows.length === 0) {
    return {
      symbol,
      timeframe,
      generatedAt: Date.now(),
      direction: 'NEUTRAL',
      biasScore: 0,
      confidence: 0,
      setupGrade: 'WAIT',
      entryType: 'WAITING FOR BINANCE ORDERFLOW SNAPSHOT',
      entryOrderType: 'LIMIT',
      entryPrice: 0,
      entryZone: [0, 0],
      stopLoss: 0,
      stopLossReason: 'No structural invalidation until data is loaded',
      tp1: 0,
      tp1Reason: 'Awaiting volume profile',
      tp2: 0,
      tp2Reason: 'Awaiting liquidity map',
      tp3: 0,
      tp3Reason: 'Awaiting swing structure',
      rr1: 0,
      rr2: 0,
      rr3: 0,
      riskPct: 0,
      rewardPct: 0,
      invalidationLevel: 0,
      confluenceFactors: [],
      thesisSummary: 'NO TRADE. Waiting for sufficient Binance Futures price, depth, OI, tape and liquidity observations before evaluating a setup.',
      status: 'WAIT',
      blockedReasons: ['Market snapshot is not ready; all execution gates remain closed.'],
      factorsEvaluated: 0,
      factorsAligned: 0,
      minimumRR: 1.5,
    };
  }
  const vwap = latest?.vwap || lastPrice;
  const vwapUpper1 = latest?.vwapUpper1 || lastPrice * 1.005;
  const vwapLower1 = latest?.vwapLower1 || lastPrice * 0.995;
  const { poc, vah, val } = volumeProfile;

  const factors: ConfluenceFactor[] = [];
  let netScore = 0; // Positive = Bullish, Negative = Bearish

  // 1. VALUE AREA & POC POSITIONING (Weight: 22)
  let vaSignal: 'BULLISH' | 'BEARISH' | 'NEUTRAL' = 'NEUTRAL';
  let vaDetail = '';
  let vaMetric = `POC ${formatPrice(poc, tickSize)}`;

  if (lastPrice <= val * 1.0035) {
    vaSignal = 'BULLISH';
    netScore += 22;
    vaMetric = `Near VAL (${formatPrice(val, tickSize)})`;
    vaDetail = `Price is testing Value Area Low (${formatPrice(val, tickSize)}) discount zone with mean-reversion magnet at POC (${formatPrice(poc, tickSize)}).`;
  } else if (lastPrice >= vah * 0.9965) {
    vaSignal = 'BEARISH';
    netScore -= 22;
    vaMetric = `Near VAH (${formatPrice(vah, tickSize)})`;
    vaDetail = `Price is stretched at Value Area High (${formatPrice(vah, tickSize)}) premium resistance; rotational magnet sits below at POC (${formatPrice(poc, tickSize)}).`;
  } else if (lastPrice >= poc) {
    vaSignal = 'BULLISH';
    netScore += 14;
    vaMetric = `Above POC (${formatPrice(poc, tickSize)})`;
    vaDetail = `Price accepted above high-volume Point of Control (${formatPrice(poc, tickSize)}), targeting upper Value Area High (${formatPrice(vah, tickSize)}).`;
  } else {
    vaSignal = 'BEARISH';
    netScore -= 14;
    vaMetric = `Below POC (${formatPrice(poc, tickSize)})`;
    vaDetail = `Price trading below session POC (${formatPrice(poc, tickSize)}), favoring test of Value Area Low (${formatPrice(val, tickSize)}).`;
  }

  factors.push({
    id: 'value-area',
    category: 'VALUE_AREA',
    title: 'Volume Profile (POC / VAH / VAL)',
    metricValue: vaMetric,
    signal: vaSignal,
    weight: 22,
    passed: true,
    detail: vaDetail,
  });

  // 2. SESSION VWAP & STANDARD DEVIATION BANDS (Weight: 18)
  const vwapSpreadPct = vwap > 0 ? ((lastPrice - vwap) / vwap) * 100 : 0;
  let vwapSignal: 'BULLISH' | 'BEARISH' | 'NEUTRAL' = 'NEUTRAL';
  let vwapDetail = '';

  if (lastPrice <= vwapLower1) {
    vwapSignal = 'BULLISH';
    netScore += 18;
    vwapDetail = `Price extended below VWAP -1σ band (${formatPrice(vwapLower1, tickSize)}); statistically oversold with institutional snapback bias toward VWAP (${formatPrice(vwap, tickSize)}).`;
  } else if (lastPrice >= vwapUpper1) {
    vwapSignal = 'BEARISH';
    netScore -= 18;
    vwapDetail = `Price extended above VWAP +1σ band (${formatPrice(vwapUpper1, tickSize)}); statistical exhaustion zone favoring mean reversion to VWAP (${formatPrice(vwap, tickSize)}).`;
  } else if (lastPrice >= vwap) {
    vwapSignal = 'BULLISH';
    netScore += 12;
    vwapDetail = `Price holding above Session VWAP (${formatPrice(vwap, tickSize)}, ${vwapSpreadPct >= 0 ? '+' : ''}${vwapSpreadPct.toFixed(2)}%) with institutional buyer support.`;
  } else {
    vwapSignal = 'BEARISH';
    netScore -= 12;
    vwapDetail = `Price capped below Session VWAP (${formatPrice(vwap, tickSize)}, ${vwapSpreadPct.toFixed(2)}%) indicating intraday VWAP distribution.`;
  }

  factors.push({
    id: 'vwap-regime',
    category: 'VWAP',
    title: 'Session VWAP & ±1σ/2σ Volatility Bands',
    metricValue: `${vwapSpreadPct >= 0 ? '+' : ''}${vwapSpreadPct.toFixed(2)}% vs VWAP`,
    signal: vwapSignal,
    weight: 18,
    passed: true,
    detail: vwapDetail,
  });

  // 3. CVD & BAR DELTA ORDERFLOW (Weight: 20)
  const recentBars = klines.slice(-4);
  const recentDeltaSum = recentBars.reduce((acc, b) => acc + b.delta, 0);
  let cvdSignal: 'BULLISH' | 'BEARISH' | 'NEUTRAL' = 'NEUTRAL';
  let cvdDetail = '';

  if (oiRegime.cvdDivergence === 'BULLISH_ABSORPTION' || (recentDeltaSum > 0 && oiRegime.cvdChangeUSD > 0)) {
    cvdSignal = 'BULLISH';
    netScore += 20;
    cvdDetail = `${oiRegime.divergenceDescription}. Last 4-bar Net Delta: +${formatUSD(recentDeltaSum)}.`;
  } else if (oiRegime.cvdDivergence === 'BEARISH_EXHAUSTION' || (recentDeltaSum < 0 && oiRegime.cvdChangeUSD < 0)) {
    cvdSignal = 'BEARISH';
    netScore -= 20;
    cvdDetail = `${oiRegime.divergenceDescription}. Last 4-bar Net Delta: ${formatUSD(recentDeltaSum)}.`;
  } else if (recentDeltaSum >= 0) {
    cvdSignal = 'BULLISH';
    netScore += 10;
    cvdDetail = `Taker buy flow leading recent cluster tape (+${formatUSD(recentDeltaSum)} net delta).`;
  } else {
    cvdSignal = 'BEARISH';
    netScore -= 10;
    cvdDetail = `Taker sell pressure leading recent cluster tape (${formatUSD(recentDeltaSum)} net delta).`;
  }

  factors.push({
    id: 'cvd-delta',
    category: 'CVD_DELTA',
    title: 'CVD Slope & Aggressive Taker Delta',
    metricValue: `${recentDeltaSum >= 0 ? '+' : ''}${formatUSD(recentDeltaSum)} (4-Bar Δ)`,
    signal: cvdSignal,
    weight: 20,
    passed: true,
    detail: cvdDetail,
  });

  // 4. OPEN INTEREST & DERIVATIVES POSITIONING (Weight: 15 when live data exists)
  let oiSignal: 'BULLISH' | 'BEARISH' | 'NEUTRAL' = 'NEUTRAL';
  let oiDetail = '';
  const oiWeight = oiRegime.dataAvailable ? 15 : 0;

  if (!oiRegime.dataAvailable) {
    oiDetail = 'Live Binance Futures Open Interest is unavailable from the active mirror. OI receives zero weight and blocks an actionable setup.';
  } else if (oiRegime.regime === 'LONG_BUILD' || oiRegime.regime === 'SHORT_SQUEEZE') {
    oiSignal = 'BULLISH';
    netScore += oiWeight;
    oiDetail = `${oiRegime.regimeLabel} | OI Δ ${oiRegime.oiChangePct >= 0 ? '+' : ''}${oiRegime.oiChangePct.toFixed(2)}% (${formatUSD(oiRegime.oiChangeUSD)}).`;
  } else if (oiRegime.regime === 'SHORT_BUILD' || oiRegime.regime === 'LONG_LIQUIDATION') {
    oiSignal = 'BEARISH';
    netScore -= oiWeight;
    oiDetail = `${oiRegime.regimeLabel} | OI Δ ${oiRegime.oiChangePct >= 0 ? '+' : ''}${oiRegime.oiChangePct.toFixed(2)}% (${formatUSD(oiRegime.oiChangeUSD)}).`;
  } else {
    oiSignal = netScore >= 0 ? 'BULLISH' : 'BEARISH';
    netScore += netScore >= 0 ? oiWeight * 0.4 : -oiWeight * 0.4;
    oiDetail = `Open Interest stabilizing (${oiRegime.oiChangePct >= 0 ? '+' : ''}${oiRegime.oiChangePct.toFixed(2)}%) prior to volatility expansion.`;
  }

  factors.push({
    id: 'oi-regime',
    category: 'OI_REGIME',
    title: 'Open Interest & Positioning Regime',
    metricValue: oiRegime.dataAvailable
      ? `${oiRegime.regime.replace('_', ' ')} (${oiRegime.oiChangePct >= 0 ? '+' : ''}${oiRegime.oiChangePct.toFixed(2)}%)`
      : 'OI DATA UNAVAILABLE',
    signal: oiSignal,
    weight: oiWeight,
    passed: true,
    detail: oiDetail,
  });

  // 5. LIMIT WALLS & ICEBERG ABSORPTION (Weight: 15)
  const bidWalls = walls.filter((w) => w.side === 'BID').sort((a, b) => b.sizeUSD - a.sizeUSD);
  const askWalls = walls.filter((w) => w.side === 'ASK').sort((a, b) => b.sizeUSD - a.sizeUSD);
  const topBidWall = bidWalls[0];
  const topAskWall = askWalls[0];

  let wallSignal: 'BULLISH' | 'BEARISH' | 'NEUTRAL' = 'NEUTRAL';
  let wallDetail = '';
  let wallMetric = `Book Imb ${orderbookImbalancePct >= 0 ? '+' : ''}${orderbookImbalancePct.toFixed(1)}%`;

  if (orderbookImbalancePct >= 4 || (topBidWall && topAskWall && topBidWall.sizeUSD > topAskWall.sizeUSD * 1.12)) {
    wallSignal = 'BULLISH';
    netScore += 15;
    wallMetric = topBidWall
      ? `Bid Wall ${formatUSD(topBidWall.sizeUSD)} @ ${formatPrice(topBidWall.price, tickSize)}`
      : wallMetric;
    wallDetail = topBidWall
      ? `${topBidWall.type === 'ICEBERG_ABSORPTION' ? 'Iceberg Absorption' : 'Resting Limit Bid Wall'} (${topBidWall.zScore.toFixed(1)}σ, ${formatUSD(topBidWall.sizeUSD)}) defending downside at ${formatPrice(topBidWall.price, tickSize)}.`
      : `L2 Orderbook skewed +${orderbookImbalancePct.toFixed(1)}% toward resting Bid liquidity.`;
  } else {
    wallSignal = 'BEARISH';
    netScore -= 15;
    wallMetric = topAskWall
      ? `Ask Wall ${formatUSD(topAskWall.sizeUSD)} @ ${formatPrice(topAskWall.price, tickSize)}`
      : wallMetric;
    wallDetail = topAskWall
      ? `${topAskWall.type === 'ICEBERG_ABSORPTION' ? 'Iceberg Supply' : 'Resting Limit Ask Wall'} (${topAskWall.zScore.toFixed(1)}σ, ${formatUSD(topAskWall.sizeUSD)}) capping upside at ${formatPrice(topAskWall.price, tickSize)}.`
      : `L2 Orderbook skewed ${orderbookImbalancePct.toFixed(1)}% toward resting Ask supply.`;
  }

  factors.push({
    id: 'liquidity-walls',
    category: 'LIQUIDITY_WALLS',
    title: 'Limit Walls & Iceberg Absorption',
    metricValue: wallMetric,
    signal: wallSignal,
    weight: 15,
    passed: true,
    detail: wallDetail,
  });

  // 6. FIBONACCI GOLDEN POCKET & FOOTPRINT IMBALANCE (Weight: 10)
  const askImbalances = latest?.footprint.filter((f) => f.imbalanceAsk).length || 0;
  const bidImbalances = latest?.footprint.filter((f) => f.imbalanceBid).length || 0;
  const gpMid = (fib.goldenPocketHigh + fib.goldenPocketLow) / 2;
  const distToGPPct = gpMid > 0 ? Math.abs((lastPrice - gpMid) / lastPrice) * 100 : 1;

  let fibSignal: 'BULLISH' | 'BEARISH' | 'NEUTRAL' = 'NEUTRAL';
  let fibDetail = '';

  if (askImbalances >= bidImbalances && (fib.trend === 'BULLISH' || lastPrice >= gpMid)) {
    fibSignal = 'BULLISH';
    netScore += 10;
    fibDetail = `Footprint prints ${askImbalances} Ask Imbalance cluster(s) (≥300% diagonal buy ratio) above Fib 0.618 Golden Pocket (${formatPrice(gpMid, tickSize)}).`;
  } else {
    fibSignal = 'BEARISH';
    netScore -= 10;
    fibDetail = `Footprint prints ${bidImbalances} Bid Imbalance cluster(s) (≥300% sell ratio) aligned with Fibonacci retracement resistance (${formatPrice(gpMid, tickSize)}).`;
  }

  factors.push({
    id: 'fib-footprint',
    category: 'FIB_FOOTPRINT',
    title: 'Fibonacci Golden Pocket & Footprint Imbalance',
    metricValue: `GP ${formatPrice(gpMid, tickSize)} | ${askImbalances}B / ${bidImbalances}S Imb`,
    signal: fibSignal,
    weight: 10,
    passed: distToGPPct < 2.5 || askImbalances + bidImbalances > 0,
    detail: fibDetail,
  });

  // 7. LIQUIDITY HEATMAP PERSISTENCE (Weight: 12)
  const heatmapBid = heatmap.nearestBidZone;
  const heatmapAsk = heatmap.nearestAskZone;
  const heatBidStrength = heatmapBid
    ? heatmapBid.averageIntensity * 0.6 + heatmapBid.persistencePct / 250
    : 0;
  const heatAskStrength = heatmapAsk
    ? heatmapAsk.averageIntensity * 0.6 + heatmapAsk.persistencePct / 250
    : 0;
  const heatmapSignal: ConfluenceFactor['signal'] =
    heatmap.imbalancePct > 4 || heatBidStrength > heatAskStrength * 1.15
      ? 'BULLISH'
      : heatmap.imbalancePct < -4 || heatAskStrength > heatBidStrength * 1.15
      ? 'BEARISH'
      : 'NEUTRAL';
  const heatmapWeight = heatmap.zones.length > 0 ? 12 : 0;
  if (heatmapSignal === 'BULLISH') netScore += heatmapWeight;
  else if (heatmapSignal === 'BEARISH') netScore -= heatmapWeight;
  factors.push({
    id: 'heatmap-persistence',
    category: 'HEATMAP',
    title: 'Liquidity Heatmap Persistence & Magnets',
    metricValue: `${heatmap.dominantSide} ${heatmap.imbalancePct >= 0 ? '+' : ''}${heatmap.imbalancePct.toFixed(1)}%`,
    signal: heatmapSignal,
    weight: heatmapWeight,
    passed: false,
    detail: `${heatmap.modelLabel}. Nearest bid zone ${heatmapBid ? formatPrice(heatmapBid.price, tickSize) : 'n/a'} (${heatmapBid?.persistencePct.toFixed(0) || 0}% persistent); nearest ask zone ${heatmapAsk ? formatPrice(heatmapAsk.price, tickSize) : 'n/a'} (${heatmapAsk?.persistencePct.toFixed(0) || 0}% persistent).`,
  });

  // 8. AGGRESSIVE TAPE & ABSORPTION (Weight: 14)
  const tapeSignal: ConfluenceFactor['signal'] =
    tape.state === 'BUYERS_IN_CONTROL' || tape.state === 'BID_ABSORPTION'
      ? 'BULLISH'
      : tape.state === 'SELLERS_IN_CONTROL' || tape.state === 'ASK_ABSORPTION'
      ? 'BEARISH'
      : 'NEUTRAL';
  const tapeWeight = tape.tradeCount >= 4 ? 14 : 0;
  if (tapeSignal === 'BULLISH') netScore += tapeWeight;
  else if (tapeSignal === 'BEARISH') netScore -= tapeWeight;
  factors.push({
    id: 'aggressive-tape',
    category: 'TAPE',
    title: 'Aggressive Tape, Price Response & Absorption',
    metricValue: `${tape.state.replace(/_/g, ' ')} | ${tape.buySellRatio.toFixed(2)}x`,
    signal: tapeSignal,
    weight: tapeWeight,
    passed: false,
    detail: `${tape.tradeCount} prints: buy ${formatUSD(tape.buyVolumeUSD)} vs sell ${formatUSD(tape.sellVolumeUSD)}; tape Δ ${formatUSD(tape.netDeltaUSD)} with ${tape.priceChangePct >= 0 ? '+' : ''}${tape.priceChangePct.toFixed(3)}% price response. ${tape.stateLabel}.`,
  });

  // 9. ADAPTIVE WHALE FLOW (Weight: 12)
  const whaleSignal: ConfluenceFactor['signal'] =
    whales.dominantSide === 'BUY'
      ? 'BULLISH'
      : whales.dominantSide === 'SELL'
      ? 'BEARISH'
      : 'NEUTRAL';
  const whaleWeight = whales.whaleCount > 0 ? 12 : 0;
  if (whaleSignal === 'BULLISH') netScore += whaleWeight;
  else if (whaleSignal === 'BEARISH') netScore -= whaleWeight;
  factors.push({
    id: 'whale-flow',
    category: 'WHALES',
    title: 'Whale Prints & Large-Lot Positioning',
    metricValue: `${whales.whaleCount} whales | Δ ${formatUSD(whales.netDeltaUSD)}`,
    signal: whaleSignal,
    weight: whaleWeight,
    passed: false,
    detail: `Adaptive threshold ${formatUSD(whales.thresholdUSD)}: ${whales.buyCount} buy / ${whales.sellCount} sell prints, ${whales.whaleVolumePct.toFixed(1)}% of taped volume. ${whales.divergence === 'OPPOSES_TAPE' ? 'Whale flow opposes aggregate tape; conflict penalty applied.' : 'Whale and tape direction checked for agreement.'} Largest print ${formatUSD(whales.largestPrint?.notionalUSD || 0)}.`,
  });

  // 10. OPTIONS GAMMA / FUTURES GAMMA PROXY (Weight: 8 live, 4 proxy)
  const distanceToCallWallPct = lastPrice > 0 ? ((gamma.callWall - lastPrice) / lastPrice) * 100 : 1;
  const distanceToPutWallPct = lastPrice > 0 ? ((lastPrice - gamma.putWall) / lastPrice) * 100 : 1;
  let gammaSignal: ConfluenceFactor['signal'] =
    lastPrice >= gamma.gammaFlip ? 'BULLISH' : 'BEARISH';
  if (gamma.regime === 'POSITIVE_GAMMA' && distanceToCallWallPct >= 0 && distanceToCallWallPct < 0.3) {
    gammaSignal = 'BEARISH';
  } else if (gamma.regime === 'POSITIVE_GAMMA' && distanceToPutWallPct >= 0 && distanceToPutWallPct < 0.3) {
    gammaSignal = 'BULLISH';
  }
  const gammaWeight = gamma.isProxy ? 4 : 8;
  if (gammaSignal === 'BULLISH') netScore += gammaWeight;
  else netScore -= gammaWeight;
  factors.push({
    id: 'gamma-exposure',
    category: 'GAMMA',
    title: gamma.isProxy ? 'Futures Gamma Regime Proxy' : 'Options Gamma Exposure & Dealer Walls',
    metricValue: `${gamma.regime.replace('_', ' ')} | Flip ${formatPrice(gamma.gammaFlip, tickSize)}`,
    signal: gammaSignal,
    weight: gammaWeight,
    passed: false,
    detail: `${gamma.sourceLabel}. Net GEX ${formatUSD(gamma.netGexUSD)} per 1% move; call wall ${formatPrice(gamma.callWall, tickSize)}, put wall ${formatPrice(gamma.putWall, tickSize)}. ${gamma.description}`,
  });

  // 11. FUNDING & CROWDING RISK (Weight: 5)
  const fundingBps = fundingRate * 10000;
  const fundingSignal: ConfluenceFactor['signal'] =
    fundingBps > 5
      ? 'BEARISH'
      : fundingBps < -5
      ? 'BULLISH'
      : fundingBps >= 0.2
      ? 'BULLISH'
      : fundingBps <= -0.2
      ? 'BEARISH'
      : 'NEUTRAL';
  if (fundingSignal === 'BULLISH') netScore += 5;
  else if (fundingSignal === 'BEARISH') netScore -= 5;
  factors.push({
    id: 'funding-crowding',
    category: 'FUNDING',
    title: 'Funding Rate & Perpetual Crowding Risk',
    metricValue: `${fundingBps >= 0 ? '+' : ''}${fundingBps.toFixed(2)} bps`,
    signal: fundingSignal,
    weight: 5,
    passed: false,
    detail: Math.abs(fundingBps) > 5
      ? 'Extreme funding treated as contrarian crowding risk, not a trend-confirmation signal.'
      : 'Funding is within a normal band and used only as a low-weight positioning input.',
  });

  // Determine overall Trade Direction & Setup Geometry after ALL inputs are evaluated
  const direction: 'LONG' | 'SHORT' = netScore >= 0 ? 'LONG' : 'SHORT';
  const targetSignal: 'BULLISH' | 'BEARISH' = direction === 'LONG' ? 'BULLISH' : 'BEARISH';
  const alignedFactors = factors.map((f) => ({
    ...f,
    passed: f.signal === targetSignal,
  }));

  const totalEvaluatedWeight = factors.reduce((sum, factor) => sum + factor.weight, 0) || 1;
  const normalizedBiasScore = Math.round((netScore / totalEvaluatedWeight) * 100);
  const alignedWeight = alignedFactors
    .filter((factor) => factor.passed)
    .reduce((sum, factor) => sum + factor.weight, 0);
  const alignedWeightPct = (alignedWeight / totalEvaluatedWeight) * 100;
  const confidence = Math.min(
    96,
    Math.max(35, Math.round(34 + Math.abs(normalizedBiasScore) * 0.34 + alignedWeightPct * 0.3))
  );
  let setupGrade: TradeSetup['setupGrade'] =
    confidence >= 86 ? 'A+' : confidence >= 76 ? 'A' : confidence >= 68 ? 'B+' : 'B';

  const sessionRange = Math.max(
    (fib.swingHigh - fib.swingLow) || lastPrice * 0.015,
    lastPrice * 0.008
  );

  let entryPrice = lastPrice;
  let stopLoss = lastPrice;
  let tp1 = lastPrice;
  let tp2 = lastPrice;
  let tp3 = lastPrice;
  let entryType = 'LIMIT @ CONFLUENCE ZONE';
  let entryOrderType: TradeSetup['entryOrderType'] = 'LIMIT';
  let stopLossReason = '';
  let tp1Reason = '';
  let tp2Reason = '';
  let tp3Reason = '';

  if (direction === 'LONG') {
    // Choose smart institutional Long entry anchored near support (VAL, Bid Wall, VWAP, or Fib 0.618)
    const candidateSupports = [
      topBidWall?.price,
      val,
      vwap,
      poc,
      fib.goldenPocketHigh,
    ].filter((p): p is number => Boolean(p && p <= lastPrice * 1.001 && p >= lastPrice * 0.985));

    const anchorSupport =
      candidateSupports.length > 0
        ? candidateSupports.sort((a, b) => Math.abs(lastPrice - a) - Math.abs(lastPrice - b))[0]
        : lastPrice - sessionRange * 0.08;

    entryPrice = roundToTick(Math.min(lastPrice, anchorSupport * 0.65 + lastPrice * 0.35), tickSize);

    if (topBidWall && Math.abs(entryPrice - topBidWall.price) / lastPrice < 0.004) {
      entryType =
        topBidWall.type === 'ICEBERG_ABSORPTION'
          ? 'ICEBERG BID ABSORPTION LIMIT'
          : `LIMIT @ ${topBidWall.zScore.toFixed(1)}σ BID WALL`;
      entryOrderType = topBidWall.type === 'ICEBERG_ABSORPTION' ? 'MARKET-ABSORPTION' : 'LIMIT';
    } else if (Math.abs(entryPrice - val) / lastPrice < 0.005) {
      entryType = 'LIMIT @ VALUE AREA LOW (VAL)';
      entryOrderType = 'LIMIT';
    } else if (Math.abs(entryPrice - poc) / lastPrice < 0.004) {
      entryType = 'LIMIT @ POC RETEST CONFLUENCE';
      entryOrderType = 'LIMIT';
    } else {
      entryType = 'LIMIT @ VWAP + DELTA DEMAND';
      entryOrderType = 'LIMIT';
    }

    // Stop Loss placed below defending Bid Wall / VAL / Swing Low invalidation
    const lowestDefendingWall = bidWalls[bidWalls.length - 1]?.price || entryPrice - sessionRange * 0.25;
    const rawSL = Math.min(
      entryPrice - sessionRange * 0.22,
      Math.max(entryPrice * 0.982, Math.min(val, lowestDefendingWall) - sessionRange * 0.06)
    );
    stopLoss = roundToTick(Math.min(rawSL, entryPrice * 0.996), tickSize);
    stopLossReason = `Below ${formatPrice(val, tickSize)} VAL & defending Bid Wall liquidity invalidation`;

    const riskDist = Math.max(entryPrice - stopLoss, entryPrice * 0.0025);

    // TP1 = POC or VWAP or +1.6R
    const rawTP1 = Math.max(
      entryPrice + riskDist * 1.55,
      poc > entryPrice ? poc : vwap > entryPrice ? vwap : entryPrice + riskDist * 1.65
    );
    tp1 = roundToTick(rawTP1, tickSize);
    tp1Reason = poc > entryPrice ? `Point of Control (POC @ ${formatPrice(poc, tickSize)})` : `Session VWAP / +1.6R Structural Target`;

    // TP2 = VAH or Major Ask Wall or +2.7R
    const askMagnet = topAskWall && topAskWall.price > tp1 ? topAskWall.price : vah;
    const rawTP2 = Math.max(tp1 + riskDist * 1.05, askMagnet > tp1 ? askMagnet : entryPrice + riskDist * 2.75);
    tp2 = roundToTick(rawTP2, tickSize);
    tp2Reason =
      vah > tp1
        ? `Value Area High (VAH @ ${formatPrice(vah, tickSize)}) + Ask Liquidity Magnet`
        : `Major Resting Ask Wall (${formatPrice(tp2, tickSize)})`;

    // TP3 = Swing High / VWAP +2σ Expansion
    const rawTP3 = Math.max(tp2 + riskDist * 1.15, Math.max(fib.swingHigh, latest?.vwapUpper2 || 0));
    tp3 = roundToTick(rawTP3, tickSize);
    tp3Reason = `Swing High Liquidity Pool & VWAP +2σ Band`;
  } else {
    // SHORT SETUP
    const candidateResistances = [
      topAskWall?.price,
      vah,
      vwap,
      poc,
      fib.goldenPocketLow,
    ].filter((p): p is number => Boolean(p && p >= lastPrice * 0.999 && p <= lastPrice * 1.015));

    const anchorRes =
      candidateResistances.length > 0
        ? candidateResistances.sort((a, b) => Math.abs(lastPrice - a) - Math.abs(lastPrice - b))[0]
        : lastPrice + sessionRange * 0.08;

    entryPrice = roundToTick(Math.max(lastPrice, anchorRes * 0.65 + lastPrice * 0.35), tickSize);

    if (topAskWall && Math.abs(entryPrice - topAskWall.price) / lastPrice < 0.004) {
      entryType =
        topAskWall.type === 'ICEBERG_ABSORPTION'
          ? 'ICEBERG ASK ABSORPTION LIMIT'
          : `LIMIT @ ${topAskWall.zScore.toFixed(1)}σ ASK WALL`;
      entryOrderType = topAskWall.type === 'ICEBERG_ABSORPTION' ? 'MARKET-ABSORPTION' : 'LIMIT';
    } else if (Math.abs(entryPrice - vah) / lastPrice < 0.005) {
      entryType = 'LIMIT @ VALUE AREA HIGH (VAH)';
      entryOrderType = 'LIMIT';
    } else if (Math.abs(entryPrice - poc) / lastPrice < 0.004) {
      entryType = 'LIMIT @ POC SUPPLY REJECTION';
      entryOrderType = 'LIMIT';
    } else {
      entryType = 'LIMIT @ VWAP + DELTA SUPPLY';
      entryOrderType = 'LIMIT';
    }

    const highestDefendingWall = askWalls[askWalls.length - 1]?.price || entryPrice + sessionRange * 0.25;
    const rawSL = Math.max(
      entryPrice + sessionRange * 0.22,
      Math.min(entryPrice * 1.018, Math.max(vah, highestDefendingWall) + sessionRange * 0.06)
    );
    stopLoss = roundToTick(Math.max(rawSL, entryPrice * 1.004), tickSize);
    stopLossReason = `Above ${formatPrice(vah, tickSize)} VAH & defending Ask Wall invalidation`;

    const riskDist = Math.max(stopLoss - entryPrice, entryPrice * 0.0025);

    const rawTP1 = Math.min(
      entryPrice - riskDist * 1.55,
      poc < entryPrice ? poc : vwap < entryPrice ? vwap : entryPrice - riskDist * 1.65
    );
    tp1 = roundToTick(rawTP1, tickSize);
    tp1Reason = poc < entryPrice ? `Point of Control (POC @ ${formatPrice(poc, tickSize)})` : `Session VWAP / +1.6R Rotational Target`;

    const bidMagnet = topBidWall && topBidWall.price < tp1 ? topBidWall.price : val;
    const rawTP2 = Math.min(tp1 - riskDist * 1.05, bidMagnet < tp1 ? bidMagnet : entryPrice - riskDist * 2.75);
    tp2 = roundToTick(rawTP2, tickSize);
    tp2Reason =
      val < tp1
        ? `Value Area Low (VAL @ ${formatPrice(val, tickSize)}) + Bid Liquidity Pool`
        : `Major Resting Bid Wall (${formatPrice(tp2, tickSize)})`;

    const rawTP3 = Math.min(tp2 - riskDist * 1.15, Math.min(fib.swingLow, latest?.vwapLower2 || tp2));
    tp3 = roundToTick(rawTP3, tickSize);
    tp3Reason = `Swing Low Liquidity Sweep & VWAP -2σ Band`;
  }

  const riskAbs = Math.max(Math.abs(entryPrice - stopLoss), tickSize || 0.0001);
  const reward1Abs = Math.abs(tp1 - entryPrice);
  const reward2Abs = Math.abs(tp2 - entryPrice);
  const reward3Abs = Math.abs(tp3 - entryPrice);

  const rr1 = Number((reward1Abs / riskAbs).toFixed(2));
  const rr2 = Number((reward2Abs / riskAbs).toFixed(2));
  const rr3 = Number((reward3Abs / riskAbs).toFixed(2));

  const riskPct = Number(((riskAbs / entryPrice) * 100).toFixed(2));
  const rewardPct = Number(((reward2Abs / entryPrice) * 100).toFixed(2));
  const zoneSpread = riskAbs * 0.18;

  const evaluatedFactors = alignedFactors.filter((factor) => factor.weight > 0);
  const passedCount = alignedFactors.filter((f) => f.passed).length;
  const requiredAligned = Math.max(6, Math.ceil(evaluatedFactors.length * 0.6));
  const minimumRR = 1.5;
  const blockedReasons: string[] = [];

  if (marketDataSource === 'SYNTHETIC_FALLBACK') blockedReasons.push('Synthetic fallback data is active; connect to a live Binance endpoint before any setup can become actionable.');
  if (klines.length < 24) blockedReasons.push('Need at least 24 closed/forming bars for stable profile, CVD and heatmap structure.');
  if (!oiRegime.dataAvailable) blockedReasons.push('Live futures Open Interest is unavailable; the engine will not approve a setup without derivatives positioning data.');
  if (tape.tradeCount < 4) blockedReasons.push('Aggressive tape has fewer than 4 usable prints; tape and price-response confirmation are incomplete.');
  if (whales.dominantSide === 'NO_DATA') blockedReasons.push('Whale-flow evidence is unavailable; large-lot positioning must be evaluated before entry.');
  if (heatmap.zones.length === 0) blockedReasons.push('No persistent heatmap zones have been established yet; liquidity mapping is incomplete.');
  if (evaluatedFactors.length < 9) blockedReasons.push(`Only ${evaluatedFactors.length}/11 evidence groups have usable data; wait for tape, whale and heatmap coverage.`);
  if (passedCount < requiredAligned) blockedReasons.push(`Only ${passedCount}/${alignedFactors.length} factors align with ${direction}; ${requiredAligned} aligned factors required.`);
  if (Math.abs(normalizedBiasScore) < 10) blockedReasons.push(`Composite bias ${normalizedBiasScore >= 0 ? '+' : ''}${normalizedBiasScore} is inside the ±10 no-trade conflict band.`);
  if (rr2 < minimumRR) blockedReasons.push(`TP2 offers ${rr2}R; minimum acceptable structural R:R is ${minimumRR.toFixed(2)}R.`);
  if (riskPct > 6) blockedReasons.push(`Structural stop requires ${riskPct}% risk; above the 6% execution-quality limit.`);

  const whaleGross = whales.buyVolumeUSD + whales.sellVolumeUSD;
  const strongWhaleOpposition =
    whaleGross > 0 &&
    Math.abs(whales.netDeltaUSD) / whaleGross > 0.22 &&
    ((direction === 'LONG' && whales.dominantSide === 'SELL') ||
      (direction === 'SHORT' && whales.dominantSide === 'BUY'));
  if (strongWhaleOpposition) blockedReasons.push(`Whale ${whales.dominantSide} flow (${formatUSD(whales.netDeltaUSD)} net) opposes the candidate ${direction}.`);

  const tapeTotal = tape.buyVolumeUSD + tape.sellVolumeUSD;
  const strongTapeOpposition =
    tapeTotal > 0 &&
    Math.abs(tape.netDeltaUSD) / tapeTotal > 0.18 &&
    ((direction === 'LONG' && tape.state === 'SELLERS_IN_CONTROL') ||
      (direction === 'SHORT' && tape.state === 'BUYERS_IN_CONTROL'));
  if (strongTapeOpposition) blockedReasons.push(`Aggressive tape (${tape.state.replace(/_/g, ' ')}) opposes the candidate ${direction}.`);

  if (
    direction === 'LONG' &&
    heatmapAsk &&
    heatmapAsk.distancePct >= 0 &&
    heatmapAsk.distancePct < 0.18 &&
    heatmapAsk.currentIntensity > 0.72
  ) {
    blockedReasons.push(`Persistent ask heatmap zone at ${formatPrice(heatmapAsk.price, tickSize)} blocks the LONG path.`);
  }
  if (
    direction === 'SHORT' &&
    heatmapBid &&
    heatmapBid.distancePct <= 0 &&
    Math.abs(heatmapBid.distancePct) < 0.18 &&
    heatmapBid.currentIntensity > 0.72
  ) {
    blockedReasons.push(`Persistent bid heatmap zone at ${formatPrice(heatmapBid.price, tickSize)} blocks the SHORT path.`);
  }

  if (!gamma.isProxy && gamma.regime === 'POSITIVE_GAMMA') {
    if (direction === 'LONG' && distanceToCallWallPct >= 0 && distanceToCallWallPct < 0.25) {
      blockedReasons.push(`Positive-gamma call wall at ${formatPrice(gamma.callWall, tickSize)} is inside the LONG entry path.`);
    }
    if (direction === 'SHORT' && distanceToPutWallPct >= 0 && distanceToPutWallPct < 0.25) {
      blockedReasons.push(`Positive-gamma put wall at ${formatPrice(gamma.putWall, tickSize)} is inside the SHORT entry path.`);
    }
  }

  const status: TradeSetup['status'] = blockedReasons.length === 0 ? 'ACTIONABLE' : 'WAIT';
  if (status === 'WAIT') setupGrade = 'WAIT';
  const outputDirection: TradeSetup['direction'] =
    Math.abs(normalizedBiasScore) < 10 ? 'NEUTRAL' : direction;

  const thesisSummary =
    status === 'WAIT'
      ? `NO TRADE yet. ${symbol} has ${outputDirection === 'NEUTRAL' ? 'no directional edge' : `a conditional ${direction} bias`} (${normalizedBiasScore >= 0 ? '+' : ''}${normalizedBiasScore}) after evaluating all ${alignedFactors.length} evidence groups, but execution is blocked: ${blockedReasons.join(' ')} Levels shown below are watch levels only, not an active recommendation.`
      : direction === 'LONG'
      ? `${symbol} passes the full ${passedCount}/${alignedFactors.length}-factor gate with ${formatUSD(whales.netDeltaUSD)} whale Δ, ${formatUSD(tape.netDeltaUSD)} tape Δ and ${heatmap.dominantSide} heatmap skew. Resting Bid liquidity and ${formatPrice(val, tickSize)} VAL / ${formatPrice(poc, tickSize)} POC structure support ${entryType} at ${formatPrice(entryPrice, tickSize)}, targeting ${formatPrice(tp1, tickSize)} (TP1) and ${formatPrice(tp2, tickSize)} (TP2, ${rr2}R), invalid below ${formatPrice(stopLoss, tickSize)}.`
      : `${symbol} passes the full ${passedCount}/${alignedFactors.length}-factor gate with ${formatUSD(whales.netDeltaUSD)} whale Δ, ${formatUSD(tape.netDeltaUSD)} tape Δ and ${heatmap.dominantSide} heatmap skew. Overhead Ask supply and ${formatPrice(vah, tickSize)} VAH / ${formatPrice(poc, tickSize)} POC rejection favor ${entryType} at ${formatPrice(entryPrice, tickSize)}, targeting ${formatPrice(tp1, tickSize)} (TP1) and ${formatPrice(tp2, tickSize)} (TP2, ${rr2}R), invalid above ${formatPrice(stopLoss, tickSize)}.`;

  return {
    symbol,
    timeframe,
    generatedAt: Date.now(),
    direction: outputDirection,
    biasScore: normalizedBiasScore,
    confidence,
    setupGrade,
    entryType,
    entryOrderType,
    entryPrice,
    entryZone: [
      roundToTick(entryPrice - zoneSpread, tickSize),
      roundToTick(entryPrice + zoneSpread, tickSize),
    ],
    stopLoss,
    stopLossReason,
    tp1,
    tp1Reason,
    tp2,
    tp2Reason,
    tp3,
    tp3Reason,
    rr1,
    rr2,
    rr3,
    riskPct,
    rewardPct,
    invalidationLevel: stopLoss,
    confluenceFactors: alignedFactors,
    thesisSummary,
    status,
    blockedReasons,
    factorsEvaluated: alignedFactors.length,
    factorsAligned: passedCount,
    minimumRR,
  };
}
