import { AssetTicker, LiveAggTrade, Timeframe } from '../types/orderflow';

export interface PopularAssetMeta {
  symbol: string;
  baseAsset: string;
  name: string;
  category: 'LAYER-1' | 'DEFI' | 'AI & INFRA' | 'MEME' | 'EXCHANGE';
  defaultPrice: number;
  tickSize: number;
  pricePrecision: number;
  defaultOIUSD: number;
}

export const DEFAULT_FUTURES_ASSETS: PopularAssetMeta[] = [
  { symbol: 'BTCUSDT', baseAsset: 'BTC', name: 'Bitcoin Perp', category: 'LAYER-1', defaultPrice: 91420.5, tickSize: 0.1, pricePrecision: 1, defaultOIUSD: 18_450_000_000 },
  { symbol: 'ETHUSDT', baseAsset: 'ETH', name: 'Ethereum Perp', category: 'LAYER-1', defaultPrice: 2745.8, tickSize: 0.01, pricePrecision: 2, defaultOIUSD: 7_820_000_000 },
  { symbol: 'SOLUSDT', baseAsset: 'SOL', name: 'Solana Perp', category: 'LAYER-1', defaultPrice: 188.45, tickSize: 0.01, pricePrecision: 2, defaultOIUSD: 3_120_000_000 },
  { symbol: 'BNBUSDT', baseAsset: 'BNB', name: 'BNB Chain Perp', category: 'EXCHANGE', defaultPrice: 642.3, tickSize: 0.01, pricePrecision: 2, defaultOIUSD: 890_000_000 },
  { symbol: 'XRPUSDT', baseAsset: 'XRP', name: 'Ripple Perp', category: 'LAYER-1', defaultPrice: 2.5420, tickSize: 0.0001, pricePrecision: 4, defaultOIUSD: 2_340_000_000 },
  { symbol: 'DOGEUSDT', baseAsset: 'DOGE', name: 'Dogecoin Perp', category: 'MEME', defaultPrice: 0.26450, tickSize: 0.00001, pricePrecision: 5, defaultOIUSD: 1_450_000_000 },
  { symbol: 'SUIUSDT', baseAsset: 'SUI', name: 'Sui Network Perp', category: 'LAYER-1', defaultPrice: 3.4120, tickSize: 0.0001, pricePrecision: 4, defaultOIUSD: 780_000_000 },
  { symbol: 'AVAXUSDT', baseAsset: 'AVAX', name: 'Avalanche Perp', category: 'LAYER-1', defaultPrice: 26.84, tickSize: 0.01, pricePrecision: 2, defaultOIUSD: 490_000_000 },
  { symbol: 'LINKUSDT', baseAsset: 'LINK', name: 'Chainlink Perp', category: 'DEFI', defaultPrice: 18.920, tickSize: 0.001, pricePrecision: 3, defaultOIUSD: 540_000_000 },
  { symbol: 'ADAUSDT', baseAsset: 'ADA', name: 'Cardano Perp', category: 'LAYER-1', defaultPrice: 0.7840, tickSize: 0.0001, pricePrecision: 4, defaultOIUSD: 620_000_000 },
  { symbol: 'AAVEUSDT', baseAsset: 'AAVE', name: 'Aave Protocol Perp', category: 'DEFI', defaultPrice: 256.40, tickSize: 0.01, pricePrecision: 2, defaultOIUSD: 340_000_000 },
  { symbol: 'INJUSDT', baseAsset: 'INJ', name: 'Injective Perp', category: 'DEFI', defaultPrice: 15.680, tickSize: 0.001, pricePrecision: 3, defaultOIUSD: 210_000_000 },
  { symbol: 'NEARUSDT', baseAsset: 'NEAR', name: 'NEAR Protocol Perp', category: 'AI & INFRA', defaultPrice: 3.485, tickSize: 0.001, pricePrecision: 3, defaultOIUSD: 285_000_000 },
  { symbol: 'FETUSDT', baseAsset: 'FET', name: 'ASI Alliance Perp', category: 'AI & INFRA', defaultPrice: 0.7940, tickSize: 0.0001, pricePrecision: 4, defaultOIUSD: 195_000_000 },
  { symbol: 'WIFUSDT', baseAsset: 'WIF', name: 'dogwifhat Perp', category: 'MEME', defaultPrice: 0.7280, tickSize: 0.0001, pricePrecision: 4, defaultOIUSD: 320_000_000 },
  { symbol: 'LTCUSDT', baseAsset: 'LTC', name: 'Litecoin Perp', category: 'LAYER-1', defaultPrice: 124.60, tickSize: 0.01, pricePrecision: 2, defaultOIUSD: 610_000_000 },
];

export interface RawKlineBar {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  quoteVolume: number;
  takerBuyQuoteVolume: number;
}

export interface SnapshotBundle {
  source: 'BINANCE_FAPI_LIVE' | 'BINANCE_VISION_MIRROR' | 'SYNTHETIC_FALLBACK';
  ticker: AssetTicker;
  klines: RawKlineBar[];
  oiHistoryMap: Map<number, number>;
  orderbook: {
    bids: [number, number][];
    asks: [number, number][];
  };
  recentTrades: LiveAggTrade[];
}

async function fetchWithTimeout(url: string, timeoutMs = 4500): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { signal: controller.signal });
    return res;
  } finally {
    clearTimeout(timer);
  }
}

export function getAssetMeta(symbol: string): PopularAssetMeta {
  const clean = symbol.toUpperCase().trim();
  const found = DEFAULT_FUTURES_ASSETS.find((a) => a.symbol === clean);
  if (found) return found;
  const baseAsset = clean.replace(/USDT$/, '') || clean;
  return {
    symbol: clean.endsWith('USDT') ? clean : `${clean}USDT`,
    baseAsset,
    name: `${baseAsset} Perpetual`,
    category: 'LAYER-1',
    defaultPrice: 100,
    tickSize: 0.01,
    pricePrecision: 2,
    defaultOIUSD: 250_000_000,
  };
}

/**
 * Fetches full list of Binance USDT-M Perpetual symbols so user can inspect ANY Binance Futures asset
 */
export async function fetchAllBinanceFuturesSymbols(): Promise<string[]> {
  try {
    const res = await fetchWithTimeout('https://fapi.binance.com/fapi/v1/exchangeInfo', 4000);
    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data.symbols)) {
        return data.symbols
          .filter(
            (s: { status?: string; contractType?: string; quoteAsset?: string }) =>
              s.status === 'TRADING' &&
              s.contractType === 'PERPETUAL' &&
              s.quoteAsset === 'USDT'
          )
          .map((s: { symbol: string }) => s.symbol);
      }
    }
  } catch {
    // Fallback to public vision API or curated list
  }
  return DEFAULT_FUTURES_ASSETS.map((a) => a.symbol);
}

/**
 * Fetches complete orderflow snapshot for a symbol & timeframe from Binance Futures free open endpoints
 */
export async function fetchAssetOrderflowSnapshot(
  symbol: string,
  timeframe: Timeframe
): Promise<SnapshotBundle> {
  const meta = getAssetMeta(symbol);
  const sym = meta.symbol;
  const oiPeriod = timeframe === '1m' ? '5m' : timeframe;

  // 1. Try Primary Binance USDT-M Futures Open API (fapi.binance.com)
  try {
    const [klineRes, depthRes, ticker24Res, premiumRes, oiRes, tradesRes] = await Promise.all([
      fetchWithTimeout(`https://fapi.binance.com/fapi/v1/klines?symbol=${sym}&interval=${timeframe}&limit=64`),
      fetchWithTimeout(`https://fapi.binance.com/fapi/v1/depth?symbol=${sym}&limit=100`),
      fetchWithTimeout(`https://fapi.binance.com/fapi/v1/ticker/24hr?symbol=${sym}`),
      fetchWithTimeout(`https://fapi.binance.com/fapi/v1/premiumIndex?symbol=${sym}`),
      fetchWithTimeout(`https://fapi.binance.com/fapi/v1/openInterest?symbol=${sym}`),
      fetchWithTimeout(`https://fapi.binance.com/fapi/v1/aggTrades?symbol=${sym}&limit=50`),
    ]);

    if (klineRes.ok && depthRes.ok && ticker24Res.ok) {
      const [rawKlines, rawDepth, raw24h] = await Promise.all([
        klineRes.json(),
        depthRes.json(),
        ticker24Res.json(),
      ]);

      const rawPremium = premiumRes.ok ? await premiumRes.json() : null;
      const rawOI = oiRes.ok ? await oiRes.json() : null;
      const rawTrades = tradesRes.ok ? await tradesRes.json() : [];

      // Optional historical OI
      const oiHistoryMap = new Map<number, number>();
      try {
        const oiHistRes = await fetchWithTimeout(
          `https://fapi.binance.com/futures/data/openInterestHist?symbol=${sym}&period=${oiPeriod}&limit=64`,
          2800
        );
        if (oiHistRes.ok) {
          const histList = await oiHistRes.json();
          if (Array.isArray(histList)) {
            histList.forEach((item: { timestamp: number; sumOpenInterestValue: string }) => {
              oiHistoryMap.set(Number(item.timestamp), parseFloat(item.sumOpenInterestValue));
            });
          }
        }
      } catch {
        // Optional endpoint
      }

      const klines: RawKlineBar[] = rawKlines.map((k: (string | number)[]) => ({
        time: Number(k[0]),
        open: parseFloat(String(k[1])),
        high: parseFloat(String(k[2])),
        low: parseFloat(String(k[3])),
        close: parseFloat(String(k[4])),
        volume: parseFloat(String(k[5])),
        quoteVolume: parseFloat(String(k[7])),
        takerBuyQuoteVolume: parseFloat(String(k[10])),
      }));

      const lastPrice = parseFloat(raw24h.lastPrice) || klines[klines.length - 1]?.close || meta.defaultPrice;
      const oiContracts = rawOI ? parseFloat(rawOI.openInterest) : meta.defaultOIUSD / lastPrice;
      const openInterestUSD = oiContracts * lastPrice;

      const bids: [number, number][] = (rawDepth.bids || []).map((b: string[]) => [
        parseFloat(b[0]),
        parseFloat(b[1]),
      ]);
      const asks: [number, number][] = (rawDepth.asks || []).map((a: string[]) => [
        parseFloat(a[0]),
        parseFloat(a[1]),
      ]);

      // Infer tickSize dynamically from prices if not in default list
      const inferredTick = inferTickSize(lastPrice, meta.tickSize);

      const recentTrades: LiveAggTrade[] = Array.isArray(rawTrades)
        ? rawTrades
            .slice(-45)
            .reverse()
            .map((t: { a: number; p: string; q: string; T: number; m: boolean }) => {
              const price = parseFloat(t.p);
              const qty = parseFloat(t.q);
              const notionalUSD = price * qty;
              return {
                id: t.a,
                price,
                qty,
                notionalUSD,
                time: t.T,
                isBuyerMaker: Boolean(t.m),
                isWhale: notionalUSD >= 25_000,
              };
            })
        : [];

      return {
        source: 'BINANCE_FAPI_LIVE',
        ticker: {
          symbol: sym,
          baseAsset: meta.baseAsset,
          quoteAsset: 'USDT',
          lastPrice,
          markPrice: rawPremium ? parseFloat(rawPremium.markPrice) : lastPrice,
          indexPrice: rawPremium ? parseFloat(rawPremium.indexPrice) : lastPrice * 0.9998,
          priceChangePct24h: parseFloat(raw24h.priceChangePercent) || 0,
          high24h: parseFloat(raw24h.highPrice) || lastPrice * 1.02,
          low24h: parseFloat(raw24h.lowPrice) || lastPrice * 0.98,
          volume24hUSD: parseFloat(raw24h.quoteVolume) || 1_200_000_000,
          openInterestUSD,
          openInterestContracts: oiContracts,
          fundingRate: rawPremium ? parseFloat(rawPremium.lastFundingRate) : 0.0001,
          nextFundingTime: rawPremium ? Number(rawPremium.nextFundingTime) : Date.now() + 3600_000 * 4,
          tickSize: inferredTick,
          pricePrecision: meta.pricePrecision,
        },
        klines,
        oiHistoryMap,
        orderbook: { bids, asks },
        recentTrades,
      };
    }
  } catch {
    // Proceed to Secondary Binance Public Market Data Mirror
  }

  // 2. Try Secondary Open Endpoint: data-api.binance.vision (Works globally even in geo-fenced regions)
  try {
    const [klineRes, depthRes, ticker24Res, tradesRes] = await Promise.all([
      fetchWithTimeout(`https://data-api.binance.vision/api/v3/klines?symbol=${sym}&interval=${timeframe}&limit=64`),
      fetchWithTimeout(`https://data-api.binance.vision/api/v3/depth?symbol=${sym}&limit=100`),
      fetchWithTimeout(`https://data-api.binance.vision/api/v3/ticker/24hr?symbol=${sym}`),
      fetchWithTimeout(`https://data-api.binance.vision/api/v3/aggTrades?symbol=${sym}&limit=50`),
    ]);

    if (klineRes.ok && depthRes.ok && ticker24Res.ok) {
      const [rawKlines, rawDepth, raw24h] = await Promise.all([
        klineRes.json(),
        depthRes.json(),
        ticker24Res.json(),
      ]);
      const rawTrades = tradesRes.ok ? await tradesRes.json() : [];

      const klines: RawKlineBar[] = rawKlines.map((k: (string | number)[]) => ({
        time: Number(k[0]),
        open: parseFloat(String(k[1])),
        high: parseFloat(String(k[2])),
        low: parseFloat(String(k[3])),
        close: parseFloat(String(k[4])),
        volume: parseFloat(String(k[5])),
        quoteVolume: parseFloat(String(k[7])),
        takerBuyQuoteVolume: parseFloat(String(k[10])),
      }));

      const lastPrice = parseFloat(raw24h.lastPrice) || klines[klines.length - 1]?.close || meta.defaultPrice;
      const inferredTick = inferTickSize(lastPrice, meta.tickSize);
      const quoteVol24h = parseFloat(raw24h.quoteVolume) || 0;

      const bids: [number, number][] = (rawDepth.bids || []).map((b: string[]) => [
        parseFloat(b[0]),
        parseFloat(b[1]),
      ]);
      const asks: [number, number][] = (rawDepth.asks || []).map((a: string[]) => [
        parseFloat(a[0]),
        parseFloat(a[1]),
      ]);

      const recentTrades: LiveAggTrade[] = Array.isArray(rawTrades)
        ? rawTrades
            .slice(-45)
            .reverse()
            .map((t: { a: number; p: string; q: string; T: number; m: boolean }) => {
              const price = parseFloat(t.p);
              const qty = parseFloat(t.q);
              const notionalUSD = price * qty;
              return {
                id: t.a,
                price,
                qty,
                notionalUSD,
                time: t.T,
                isBuyerMaker: Boolean(t.m),
                isWhale: notionalUSD >= 20_000,
              };
            })
        : [];

      return {
        source: 'BINANCE_VISION_MIRROR',
        ticker: {
          symbol: sym,
          baseAsset: meta.baseAsset,
          quoteAsset: 'USDT',
          lastPrice,
          markPrice: lastPrice * 1.0001,
          indexPrice: lastPrice * 0.9999,
          priceChangePct24h: parseFloat(raw24h.priceChangePercent) || 0,
          high24h: parseFloat(raw24h.highPrice) || lastPrice * 1.025,
          low24h: parseFloat(raw24h.lowPrice) || lastPrice * 0.975,
          volume24hUSD: quoteVol24h,
          openInterestUSD: 0, // Spot mirror has no futures OI; never substitute an estimate.
          openInterestContracts: 0,
          fundingRate: 0, // Funding unavailable from this mirror; treated as neutral.
          nextFundingTime: getNextFundingTimestamp(),
          tickSize: inferredTick,
          pricePrecision: meta.pricePrecision,
        },
        klines,
        oiHistoryMap: new Map(),
        orderbook: { bids, asks },
        recentTrades,
      };
    }
  } catch {
    // Proceed to Synthetic High-Precision Fallback
  }

  // 3. Deterministic Institutional Fallback (if offline or strict network sandbox)
  return generateSyntheticOrderflowSnapshot(meta, timeframe);
}

function inferTickSize(price: number, defaultTick: number): number {
  if (defaultTick && defaultTick !== 0.01) return defaultTick;
  if (price >= 10000) return 0.1;
  if (price >= 100) return 0.01;
  if (price >= 10) return 0.001;
  if (price >= 1) return 0.0001;
  if (price >= 0.05) return 0.00001;
  return 0.000001;
}

function getNextFundingTimestamp(): number {
  const now = new Date();
  const utcHours = now.getUTCHours();
  const nextIntervalHour = Math.ceil((utcHours + 0.01) / 8) * 8;
  const next = new Date(now);
  next.setUTCHours(nextIntervalHour, 0, 0, 0);
  return next.getTime();
}

function generateSyntheticOrderflowSnapshot(
  meta: PopularAssetMeta,
  timeframe: Timeframe
): SnapshotBundle {
  const tfMinutes =
    timeframe === '1m' ? 1 : timeframe === '5m' ? 5 : timeframe === '15m' ? 15 : timeframe === '1h' ? 60 : 240;
  const intervalMs = tfMinutes * 60 * 1000;
  const now = Math.floor(Date.now() / intervalMs) * intervalMs;

  const klines: RawKlineBar[] = [];
  let price = meta.defaultPrice * 0.988;

  for (let i = 63; i >= 0; i--) {
    const t = now - i * intervalMs;
    const wave = Math.sin(i * 0.24) * 0.0032 + Math.cos(i * 0.11) * 0.0021;
    const drift = 0.00022;
    const open = price;
    const close = open * (1 + wave * 0.45 + drift);
    const high = Math.max(open, close) * (1 + Math.abs(Math.sin(i * 1.7)) * 0.0026);
    const low = Math.min(open, close) * (1 - Math.abs(Math.cos(i * 1.3)) * 0.0024);

    const baseQuoteVol = (meta.defaultOIUSD * 0.012) * (0.65 + Math.abs(Math.sin(i * 0.75)) * 0.9);
    const volume = baseQuoteVol / close;
    const bullRatio = close >= open ? 0.54 + Math.abs(Math.sin(i)) * 0.12 : 0.44 - Math.abs(Math.cos(i)) * 0.1;
    const takerBuyQuoteVolume = baseQuoteVol * Math.min(0.74, Math.max(0.28, bullRatio));

    klines.push({
      time: t,
      open,
      high,
      low,
      close,
      volume,
      quoteVolume: baseQuoteVol,
      takerBuyQuoteVolume,
    });
    price = close;
  }

  const lastPrice = klines[klines.length - 1].close;
  const step = meta.tickSize * 5;
  const bids: [number, number][] = [];
  const asks: [number, number][] = [];

  for (let i = 1; i <= 40; i++) {
    const bidPrice = Number((lastPrice - i * step).toFixed(6));
    const askPrice = Number((lastPrice + i * step).toFixed(6));
    const isBidWall = i === 6 || i === 14 || i === 22;
    const isAskWall = i === 8 || i === 17 || i === 25;

    const baseNotional = (meta.defaultOIUSD * 0.00018) * (0.6 + (i % 5) * 0.22);
    const bidNotional = isBidWall ? baseNotional * 4.4 : baseNotional;
    const askNotional = isAskWall ? baseNotional * 3.9 : baseNotional;

    bids.push([bidPrice, bidNotional / bidPrice]);
    asks.push([askPrice, askNotional / askPrice]);
  }

  const recentTrades: LiveAggTrade[] = Array.from({ length: 30 }, (_, idx) => {
    const isSell = idx % 3 === 0;
    const p = lastPrice + (isSell ? -meta.tickSize : meta.tickSize) * (idx % 3);
    const notionalUSD = (idx % 7 === 0 ? 68_000 : 8_400) * (0.7 + (idx % 4) * 0.35);
    return {
      id: Date.now() - idx * 800,
      price: p,
      qty: notionalUSD / p,
      notionalUSD,
      time: Date.now() - idx * 850,
      isBuyerMaker: isSell,
      isWhale: notionalUSD >= 25_000,
    };
  });

  return {
    source: 'SYNTHETIC_FALLBACK',
    ticker: {
      symbol: meta.symbol,
      baseAsset: meta.baseAsset,
      quoteAsset: 'USDT',
      lastPrice,
      markPrice: lastPrice * 1.0001,
      indexPrice: lastPrice * 0.9998,
      priceChangePct24h: 2.38,
      high24h: lastPrice * 1.028,
      low24h: lastPrice * 0.971,
      volume24hUSD: meta.defaultOIUSD * 1.45,
      openInterestUSD: meta.defaultOIUSD,
      openInterestContracts: meta.defaultOIUSD / lastPrice,
      fundingRate: 0.000125,
      nextFundingTime: getNextFundingTimestamp(),
      tickSize: meta.tickSize,
      pricePrecision: meta.pricePrecision,
    },
    klines,
    oiHistoryMap: new Map(),
    orderbook: { bids, asks },
    recentTrades,
  };
}
