import {
  GammaExposureData,
  GammaStrikeLevel,
  HeatmapAnalysis,
  HeatmapZone,
  KlineOrderflow,
  LiveAggTrade,
  TapeAnalysis,
  WhaleFlowAnalysis,
} from '../types/orderflow';

const clamp = (value: number, min: number, max: number) =>
  Math.min(max, Math.max(min, value));

function percentile(values: number[], p: number): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const index = clamp(Math.floor((sorted.length - 1) * p), 0, sorted.length - 1);
  return sorted[index];
}

/**
 * Compresses the last 24 heatmap columns into persistent liquidity zones.
 * Historical cells are a depth-anchored model; current cells use the live L2 book where available.
 */
export function analyzeLiquidityHeatmap(
  klines: KlineOrderflow[],
  lastPrice: number
): HeatmapAnalysis {
  const recent = klines.slice(-24).filter((k) => k.heatmapSlice.length > 0);
  if (recent.length === 0 || lastPrice <= 0) {
    return {
      zones: [],
      bidLiquidityUSD: 0,
      askLiquidityUSD: 0,
      imbalancePct: 0,
      dominantSide: 'BALANCED',
      nearestBidZone: null,
      nearestAskZone: null,
      modelLabel: 'Awaiting heatmap observations',
    };
  }

  const bucketCount = Math.min(...recent.map((k) => k.heatmapSlice.length));
  const zones: HeatmapZone[] = [];
  let bidLiquidityUSD = 0;
  let askLiquidityUSD = 0;

  for (let bucket = 0; bucket < bucketCount; bucket++) {
    const cells = recent
      .map((k) => k.heatmapSlice[bucket])
      .filter((cell) => Boolean(cell));
    if (cells.length === 0) continue;

    const latest = cells[cells.length - 1];
    const price = latest.price;
    const side: 'BID' | 'ASK' = price <= lastPrice ? 'BID' : 'ASK';
    const averageIntensity =
      cells.reduce((sum, cell) => sum + cell.intensity, 0) / cells.length;
    const activeBars = cells.filter((cell) => cell.intensity >= 0.5).length;
    const persistencePct = (activeBars / cells.length) * 100;
    const averageLiquidityUSD =
      cells.reduce((sum, cell) => sum + cell.restingLiquidityUSD, 0) / cells.length;
    const currentLiquidityUSD = latest.restingLiquidityUSD;

    if (side === 'BID') bidLiquidityUSD += currentLiquidityUSD;
    else askLiquidityUSD += currentLiquidityUSD;

    if (averageIntensity >= 0.28 || latest.isLimitWall || latest.isIceberg) {
      zones.push({
        id: `${bucket}-${Math.round(price * 1e6)}`,
        price,
        side,
        averageIntensity,
        currentIntensity: latest.intensity,
        persistencePct,
        averageLiquidityUSD,
        currentLiquidityUSD,
        distancePct: ((price - lastPrice) / lastPrice) * 100,
        activeBars,
      });
    }
  }

  zones.sort(
    (a, b) =>
      b.averageIntensity * 0.55 +
      b.persistencePct / 100 * 0.25 +
      Math.min(1, b.currentLiquidityUSD / Math.max(1, bidLiquidityUSD + askLiquidityUSD)) * 0.2 -
      (a.averageIntensity * 0.55 +
        a.persistencePct / 100 * 0.25 +
        Math.min(1, a.currentLiquidityUSD / Math.max(1, bidLiquidityUSD + askLiquidityUSD)) * 0.2)
  );

  const bidZones = zones
    .filter((z) => z.side === 'BID' && z.price <= lastPrice)
    .sort((a, b) => b.price - a.price);
  const askZones = zones
    .filter((z) => z.side === 'ASK' && z.price >= lastPrice)
    .sort((a, b) => a.price - b.price);

  const total = bidLiquidityUSD + askLiquidityUSD;
  const imbalancePct = total > 0 ? ((bidLiquidityUSD - askLiquidityUSD) / total) * 100 : 0;

  return {
    zones: zones.slice(0, 14),
    bidLiquidityUSD,
    askLiquidityUSD,
    imbalancePct,
    dominantSide: imbalancePct > 5 ? 'BID' : imbalancePct < -5 ? 'ASK' : 'BALANCED',
    nearestBidZone: bidZones[0] || null,
    nearestAskZone: askZones[0] || null,
    modelLabel: `${recent.length}-bar depth-anchored liquidity persistence model`,
  };
}

/** Aggregates aggressive market orders and detects when price fails to respond to delta. */
export function analyzeAggressiveTape(trades: LiveAggTrade[]): TapeAnalysis {
  if (trades.length === 0) {
    return {
      windowMs: 60000,
      tradeCount: 0,
      buyVolumeUSD: 0,
      sellVolumeUSD: 0,
      netDeltaUSD: 0,
      buySellRatio: 1,
      buyVolumePct: 50,
      priceChangePct: 0,
      averageTradeUSD: 0,
      tradesPerMinute: 0,
      largestPrintUSD: 0,
      state: 'NO_DATA',
      stateLabel: 'Awaiting aggressive trades',
      absorptionDetected: false,
    };
  }

  const ordered = [...trades].sort((a, b) => b.time - a.time);
  const anchor = ordered[0].time;
  let windowTrades = ordered.filter((t) => anchor - t.time <= 60000);
  if (windowTrades.length < 6) windowTrades = ordered.slice(0, Math.min(30, ordered.length));

  const newest = windowTrades[0];
  const oldest = windowTrades[windowTrades.length - 1];
  const buyVolumeUSD = windowTrades
    .filter((t) => !t.isBuyerMaker)
    .reduce((sum, t) => sum + t.notionalUSD, 0);
  const sellVolumeUSD = windowTrades
    .filter((t) => t.isBuyerMaker)
    .reduce((sum, t) => sum + t.notionalUSD, 0);
  const total = buyVolumeUSD + sellVolumeUSD;
  const netDeltaUSD = buyVolumeUSD - sellVolumeUSD;
  const priceChangePct = oldest.price > 0 ? ((newest.price - oldest.price) / oldest.price) * 100 : 0;
  const actualWindowMs = Math.max(1000, newest.time - oldest.time);
  const deltaShare = total > 0 ? netDeltaUSD / total : 0;

  let state: TapeAnalysis['state'] = 'BALANCED';
  let stateLabel = 'Two-sided tape / no control';
  let absorptionDetected = false;

  if (deltaShare > 0.1 && priceChangePct < -0.015) {
    state = 'ASK_ABSORPTION';
    stateLabel = 'Ask absorption: market buys fail to lift price';
    absorptionDetected = true;
  } else if (deltaShare < -0.1 && priceChangePct > 0.015) {
    state = 'BID_ABSORPTION';
    stateLabel = 'Bid absorption: market sells fail to push price down';
    absorptionDetected = true;
  } else if (deltaShare > 0.08) {
    state = 'BUYERS_IN_CONTROL';
    stateLabel = 'Aggressive buyers lifting offers';
  } else if (deltaShare < -0.08) {
    state = 'SELLERS_IN_CONTROL';
    stateLabel = 'Aggressive sellers hitting bids';
  }

  return {
    windowMs: actualWindowMs,
    tradeCount: windowTrades.length,
    buyVolumeUSD,
    sellVolumeUSD,
    netDeltaUSD,
    buySellRatio: sellVolumeUSD > 0 ? buyVolumeUSD / sellVolumeUSD : buyVolumeUSD > 0 ? 9.99 : 1,
    buyVolumePct: total > 0 ? (buyVolumeUSD / total) * 100 : 50,
    priceChangePct,
    averageTradeUSD: total / Math.max(1, windowTrades.length),
    tradesPerMinute: (windowTrades.length / actualWindowMs) * 60000,
    largestPrintUSD: Math.max(...windowTrades.map((t) => t.notionalUSD), 0),
    state,
    stateLabel,
    absorptionDetected,
  };
}

/** Adaptive whale filter: threshold scales to the asset's own trade-size distribution. */
export function analyzeWhaleFlow(
  trades: LiveAggTrade[],
  tape: TapeAnalysis,
  volume24hUSD: number
): WhaleFlowAnalysis {
  if (trades.length === 0) {
    return {
      thresholdUSD: 25000,
      whaleCount: 0,
      buyCount: 0,
      sellCount: 0,
      buyVolumeUSD: 0,
      sellVolumeUSD: 0,
      netDeltaUSD: 0,
      whaleVolumePct: 0,
      dominantSide: 'NO_DATA',
      largestPrint: null,
      topPrints: [],
      divergence: 'NO_DATA',
    };
  }

  const notionals = trades.map((t) => t.notionalUSD);
  const assetBaseline = clamp(volume24hUSD * 0.000004, 10000, 100000);
  const thresholdUSD = Math.max(assetBaseline, percentile(notionals, 0.9));
  const whales = trades.filter((t) => t.notionalUSD >= thresholdUSD);
  const buyVolumeUSD = whales
    .filter((t) => !t.isBuyerMaker)
    .reduce((sum, t) => sum + t.notionalUSD, 0);
  const sellVolumeUSD = whales
    .filter((t) => t.isBuyerMaker)
    .reduce((sum, t) => sum + t.notionalUSD, 0);
  const netDeltaUSD = buyVolumeUSD - sellVolumeUSD;
  const whaleTotal = buyVolumeUSD + sellVolumeUSD;
  const allVolume = trades.reduce((sum, t) => sum + t.notionalUSD, 0);
  const whaleShareOfDelta = Math.abs(tape.netDeltaUSD) > 0 ? Math.abs(netDeltaUSD / tape.netDeltaUSD) : 0;
  const opposesTape =
    Math.abs(netDeltaUSD) > whaleTotal * 0.12 &&
    Math.abs(tape.netDeltaUSD) > 0 &&
    Math.sign(netDeltaUSD) !== Math.sign(tape.netDeltaUSD) &&
    whaleShareOfDelta > 0.15;

  const sorted = [...trades].sort((a, b) => b.notionalUSD - a.notionalUSD);

  return {
    thresholdUSD,
    whaleCount: whales.length,
    buyCount: whales.filter((t) => !t.isBuyerMaker).length,
    sellCount: whales.filter((t) => t.isBuyerMaker).length,
    buyVolumeUSD,
    sellVolumeUSD,
    netDeltaUSD,
    whaleVolumePct: allVolume > 0 ? (whaleTotal / allVolume) * 100 : 0,
    dominantSide:
      whales.length === 0
        ? 'NO_DATA'
        : netDeltaUSD > whaleTotal * 0.08
        ? 'BUY'
        : netDeltaUSD < -whaleTotal * 0.08
        ? 'SELL'
        : 'BALANCED',
    largestPrint: sorted[0] || null,
    topPrints: sorted.slice(0, 6),
    divergence: whales.length === 0 ? 'NO_DATA' : opposesTape ? 'OPPOSES_TAPE' : 'ALIGNED_WITH_TAPE',
  };
}

interface DeribitSummary {
  instrument_name: string;
  open_interest: number;
  mark_iv?: number;
  underlying_price?: number;
}

const MONTHS: Record<string, number> = {
  JAN: 0,
  FEB: 1,
  MAR: 2,
  APR: 3,
  MAY: 4,
  JUN: 5,
  JUL: 6,
  AUG: 7,
  SEP: 8,
  OCT: 9,
  NOV: 10,
  DEC: 11,
};

function normalPDF(x: number): number {
  return Math.exp(-0.5 * x * x) / Math.sqrt(2 * Math.PI);
}

/**
 * Public Deribit options chain -> Black-Scholes gamma -> signed GEX per 1% underlying move.
 * Calls are positive and puts negative by convention; this is exposure, not observed dealer inventory.
 */
export async function fetchDeribitOptionsGamma(
  baseAsset: string,
  spotPrice: number
): Promise<GammaExposureData | null> {
  const currency = baseAsset.toUpperCase();
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 4800);

  try {
    const response = await fetch(
      `https://www.deribit.com/api/v2/public/get_book_summary_by_currency?currency=${encodeURIComponent(
        currency
      )}&kind=option`,
      { signal: controller.signal }
    );
    if (!response.ok) return null;
    const json = await response.json();
    const rows = (json.result || []) as DeribitSummary[];
    if (!Array.isArray(rows) || rows.length < 8) return null;

    const now = Date.now();
    const byStrike = new Map<number, GammaStrikeLevel & { nearestExpiry: number; ivWeight: number; ivSum: number }>();
    let nearestExpiry = Infinity;

    for (const row of rows) {
      const parts = row.instrument_name.split('-');
      if (parts.length !== 4) continue;
      const expiryCode = parts[1];
      const strike = Number(parts[2]);
      const optionType = parts[3];
      const oi = Number(row.open_interest || 0);
      const ivPct = Number(row.mark_iv || 0);
      const S = Number(row.underlying_price || spotPrice);
      if (!strike || !S || oi <= 0 || ivPct <= 0 || (optionType !== 'C' && optionType !== 'P')) continue;

      const day = Number(expiryCode.slice(0, 2));
      const month = MONTHS[expiryCode.slice(2, 5).toUpperCase()];
      const year = 2000 + Number(expiryCode.slice(5, 7));
      if (!day || month === undefined || !year) continue;
      const expiry = Date.UTC(year, month, day, 8, 0, 0);
      const T = (expiry - now) / (365 * 24 * 3600 * 1000);
      if (T <= 0 || T > 0.28) continue; // roughly 100 days: relevant dealer-hedging horizon

      const sigma = ivPct / 100;
      const sqrtT = Math.sqrt(T);
      const d1 = (Math.log(S / strike) + 0.5 * sigma * sigma * T) / (sigma * sqrtT);
      const gamma = normalPDF(d1) / (S * sigma * sqrtT);
      const gex = gamma * oi * S * S * 0.01;
      if (!Number.isFinite(gex)) continue;

      nearestExpiry = Math.min(nearestExpiry, expiry);
      const existing = byStrike.get(strike) || {
        strike,
        callGexUSD: 0,
        putGexUSD: 0,
        netGexUSD: 0,
        openInterest: 0,
        distancePct: ((strike - S) / S) * 100,
        nearestExpiry: expiry,
        ivWeight: 0,
        ivSum: 0,
      };
      if (optionType === 'C') existing.callGexUSD += gex;
      else existing.putGexUSD -= gex;
      existing.netGexUSD = existing.callGexUSD + existing.putGexUSD;
      existing.openInterest += oi;
      existing.nearestExpiry = Math.min(existing.nearestExpiry, expiry);
      if (Math.abs(Math.log(strike / S)) < 0.035) {
        existing.ivWeight += oi;
        existing.ivSum += ivPct * oi;
      }
      byStrike.set(strike, existing);
    }

    const allLevels = [...byStrike.values()].sort((a, b) => a.strike - b.strike);
    if (allLevels.length < 4) return null;

    const callGexUSD = allLevels.reduce((sum, l) => sum + l.callGexUSD, 0);
    const putGexUSD = allLevels.reduce((sum, l) => sum + l.putGexUSD, 0);
    const netGexUSD = callGexUSD + putGexUSD;
    const gross = callGexUSD + Math.abs(putGexUSD);
    const signedRatio = gross > 0 ? netGexUSD / gross : 0;

    const callWall = [...allLevels].sort((a, b) => b.callGexUSD - a.callGexUSD)[0]?.strike || spotPrice;
    const putWall = [...allLevels].sort((a, b) => a.putGexUSD - b.putGexUSD)[0]?.strike || spotPrice;

    // Cumulative signed GEX zero-crossing, nearest to spot when multiple crossings exist.
    const crossings: number[] = [];
    let cumulative = 0;
    for (let i = 0; i < allLevels.length; i++) {
      const previous = cumulative;
      cumulative += allLevels[i].netGexUSD;
      if (i > 0 && Math.sign(previous) !== Math.sign(cumulative) && previous !== 0) {
        const left = allLevels[i - 1].strike;
        const right = allLevels[i].strike;
        const fraction = Math.abs(previous) / Math.max(1e-9, Math.abs(previous) + Math.abs(cumulative));
        crossings.push(left + (right - left) * fraction);
      }
    }
    const gammaFlip = crossings.length
      ? crossings.sort((a, b) => Math.abs(a - spotPrice) - Math.abs(b - spotPrice))[0]
      : spotPrice;

    const ivLevels = allLevels.filter((l) => l.ivWeight > 0);
    const atmIV = ivLevels.length
      ? ivLevels.reduce((sum, l) => sum + l.ivSum, 0) / ivLevels.reduce((sum, l) => sum + l.ivWeight, 0)
      : 0;

    const levels = allLevels
      .map(({ ivWeight: _ivWeight, ivSum: _ivSum, nearestExpiry: _nearestExpiry, ...level }) => level)
      .sort((a, b) => Math.abs(a.strike - spotPrice) - Math.abs(b.strike - spotPrice))
      .slice(0, 14)
      .sort((a, b) => b.strike - a.strike);

    const regime: GammaExposureData['regime'] =
      signedRatio > 0.07 ? 'POSITIVE_GAMMA' : signedRatio < -0.07 ? 'NEGATIVE_GAMMA' : 'NEUTRAL_GAMMA';

    return {
      source: 'DERIBIT_OPTIONS_LIVE',
      sourceLabel: 'DERIBIT OPTIONS OI + MARK IV',
      isProxy: false,
      regime,
      netGexUSD,
      callGexUSD,
      putGexUSD,
      gammaFlip,
      callWall,
      putWall,
      spotPrice,
      atmIV,
      nearestExpiry: Number.isFinite(nearestExpiry) ? nearestExpiry : 0,
      levels,
      description:
        regime === 'POSITIVE_GAMMA'
          ? 'Call-positive GEX convention: hedging may dampen movement near high-gamma strikes; walls can act as magnets.'
          : regime === 'NEGATIVE_GAMMA'
          ? 'Put-negative GEX convention: hedging may amplify movement away from flip; breakout targets need confirmation.'
          : 'Call and put gamma are balanced; use flip and walls as levels, not a standalone directional signal.',
      updatedAt: Date.now(),
    };
  } catch {
    return null;
  } finally {
    clearTimeout(timeout);
  }
}

/** Honest fallback for assets without a public options chain: estimates hedging regime from futures data only. */
export function buildFuturesGammaProxy(
  klines: KlineOrderflow[],
  spotPrice: number,
  bidDepthUSD: number,
  askDepthUSD: number
): GammaExposureData {
  const bars = klines.slice(-24);
  const returns = bars.slice(1).map((bar, i) => {
    const previous = bars[i].close;
    return previous > 0 ? Math.log(bar.close / previous) : 0;
  });
  const mean = returns.length ? returns.reduce((a, b) => a + b, 0) / returns.length : 0;
  const variance = returns.length
    ? returns.reduce((sum, r) => sum + Math.pow(r - mean, 2), 0) / returns.length
    : 0;
  const barVolPct = Math.sqrt(variance) * 100;
  const totalDepth = bidDepthUSD + askDepthUSD;
  const oiTrend = bars.length > 1 ? bars[bars.length - 1].openInterestUSD - bars[0].openInterestUSD : 0;
  const expansion = bars.length > 1 ? Math.abs(bars[bars.length - 1].close / bars[0].close - 1) : 0;
  const stability = clamp(1 - barVolPct / 0.8, -1, 1);
  const depthImbalance = totalDepth > 0 ? (bidDepthUSD - askDepthUSD) / totalDepth : 0;
  const proxyScore = stability * 0.7 - Math.sign(oiTrend) * expansion * 4;
  const regime: GammaExposureData['regime'] =
    proxyScore > 0.12 ? 'POSITIVE_GAMMA' : proxyScore < -0.12 ? 'NEGATIVE_GAMMA' : 'NEUTRAL_GAMMA';
  const proxyGex = totalDepth * proxyScore * 0.08;
  const vwap = bars[bars.length - 1]?.vwap || spotPrice;
  const offset = Math.max(spotPrice * 0.006, spotPrice * (barVolPct / 100) * 2.5);
  const callWall = spotPrice + offset * (depthImbalance < 0 ? 0.8 : 1.2);
  const putWall = spotPrice - offset * (depthImbalance > 0 ? 0.8 : 1.2);
  const levels: GammaStrikeLevel[] = [-2, -1, 0, 1, 2].map((step) => {
    const strike = spotPrice + step * offset * 0.5;
    const concentration = Math.exp(-Math.abs(step) * 0.55);
    const callGexUSD = Math.max(0, proxyGex) * concentration * 0.32;
    const putGexUSD = Math.min(0, proxyGex) * concentration * 0.32;
    return {
      strike,
      callGexUSD,
      putGexUSD,
      netGexUSD: callGexUSD + putGexUSD,
      openInterest: 0,
      distancePct: ((strike - spotPrice) / spotPrice) * 100,
    };
  });

  return {
    source: 'FUTURES_GAMMA_PROXY',
    sourceLabel: 'FUTURES VOL/OI/DEPTH PROXY — NOT OPTIONS GEX',
    isProxy: true,
    regime,
    netGexUSD: proxyGex,
    callGexUSD: Math.max(0, proxyGex) * 0.65,
    putGexUSD: Math.min(0, proxyGex) * 0.65,
    gammaFlip: vwap,
    callWall,
    putWall,
    spotPrice,
    atmIV: barVolPct * Math.sqrt(24),
    nearestExpiry: 0,
    levels: levels.reverse(),
    description:
      'No liquid public option chain loaded. This proxy uses futures realized volatility, OI expansion and L2 depth; it never represents measured options dealer gamma.',
    updatedAt: Date.now(),
  };
}
