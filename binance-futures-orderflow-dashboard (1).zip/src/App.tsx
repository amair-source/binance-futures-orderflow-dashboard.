import { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import {
  Timeframe,
  AssetTicker,
  LiveAggTrade,
  ChartOverlayConfig,
  GammaExposureData,
} from './types/orderflow';
import {
  DEFAULT_FUTURES_ASSETS,
  RawKlineBar,
  fetchAllBinanceFuturesSymbols,
  fetchAssetOrderflowSnapshot,
  getAssetMeta,
} from './services/binanceFuturesService';
import {
  buildEnrichedKlines,
  computeVolumeProfile,
  computeAutoFibonacci,
  analyzeOrderbookAndWalls,
  analyzeOIRegime,
  generateTradeSetup,
  roundToTick,
} from './services/orderflowEngine';
import { TopTelemetryBar } from './components/TopTelemetryBar';
import { MainOrderflowCanvas } from './components/MainOrderflowCanvas';
import { SynchronizedSubCharts } from './components/SynchronizedSubCharts';
import { OrderbookWallsScanner } from './components/OrderbookWallsScanner';
import { TradeSetupCard } from './components/TradeSetupCard';
import { KeyLevelsSummaryStrip } from './components/KeyLevelsSummaryStrip';
import { AdvancedFlowWorkspace } from './components/AdvancedFlowWorkspace';
import {
  analyzeLiquidityHeatmap,
  analyzeAggressiveTape,
  analyzeWhaleFlow,
  fetchDeribitOptionsGamma,
  buildFuturesGammaProxy,
} from './services/advancedFlowEngine';

export function App() {
  const [symbol, setSymbol] = useState<string>('BTCUSDT');
  const [timeframe, setTimeframe] = useState<Timeframe>('5m');
  const [allSymbols, setAllSymbols] = useState<string[]>(
    DEFAULT_FUTURES_ASSETS.map((a) => a.symbol)
  );
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [wsConnected, setWsConnected] = useState<boolean>(false);
  const [connectionSource, setConnectionSource] = useState<
    'BINANCE_FAPI_LIVE' | 'BINANCE_VISION_MIRROR' | 'SYNTHETIC_FALLBACK'
  >('BINANCE_FAPI_LIVE');

  const meta = getAssetMeta(symbol);

  const [ticker, setTicker] = useState<AssetTicker>({
    symbol: meta.symbol,
    baseAsset: meta.baseAsset,
    quoteAsset: 'USDT',
    lastPrice: meta.defaultPrice,
    markPrice: meta.defaultPrice,
    indexPrice: meta.defaultPrice,
    priceChangePct24h: 2.15,
    high24h: meta.defaultPrice * 1.025,
    low24h: meta.defaultPrice * 0.975,
    volume24hUSD: meta.defaultOIUSD * 1.4,
    openInterestUSD: meta.defaultOIUSD,
    openInterestContracts: meta.defaultOIUSD / meta.defaultPrice,
    fundingRate: 0.0001,
    nextFundingTime: Date.now() + 3600_000 * 4,
    tickSize: meta.tickSize,
    pricePrecision: meta.pricePrecision,
  });

  const [rawKlines, setRawKlines] = useState<RawKlineBar[]>([]);
  const [oiHistoryMap, setOiHistoryMap] = useState<Map<number, number>>(new Map());
  const [rawOrderbook, setRawOrderbook] = useState<{
    bids: [number, number][];
    asks: [number, number][];
  }>({ bids: [], asks: [] });
  const [recentTrades, setRecentTrades] = useState<LiveAggTrade[]>([]);
  const [liveGamma, setLiveGamma] = useState<GammaExposureData | null>(null);
  const gammaRequestRef = useRef<number>(0);

  // Tracks aggressive market volume absorbed at specific rounded price levels to detect Iceberg orders
  const absorptionTrackerRef = useRef<
    Map<number, { absorbedUSD: number; refillCount: number }>
  >(new Map());

  const [overlays, setOverlays] = useState<ChartOverlayConfig>({
    showHeatmap: true,
    showVolumeProfile: true,
    showVWAP: true,
    showFib: true,
    showLimitWalls: true,
    showIcebergs: true,
    showTradeSetup: true,
    showFootprintImbalances: true,
  });

  const handleToggleOverlay = (key: keyof ChartOverlayConfig) => {
    setOverlays((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  // Fetch all available Binance USDT-M Perpetual contracts on mount
  useEffect(() => {
    fetchAllBinanceFuturesSymbols().then((list) => {
      if (list && list.length > 0) setAllSymbols(list);
    });
  }, []);

  // Load Orderflow Snapshot for selected Symbol + Timeframe
  const loadSnapshot = useCallback(async () => {
    setIsLoading(true);
    absorptionTrackerRef.current.clear();

    const bundle = await fetchAssetOrderflowSnapshot(symbol, timeframe);
    setConnectionSource(bundle.source);
    setTicker(bundle.ticker);
    setRawKlines(bundle.klines);
    setOiHistoryMap(bundle.oiHistoryMap);
    setRawOrderbook(bundle.orderbook);
    setRecentTrades(bundle.recentTrades);

    // Load real public options chain when the asset has one; otherwise the UI explicitly uses a futures proxy.
    const gammaRequestId = ++gammaRequestRef.current;
    setLiveGamma(null);
    void fetchDeribitOptionsGamma(bundle.ticker.baseAsset, bundle.ticker.lastPrice).then((gamma) => {
      if (gamma && gammaRequestRef.current === gammaRequestId) setLiveGamma(gamma);
    });

    // Seed Iceberg Absorption tracker from recent trades & orderbook walls
    const step = bundle.ticker.tickSize * 5;
    bundle.recentTrades.forEach((tr) => {
      const bucketPrice = roundToTick(tr.price, step);
      const prev = absorptionTrackerRef.current.get(bucketPrice) || {
        absorbedUSD: 0,
        refillCount: 0,
      };
      absorptionTrackerRef.current.set(bucketPrice, {
        absorbedUSD: prev.absorbedUSD + tr.notionalUSD,
        refillCount: prev.refillCount + 1,
      });
    });

    setIsLoading(false);
  }, [symbol, timeframe]);

  useEffect(() => {
    loadSnapshot();
  }, [loadSnapshot]);

  // Connect to Live Binance Futures WebSocket Streams (@aggTrade, @depth20@100ms, @kline)
  useEffect(() => {
    let ws: WebSocket | null = null;
    let fallbackTimer: ReturnType<typeof setInterval> | null = null;
    let isDisposed = false;
    let socketAlive = false;

    const lowerSym = symbol.toLowerCase();
    const primaryWsUrl = `wss://fstream.binance.com/stream?streams=${lowerSym}@aggTrade/${lowerSym}@depth20@100ms/${lowerSym}@kline_${timeframe}`;
    const mirrorWsUrl = `wss://data-stream.binance.vision/stream?streams=${lowerSym}@aggTrade/${lowerSym}@depth20@100ms/${lowerSym}@kline_${timeframe}`;

    const attachMessageHandler = (socket: WebSocket) => {
      socket.onopen = () => {
        socketAlive = true;
        if (!isDisposed) setWsConnected(true);
      };
      socket.onclose = () => {
        socketAlive = false;
        if (!isDisposed) setWsConnected(false);
      };

      socket.onmessage = (event) => {
        if (isDisposed) return;
        try {
          const payload = JSON.parse(event.data);
          const data = payload.data;
          if (!data) return;

          // 1. Live AggTrade Stream (Footprint & Iceberg Absorption + Tape)
          if (data.e === 'aggTrade') {
            const price = parseFloat(data.p);
            const qty = parseFloat(data.q);
            const notionalUSD = price * qty;
            const isBuyerMaker = Boolean(data.m);

            const trade: LiveAggTrade = {
              id: Number(data.a || Date.now()),
              price,
              qty,
              notionalUSD,
              time: Number(data.T || Date.now()),
              isBuyerMaker,
              isWhale: notionalUSD >= 25_000,
            };

            setTicker((prev) => ({
              ...prev,
              lastPrice: price,
              markPrice: price,
            }));

            setRecentTrades((prev) => [trade, ...prev.slice(0, 199)]);

            // Track Iceberg Absorption at price level
            const bucket = roundToTick(price, meta.tickSize * 5);
            const existing = absorptionTrackerRef.current.get(bucket) || {
              absorbedUSD: 0,
              refillCount: 0,
            };
            absorptionTrackerRef.current.set(bucket, {
              absorbedUSD: existing.absorbedUSD + notionalUSD,
              refillCount: existing.refillCount + 1,
            });
          }

          // 2. Live Depth20@100ms Orderbook Stream (Limit Walls & DOM)
          if (data.e === 'depthUpdate' || (Array.isArray(data.b) && Array.isArray(data.a)) || (Array.isArray(data.bids) && Array.isArray(data.asks))) {
            const rawB = data.b || data.bids || [];
            const rawA = data.a || data.asks || [];
            if (rawB.length > 0 && rawA.length > 0) {
              const bids: [number, number][] = rawB
                .map((b: string[]) => [parseFloat(b[0]), parseFloat(b[1])] as [number, number])
                .filter((b: [number, number]) => b[1] > 0);
              const asks: [number, number][] = rawA
                .map((a: string[]) => [parseFloat(a[0]), parseFloat(a[1])] as [number, number])
                .filter((a: [number, number]) => a[1] > 0);
              if (bids.length > 5 && asks.length > 5) {
                setRawOrderbook({ bids, asks });
              }
            }
          }

          // 3. Live Kline Stream (Updates Latest Candle Volume, Taker Buy Vol & Delta)
          if (data.e === 'kline' && data.k) {
            const k = data.k;
            const updatedBar: RawKlineBar = {
              time: Number(k.t),
              open: parseFloat(k.o),
              high: parseFloat(k.h),
              low: parseFloat(k.l),
              close: parseFloat(k.c),
              volume: parseFloat(k.v),
              quoteVolume: parseFloat(k.q),
              takerBuyQuoteVolume: parseFloat(k.Q),
            };

            setRawKlines((prev) => {
              if (prev.length === 0) return [updatedBar];
              const last = prev[prev.length - 1];
              if (last.time === updatedBar.time) {
                return [...prev.slice(0, -1), updatedBar];
              }
              return [...prev.slice(1), updatedBar];
            });
          }
        } catch {
          // Ignore malformed frame
        }
      };
    };

    try {
      ws = new WebSocket(
        connectionSource === 'BINANCE_FAPI_LIVE' ? primaryWsUrl : mirrorWsUrl
      );
      attachMessageHandler(ws);
      ws.onerror = () => {
        socketAlive = false;
        if (isDisposed) return;
        setWsConnected(false);
      };
    } catch {
      setWsConnected(false);
    }

    // If streaming is blocked, revalidate through open REST endpoints. Never invent live ticks.
    fallbackTimer = setInterval(() => {
      if (!isDisposed && !socketAlive) void loadSnapshot();
    }, 20000);

    return () => {
      isDisposed = true;
      if (ws) {
        try {
          ws.close();
        } catch {
          // ignore
        }
      }
      if (fallbackTimer) clearInterval(fallbackTimer);
    };
  }, [symbol, timeframe, connectionSource, meta.tickSize]);

  // 1. Enrich Klines with Footprint Clusters, Heatmap Slices, CVD, Delta, VWAP ±1σ/2σ, and Open Interest
  const enrichedKlines = useMemo(() => {
    return buildEnrichedKlines(
      rawKlines,
      oiHistoryMap,
      rawOrderbook,
      ticker.openInterestUSD
    );
  }, [rawKlines, oiHistoryMap, rawOrderbook, ticker.openInterestUSD]);

  // 2. Compute Session Volume Profile (POC, VAH 70%, VAL 70%)
  const volumeProfile = useMemo(() => {
    return computeVolumeProfile(enrichedKlines, 40);
  }, [enrichedKlines]);

  // 3. Compute Auto-Fibonacci Retracement Levels & Golden Pocket (0.618 - 0.65)
  const fib = useMemo(() => {
    return computeAutoFibonacci(enrichedKlines);
  }, [enrichedKlines]);

  // 4. Analyze Orderbook Depth, Resting Limit Walls (≥1.8σ-4σ) & Iceberg Absorption
  const orderbookAnalysis = useMemo(() => {
    return analyzeOrderbookAndWalls(
      rawOrderbook.bids,
      rawOrderbook.asks,
      ticker.lastPrice,
      absorptionTrackerRef.current,
      ticker.tickSize * 5
    );
  }, [rawOrderbook, ticker.lastPrice, ticker.tickSize, recentTrades]);

  // 5. Analyze Open Interest & CVD Regime Matrix
  const oiRegime = useMemo(() => {
    return analyzeOIRegime(enrichedKlines);
  }, [enrichedKlines]);

  // 6. Dedicated pre-trade evidence: heatmap persistence, aggressive tape, adaptive whales and gamma.
  const heatmapAnalysis = useMemo(
    () => analyzeLiquidityHeatmap(enrichedKlines, ticker.lastPrice),
    [enrichedKlines, ticker.lastPrice]
  );
  const tapeAnalysis = useMemo(() => analyzeAggressiveTape(recentTrades), [recentTrades]);
  const whaleFlow = useMemo(
    () => analyzeWhaleFlow(recentTrades, tapeAnalysis, ticker.volume24hUSD),
    [recentTrades, tapeAnalysis, ticker.volume24hUSD]
  );
  const futuresGammaProxy = useMemo(
    () =>
      buildFuturesGammaProxy(
        enrichedKlines,
        ticker.lastPrice,
        orderbookAnalysis.bidTotalUSD,
        orderbookAnalysis.askTotalUSD
      ),
    [enrichedKlines, ticker.lastPrice, orderbookAnalysis.bidTotalUSD, orderbookAnalysis.askTotalUSD]
  );
  const gammaExposure = liveGamma || futuresGammaProxy;

  // 7. Synthesize Algorithmic Trade Setup only after ALL evidence groups are scored
  const tradeSetup = useMemo(() => {
    return generateTradeSetup({
      symbol: ticker.symbol,
      timeframe,
      klines: enrichedKlines,
      volumeProfile,
      fib,
      walls: orderbookAnalysis.walls,
      oiRegime,
      orderbookImbalancePct: orderbookAnalysis.imbalancePct,
      tickSize: ticker.tickSize,
      heatmap: heatmapAnalysis,
      tape: tapeAnalysis,
      whales: whaleFlow,
      gamma: gammaExposure,
      fundingRate: ticker.fundingRate,
      marketDataSource: connectionSource,
    });
  }, [
    ticker.symbol,
    ticker.tickSize,
    timeframe,
    enrichedKlines,
    volumeProfile,
    fib,
    orderbookAnalysis.walls,
    orderbookAnalysis.imbalancePct,
    oiRegime,
    heatmapAnalysis,
    tapeAnalysis,
    whaleFlow,
    gammaExposure,
    ticker.fundingRate,
    connectionSource,
  ]);

  const latestBar = enrichedKlines[enrichedKlines.length - 1];
  const currentVWAP = latestBar?.vwap || ticker.lastPrice;
  const currentCVD = latestBar?.cvd || 0;

  return (
    <div className="min-h-screen bg-[#07090E] text-[#F1F5F9] flex flex-col">
      {/* Top Institutional Telemetry & Asset Command Bar */}
      <TopTelemetryBar
        ticker={ticker}
        timeframe={timeframe}
        onSelectSymbol={setSymbol}
        onSelectTimeframe={setTimeframe}
        allSymbols={allSymbols}
        volumeProfile={volumeProfile}
        currentVWAP={currentVWAP}
        currentCVD={currentCVD}
        connectionSource={connectionSource}
        wsConnected={wsConnected}
        onRefresh={loadSnapshot}
        isLoading={isLoading}
      />

      {/* Main High-Density 12-Column Quantitative Terminal Grid */}
      <main className="flex-1 p-2.5 grid grid-cols-1 xl:grid-cols-12 gap-2.5 max-w-[1920px] w-full mx-auto">
        {/* LEFT & CENTER WORKSPACE (8 COLUMNS): Heatmap/Footprint/VP Canvas + Sub-Oscillators + Key Levels Matrix */}
        <div className="xl:col-span-8 flex flex-col gap-2.5 min-w-0">
          {/* Primary Multi-Layer Orderflow Canvas */}
          <MainOrderflowCanvas
            symbol={ticker.symbol}
            tickSize={ticker.tickSize}
            klines={enrichedKlines}
            volumeProfile={volumeProfile}
            fib={fib}
            walls={orderbookAnalysis.walls}
            tradeSetup={tradeSetup}
            overlays={overlays}
            onToggleOverlay={handleToggleOverlay}
          />

          {/* Synchronized CVD, Bar Delta & Open Interest Sub-Charts */}
          <SynchronizedSubCharts klines={enrichedKlines} oiRegime={oiRegime} />

          {/* Structured Key Levels Matrix (POC, VAH, VAL, VWAP, Fib GP, Limit & Iceberg Walls) */}
          <KeyLevelsSummaryStrip
            symbol={ticker.symbol}
            lastPrice={ticker.lastPrice}
            tickSize={ticker.tickSize}
            vwap={currentVWAP}
            vwapUpper1={latestBar?.vwapUpper1 || ticker.lastPrice * 1.005}
            vwapLower1={latestBar?.vwapLower1 || ticker.lastPrice * 0.995}
            volumeProfile={volumeProfile}
            fib={fib}
            walls={orderbookAnalysis.walls}
            onSelectSymbol={setSymbol}
          />
        </div>

        {/* RIGHT INTELLIGENCE & EXECUTION DOCK (4 COLUMNS): Algorithmic Trade Setup Generator + Limit/Iceberg Wall Scanner */}
        <div className="xl:col-span-4 flex flex-col gap-2.5 min-w-0">
          {/* Synthesized Trade Setup & Multi-Factor Confluence Engine */}
          <TradeSetupCard
            setup={tradeSetup}
            tickSize={ticker.tickSize}
            baseAsset={ticker.baseAsset}
          />

          {/* L2 Orderbook Depth, Limit Walls (≥2.5σ) & Iceberg Absorption Scanner */}
          <OrderbookWallsScanner
            symbol={ticker.symbol}
            lastPrice={ticker.lastPrice}
            tickSize={ticker.tickSize}
            bids={orderbookAnalysis.bids}
            asks={orderbookAnalysis.asks}
            walls={orderbookAnalysis.walls}
            bidTotalUSD={orderbookAnalysis.bidTotalUSD}
            askTotalUSD={orderbookAnalysis.askTotalUSD}
            imbalancePct={orderbookAnalysis.imbalancePct}
            recentTrades={recentTrades}
          />
        </div>

        {/* Full-width evidence row: every panel below also feeds the execution gate above. */}
        <div className="xl:col-span-12 min-w-0">
          <AdvancedFlowWorkspace
            heatmap={heatmapAnalysis}
            tape={tapeAnalysis}
            whales={whaleFlow}
            gamma={gammaExposure}
            setup={tradeSetup}
            tickSize={ticker.tickSize}
          />
        </div>
      </main>
    </div>
  );
}

export default App;
