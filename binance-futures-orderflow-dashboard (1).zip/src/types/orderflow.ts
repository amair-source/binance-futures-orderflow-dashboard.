export type Timeframe = '1m' | '5m' | '15m' | '1h' | '4h';

export interface AssetTicker {
  symbol: string;
  baseAsset: string;
  quoteAsset: string;
  lastPrice: number;
  markPrice: number;
  indexPrice: number;
  priceChangePct24h: number;
  high24h: number;
  low24h: number;
  volume24hUSD: number;
  openInterestUSD: number;
  openInterestContracts: number;
  fundingRate: number;
  nextFundingTime: number;
  tickSize: number;
  pricePrecision: number;
}

export interface FootprintRow {
  price: number;
  bidVol: number; // Aggressive sell hitting bid (USD)
  askVol: number; // Aggressive buy lifting ask (USD)
  delta: number;  // askVol - bidVol
  totalVol: number;
  imbalanceBid: boolean; // bidVol >= askVol * 3.0
  imbalanceAsk: boolean; // askVol >= bidVol * 3.0
  isPOC: boolean;
}

export interface HeatmapCell {
  price: number;
  restingLiquidityUSD: number;
  side: 'BID' | 'ASK';
  intensity: number; // 0 to 1 normalized for thermal colormap
  isLimitWall: boolean;
  isIceberg: boolean;
}

export interface KlineOrderflow {
  time: number; // unix ms
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number; // base asset
  quoteVolume: number; // USD volume
  buyVolumeUSD: number; // taker buy quote volume
  sellVolumeUSD: number; // taker sell quote volume
  delta: number; // buyVolumeUSD - sellVolumeUSD
  cvd: number; // cumulative volume delta USD
  vwap: number;
  vwapUpper1: number;
  vwapLower1: number;
  vwapUpper2: number;
  vwapLower2: number;
  openInterestUSD: number;
  oiDeltaUSD: number;
  oiDeltaPct: number;
  footprint: FootprintRow[];
  pocPrice: number;
  unfinishedAuctionHigh: boolean;
  unfinishedAuctionLow: boolean;
  heatmapSlice: HeatmapCell[];
}

export interface VolumeProfileRow {
  price: number;
  priceLow: number;
  priceHigh: number;
  buyVolUSD: number;
  sellVolUSD: number;
  totalVolUSD: number;
  deltaUSD: number;
  pctOfMax: number;
  inValueArea: boolean;
  isPOC: boolean;
  isVAH: boolean;
  isVAL: boolean;
}

export interface VolumeProfileData {
  rows: VolumeProfileRow[];
  poc: number;
  vah: number;
  val: number;
  totalVolumeUSD: number;
  valueAreaVolumePct: number;
}

export interface FibLevel {
  ratio: number;
  label: string;
  price: number;
  isGoldenPocket: boolean;
}

export interface FibonacciData {
  swingHigh: number;
  swingLow: number;
  swingHighTime: number;
  swingLowTime: number;
  trend: 'BULLISH' | 'BEARISH'; // Bullish = retracing down from high after impulse up; Bearish = retracing up from low
  levels: FibLevel[];
  goldenPocketHigh: number;
  goldenPocketLow: number;
}

export interface OrderbookLevel {
  price: number;
  quantity: number;
  notionalUSD: number;
  cumulativeUSD: number;
  pctOfMax: number;
  zScore: number;
  isWall: boolean;
  isIceberg: boolean;
  absorbedUSD: number;
}

export interface OrderbookWall {
  id: string;
  price: number;
  sizeContracts: number;
  sizeUSD: number;
  side: 'BID' | 'ASK';
  type: 'LIMIT_WALL' | 'ICEBERG_ABSORPTION';
  zScore: number;
  absorbedUSD: number;
  refillCount: number;
  distancePct: number;
  strength: 'EXTREME' | 'HIGH' | 'MODERATE';
  timestamp: number;
}

export interface LiveAggTrade {
  id: number;
  price: number;
  qty: number;
  notionalUSD: number;
  time: number;
  isBuyerMaker: boolean; // true = Market SELL (hit bid), false = Market BUY (lifted ask)
  isWhale: boolean;
}

export interface OIRegimeAnalysis {
  dataAvailable: boolean;
  regime: 'LONG_BUILD' | 'SHORT_BUILD' | 'SHORT_SQUEEZE' | 'LONG_LIQUIDATION' | 'NEUTRAL';
  regimeLabel: string;
  priceChangePct: number;
  oiChangePct: number;
  oiChangeUSD: number;
  cvdChangeUSD: number;
  cvdDivergence: 'BULLISH_ABSORPTION' | 'BEARISH_EXHAUSTION' | 'CONFIRMED_BULL' | 'CONFIRMED_BEAR' | 'NONE';
  divergenceDescription: string;
  netDeltaSessionUSD: number;
  buySellRatio: number;
}

export interface HeatmapZone {
  id: string;
  price: number;
  side: 'BID' | 'ASK';
  averageIntensity: number;
  currentIntensity: number;
  persistencePct: number;
  averageLiquidityUSD: number;
  currentLiquidityUSD: number;
  distancePct: number;
  activeBars: number;
}

export interface HeatmapAnalysis {
  zones: HeatmapZone[];
  bidLiquidityUSD: number;
  askLiquidityUSD: number;
  imbalancePct: number;
  dominantSide: 'BID' | 'ASK' | 'BALANCED';
  nearestBidZone: HeatmapZone | null;
  nearestAskZone: HeatmapZone | null;
  modelLabel: string;
}

export interface TapeAnalysis {
  windowMs: number;
  tradeCount: number;
  buyVolumeUSD: number;
  sellVolumeUSD: number;
  netDeltaUSD: number;
  buySellRatio: number;
  buyVolumePct: number;
  priceChangePct: number;
  averageTradeUSD: number;
  tradesPerMinute: number;
  largestPrintUSD: number;
  state: 'BUYERS_IN_CONTROL' | 'SELLERS_IN_CONTROL' | 'BID_ABSORPTION' | 'ASK_ABSORPTION' | 'BALANCED' | 'NO_DATA';
  stateLabel: string;
  absorptionDetected: boolean;
}

export interface WhaleFlowAnalysis {
  thresholdUSD: number;
  whaleCount: number;
  buyCount: number;
  sellCount: number;
  buyVolumeUSD: number;
  sellVolumeUSD: number;
  netDeltaUSD: number;
  whaleVolumePct: number;
  dominantSide: 'BUY' | 'SELL' | 'BALANCED' | 'NO_DATA';
  largestPrint: LiveAggTrade | null;
  topPrints: LiveAggTrade[];
  divergence: 'ALIGNED_WITH_TAPE' | 'OPPOSES_TAPE' | 'NO_DATA';
}

export interface GammaStrikeLevel {
  strike: number;
  callGexUSD: number;
  putGexUSD: number;
  netGexUSD: number;
  openInterest: number;
  distancePct: number;
}

export interface GammaExposureData {
  source: 'DERIBIT_OPTIONS_LIVE' | 'FUTURES_GAMMA_PROXY';
  sourceLabel: string;
  isProxy: boolean;
  regime: 'POSITIVE_GAMMA' | 'NEGATIVE_GAMMA' | 'NEUTRAL_GAMMA';
  netGexUSD: number;
  callGexUSD: number;
  putGexUSD: number;
  gammaFlip: number;
  callWall: number;
  putWall: number;
  spotPrice: number;
  atmIV: number;
  nearestExpiry: number;
  levels: GammaStrikeLevel[];
  description: string;
  updatedAt: number;
}

export interface ConfluenceFactor {
  id: string;
  category: 'VALUE_AREA' | 'VWAP' | 'CVD_DELTA' | 'OI_REGIME' | 'LIQUIDITY_WALLS' | 'FIB_FOOTPRINT' | 'HEATMAP' | 'TAPE' | 'WHALES' | 'GAMMA' | 'FUNDING';
  title: string;
  metricValue: string;
  signal: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  weight: number;
  passed: boolean;
  detail: string;
}

export interface TradeSetup {
  symbol: string;
  timeframe: Timeframe;
  generatedAt: number;
  direction: 'LONG' | 'SHORT' | 'NEUTRAL';
  biasScore: number; // -100 to +100
  confidence: number; // 0 to 100
  setupGrade: 'A+' | 'A' | 'B+' | 'B' | 'WAIT';
  entryType: string;
  entryOrderType: 'LIMIT' | 'STOP-MARKET' | 'MARKET-ABSORPTION';
  entryPrice: number;
  entryZone: [number, number];
  stopLoss: number;
  stopLossReason: string;
  tp1: number;
  tp1Reason: string;
  tp2: number;
  tp2Reason: string;
  tp3: number;
  tp3Reason: string;
  rr1: number;
  rr2: number;
  rr3: number;
  riskPct: number;
  rewardPct: number;
  invalidationLevel: number;
  confluenceFactors: ConfluenceFactor[];
  thesisSummary: string;
  status: 'ACTIONABLE' | 'WAIT';
  blockedReasons: string[];
  factorsEvaluated: number;
  factorsAligned: number;
  minimumRR: number;
}

export interface ChartOverlayConfig {
  showHeatmap: boolean;
  showVolumeProfile: boolean;
  showVWAP: boolean;
  showFib: boolean;
  showLimitWalls: boolean;
  showIcebergs: boolean;
  showTradeSetup: boolean;
  showFootprintImbalances: boolean;
}
