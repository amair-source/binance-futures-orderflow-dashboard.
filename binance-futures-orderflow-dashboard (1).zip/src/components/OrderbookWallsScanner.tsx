import React, { useState } from 'react';
import {
  Shield,
  Snowflake,
  ArrowUpRight,
  ArrowDownRight,
} from 'lucide-react';
import {
  OrderbookLevel,
  OrderbookWall,
  LiveAggTrade,
} from '../types/orderflow';
import { formatPrice, formatUSD } from '../services/orderflowEngine';

interface OrderbookWallsScannerProps {
  symbol: string;
  lastPrice: number;
  tickSize: number;
  bids: OrderbookLevel[];
  asks: OrderbookLevel[];
  walls: OrderbookWall[];
  bidTotalUSD: number;
  askTotalUSD: number;
  imbalancePct: number;
  recentTrades: LiveAggTrade[];
}

type ScannerTab = 'WALLS_ICEBERGS' | 'DOM_LADDER' | 'LIVE_TAPE';

export const OrderbookWallsScanner: React.FC<OrderbookWallsScannerProps> = ({
  symbol,
  lastPrice,
  tickSize,
  bids,
  asks,
  walls,
  bidTotalUSD,
  askTotalUSD,
  imbalancePct,
  recentTrades,
}) => {
  const [activeTab, setActiveTab] = useState<ScannerTab>('WALLS_ICEBERGS');

  const totalBook = bidTotalUSD + askTotalUSD || 1;
  const bidShare = (bidTotalUSD / totalBook) * 100;
  const askShare = 100 - bidShare;

  const askWalls = walls.filter((w) => w.side === 'ASK').sort((a, b) => a.price - b.price);
  const bidWalls = walls.filter((w) => w.side === 'BID').sort((a, b) => b.price - a.price);

  return (
    <div className="bg-[#0B0E17] border border-[#1E2638] rounded-sm flex flex-col overflow-hidden">
      {/* Scanner Header */}
      <div className="px-3 py-2 bg-[#111622] border-b border-[#1E2638] flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <Snowflake className="w-3.5 h-3.5 text-[#00F0FF]" />
          <span className="font-display font-bold text-xs uppercase tracking-wider text-[#F1F5F9]">
            Ice Walls, Limit Walls & L2 Depth
          </span>
        </div>

        {/* Sub-navigation Tabs */}
        <div className="flex items-center gap-1 bg-[#07090E] p-0.5 rounded border border-[#1E2638] text-[10px] font-mono-tabular">
          <button
            onClick={() => setActiveTab('WALLS_ICEBERGS')}
            className={`px-2 py-0.5 rounded cursor-pointer transition-colors ${
              activeTab === 'WALLS_ICEBERGS'
                ? 'bg-[#00F0FF]/20 text-[#00F0FF] font-semibold'
                : 'text-[#64748B] hover:text-[#94A3B8]'
            }`}
          >
            WALLS & ICE ({walls.length})
          </button>
          <button
            onClick={() => setActiveTab('DOM_LADDER')}
            className={`px-2 py-0.5 rounded cursor-pointer transition-colors ${
              activeTab === 'DOM_LADDER'
                ? 'bg-[#00F0FF]/20 text-[#00F0FF] font-semibold'
                : 'text-[#64748B] hover:text-[#94A3B8]'
            }`}
          >
            DOM
          </button>
          <button
            onClick={() => setActiveTab('LIVE_TAPE')}
            className={`px-2 py-0.5 rounded cursor-pointer transition-colors ${
              activeTab === 'LIVE_TAPE'
                ? 'bg-[#00F0FF]/20 text-[#00F0FF] font-semibold'
                : 'text-[#64748B] hover:text-[#94A3B8]'
            }`}
          >
            TAPE
          </button>
        </div>
      </div>

      {/* Top L2 Book Bid/Ask Imbalance Gauge */}
      <div className="px-3 py-2 bg-[#07090E] border-b border-[#1E2638]">
        <div className="flex items-center justify-between text-[10px] font-mono-tabular mb-1">
          <span className="text-[#00E676] font-semibold">
            BIDS: {formatUSD(bidTotalUSD)} ({bidShare.toFixed(1)}%)
          </span>
          <span
            className={`font-bold ${
              imbalancePct >= 0 ? 'text-[#00E676]' : 'text-[#FF1744]'
            }`}
          >
            {imbalancePct >= 0 ? 'BID SKEW' : 'ASK SKEW'} {imbalancePct >= 0 ? '+' : ''}
            {imbalancePct.toFixed(1)}%
          </span>
          <span className="text-[#FF1744] font-semibold">
            ASKS: {formatUSD(askTotalUSD)} ({askShare.toFixed(1)}%)
          </span>
        </div>
        <div className="w-full h-2 bg-[#111622] rounded-xs overflow-hidden flex">
          <div
            className="h-full bg-[#00E676] transition-all duration-300"
            style={{ width: `${bidShare}%` }}
          />
          <div
            className="h-full bg-[#FF1744] transition-all duration-300"
            style={{ width: `${askShare}%` }}
          />
        </div>
      </div>

      {/* TAB 1: ICEBERG ABSORPTION & LIMIT WALLS RADAR */}
      {activeTab === 'WALLS_ICEBERGS' && (
        <div className="p-2.5 space-y-2.5 max-h-[360px] overflow-y-auto">
          {/* Overhead Ask Supply Walls */}
          <div>
            <div className="flex items-center justify-between text-[10px] font-mono-tabular text-[#FF1744] uppercase tracking-wider mb-1">
              <span className="flex items-center gap-1 font-semibold">
                <Shield className="w-3 h-3" />
                Overhead Ask Limit & Iceberg Walls (Supply)
              </span>
              <span className="text-[#64748B]">Size / Z-Score / Dist</span>
            </div>

            <div className="space-y-1">
              {askWalls.length === 0 && (
                <div className="px-2 py-2 rounded border border-[#1E2638] bg-[#07090E] text-[10px] font-mono-tabular text-[#64748B]">
                  No ask level currently exceeds the 1.65σ wall threshold or iceberg-absorption rules.
                </div>
              )}
              {askWalls.slice(0, 5).map((wall) => (
                <div
                  key={wall.id}
                  className={`flex items-center justify-between px-2 py-1.5 rounded border text-xs font-mono-tabular ${
                    wall.type === 'ICEBERG_ABSORPTION'
                      ? 'bg-[#00F0FF]/10 border-[#00F0FF]/40'
                      : 'bg-[#FF1744]/10 border-[#FF1744]/30'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                        wall.type === 'ICEBERG_ABSORPTION'
                          ? 'bg-[#00F0FF]/20 text-[#00F0FF]'
                          : 'bg-[#FF1744]/20 text-[#FF1744]'
                      }`}
                    >
                      {wall.type === 'ICEBERG_ABSORPTION' ? 'ICE WALL' : 'LIMIT WALL'}
                    </span>
                    <div>
                      <div className="font-bold text-[#F1F5F9]">
                        ${formatPrice(wall.price, tickSize)}
                      </div>
                      <div className="text-[10px] text-[#94A3B8]">
                        {wall.type === 'ICEBERG_ABSORPTION'
                          ? `Taped absorption ${formatUSD(wall.absorbedUSD)} (${wall.refillCount} prints)`
                          : `Resting Ask Liquidity (${wall.strength})`}
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="font-bold text-[#FF1744]">{formatUSD(wall.sizeUSD)}</div>
                    <div className="text-[10px] text-[#94A3B8]">
                      <span className="text-[#FACC15]">{wall.zScore.toFixed(1)}σ</span> • +
                      {Math.abs(wall.distancePct).toFixed(2)}%
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Current Mark Price Divider */}
          <div className="flex items-center justify-between px-2.5 py-1 bg-[#111622] border border-[#28324B] rounded text-xs font-mono-tabular">
            <span className="text-[#94A3B8] text-[10px] uppercase">Current Spread Center</span>
            <span className="font-bold text-[#00F0FF]">
              ${formatPrice(lastPrice, tickSize)}
            </span>
          </div>

          {/* Below Bid Demand Walls */}
          <div>
            <div className="flex items-center justify-between text-[10px] font-mono-tabular text-[#00E676] uppercase tracking-wider mb-1">
              <span className="flex items-center gap-1 font-semibold">
                <Shield className="w-3 h-3" />
                Defending Bid Limit & Iceberg Walls (Demand)
              </span>
              <span className="text-[#64748B]">Size / Z-Score / Dist</span>
            </div>

            <div className="space-y-1">
              {bidWalls.length === 0 && (
                <div className="px-2 py-2 rounded border border-[#1E2638] bg-[#07090E] text-[10px] font-mono-tabular text-[#64748B]">
                  No bid level currently exceeds the 1.65σ wall threshold or iceberg-absorption rules.
                </div>
              )}
              {bidWalls.slice(0, 5).map((wall) => (
                <div
                  key={wall.id}
                  className={`flex items-center justify-between px-2 py-1.5 rounded border text-xs font-mono-tabular ${
                    wall.type === 'ICEBERG_ABSORPTION'
                      ? 'bg-[#00F0FF]/10 border-[#00F0FF]/40'
                      : 'bg-[#00E676]/10 border-[#00E676]/30'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                        wall.type === 'ICEBERG_ABSORPTION'
                          ? 'bg-[#00F0FF]/20 text-[#00F0FF]'
                          : 'bg-[#00E676]/20 text-[#00E676]'
                      }`}
                    >
                      {wall.type === 'ICEBERG_ABSORPTION' ? 'ICE WALL' : 'LIMIT WALL'}
                    </span>
                    <div>
                      <div className="font-bold text-[#F1F5F9]">
                        ${formatPrice(wall.price, tickSize)}
                      </div>
                      <div className="text-[10px] text-[#94A3B8]">
                        {wall.type === 'ICEBERG_ABSORPTION'
                          ? `Taped absorption ${formatUSD(wall.absorbedUSD)} (${wall.refillCount} prints)`
                          : `Resting Bid Liquidity (${wall.strength})`}
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="font-bold text-[#00E676]">{formatUSD(wall.sizeUSD)}</div>
                    <div className="text-[10px] text-[#94A3B8]">
                      <span className="text-[#FACC15]">{wall.zScore.toFixed(1)}σ</span> •{' '}
                      {wall.distancePct.toFixed(2)}%
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: L2 DOM LADDER */}
      {activeTab === 'DOM_LADDER' && (
        <div className="p-2 max-h-[360px] overflow-y-auto font-mono-tabular text-[11px]">
          <div className="grid grid-cols-4 text-[10px] text-[#64748B] pb-1 mb-1 border-b border-[#1E2638] px-1">
            <span>PRICE</span>
            <span className="text-right">SIZE ($)</span>
            <span className="text-right">CUMULATIVE</span>
            <span className="text-right">TAG</span>
          </div>

          {/* Asks (Reversed so lowest ask is closest to spread) */}
          <div className="space-y-0.5 mb-1.5">
            {[...asks.slice(0, 10)].reverse().map((lvl) => (
              <div
                key={`ask-${lvl.price}`}
                className="relative flex items-center justify-between px-1.5 py-0.5 rounded-xs overflow-hidden"
              >
                <div
                  className="absolute inset-y-0 right-0 bg-[#FF1744]/15 pointer-events-none"
                  style={{ width: `${Math.min(100, lvl.pctOfMax)}%` }}
                />
                <span className="relative text-[#FF1744] font-semibold">
                  {formatPrice(lvl.price, tickSize)}
                </span>
                <span className="relative text-right text-[#E2E8F0]">
                  {formatUSD(lvl.notionalUSD)}
                </span>
                <span className="relative text-right text-[#64748B]">
                  {formatUSD(lvl.cumulativeUSD)}
                </span>
                <span className="relative text-right">
                  {lvl.isIceberg ? (
                    <span className="text-[9px] px-1 bg-[#00F0FF]/20 text-[#00F0FF] rounded">
                      ICE
                    </span>
                  ) : lvl.isWall ? (
                    <span className="text-[9px] px-1 bg-[#FACC15]/20 text-[#FACC15] rounded">
                      {lvl.zScore.toFixed(1)}σ
                    </span>
                  ) : (
                    <span className="text-[#475569]">-</span>
                  )}
                </span>
              </div>
            ))}
          </div>

          {/* Spread Banner */}
          <div className="py-1 px-2 my-1 bg-[#111622] border-y border-[#1E2638] flex items-center justify-between text-xs font-bold">
            <span className="text-[#94A3B8] text-[10px]">{symbol} LAST</span>
            <span className="text-[#00F0FF]">${formatPrice(lastPrice, tickSize)}</span>
          </div>

          {/* Bids */}
          <div className="space-y-0.5 mt-1.5">
            {bids.slice(0, 10).map((lvl) => (
              <div
                key={`bid-${lvl.price}`}
                className="relative flex items-center justify-between px-1.5 py-0.5 rounded-xs overflow-hidden"
              >
                <div
                  className="absolute inset-y-0 right-0 bg-[#00E676]/15 pointer-events-none"
                  style={{ width: `${Math.min(100, lvl.pctOfMax)}%` }}
                />
                <span className="relative text-[#00E676] font-semibold">
                  {formatPrice(lvl.price, tickSize)}
                </span>
                <span className="relative text-right text-[#E2E8F0]">
                  {formatUSD(lvl.notionalUSD)}
                </span>
                <span className="relative text-right text-[#64748B]">
                  {formatUSD(lvl.cumulativeUSD)}
                </span>
                <span className="relative text-right">
                  {lvl.isIceberg ? (
                    <span className="text-[9px] px-1 bg-[#00F0FF]/20 text-[#00F0FF] rounded">
                      ICE
                    </span>
                  ) : lvl.isWall ? (
                    <span className="text-[9px] px-1 bg-[#FACC15]/20 text-[#FACC15] rounded">
                      {lvl.zScore.toFixed(1)}σ
                    </span>
                  ) : (
                    <span className="text-[#475569]">-</span>
                  )}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: LIVE AGGTRADE TAPE & WHALE PRINTS */}
      {activeTab === 'LIVE_TAPE' && (
        <div className="p-2 max-h-[360px] overflow-y-auto font-mono-tabular text-[11px]">
          <div className="grid grid-cols-4 text-[10px] text-[#64748B] pb-1 mb-1 border-b border-[#1E2638] px-1">
            <span>SIDE / AGGRESSOR</span>
            <span className="text-right">PRICE</span>
            <span className="text-right">NOTIONAL</span>
            <span className="text-right">TIME</span>
          </div>

          <div className="space-y-0.5">
            {recentTrades.slice(0, 28).map((tr) => {
              const isBuy = !tr.isBuyerMaker;
              const d = new Date(tr.time);
              const tStr = `${String(d.getHours()).padStart(2, '0')}:${String(
                d.getMinutes()
              ).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}`;
              return (
                <div
                  key={tr.id}
                  className={`flex items-center justify-between px-1.5 py-1 rounded-xs ${
                    tr.isWhale
                      ? isBuy
                        ? 'bg-[#00E676]/20 border border-[#00E676]/50'
                        : 'bg-[#FF1744]/20 border border-[#FF1744]/50'
                      : 'hover:bg-[#111622]'
                  }`}
                >
                  <span
                    className={`flex items-center gap-1 font-semibold ${
                      isBuy ? 'text-[#00E676]' : 'text-[#FF1744]'
                    }`}
                  >
                    {isBuy ? (
                      <ArrowUpRight className="w-3 h-3" />
                    ) : (
                      <ArrowDownRight className="w-3 h-3" />
                    )}
                    {isBuy ? 'LIFT ASK' : 'HIT BID'}
                    {tr.isWhale && (
                      <span className="text-[9px] px-1 bg-[#FACC15] text-[#07090E] font-bold rounded-xs">
                        WHALE
                      </span>
                    )}
                  </span>
                  <span className="text-right text-[#F1F5F9]">
                    ${formatPrice(tr.price, tickSize)}
                  </span>
                  <span
                    className={`text-right font-semibold ${
                      tr.isWhale ? 'text-[#FACC15]' : 'text-[#E2E8F0]'
                    }`}
                  >
                    {formatUSD(tr.notionalUSD)}
                  </span>
                  <span className="text-right text-[#64748B] text-[10px]">{tStr}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
