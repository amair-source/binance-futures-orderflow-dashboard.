import React, { useState, useRef, useEffect } from 'react';
import {
  Flame,
  Grid,
  BarChart2,
  Eye,
  ShieldAlert,
  Target,
  Layers,
  Sparkles,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import {
  KlineOrderflow,
  VolumeProfileData,
  FibonacciData,
  OrderbookWall,
  TradeSetup,
  ChartOverlayConfig,
} from '../types/orderflow';
import { formatPrice, formatUSD } from '../services/orderflowEngine';

interface MainOrderflowCanvasProps {
  symbol: string;
  tickSize: number;
  klines: KlineOrderflow[];
  volumeProfile: VolumeProfileData;
  fib: FibonacciData;
  walls: OrderbookWall[];
  tradeSetup: TradeSetup;
  overlays: ChartOverlayConfig;
  onToggleOverlay: (key: keyof ChartOverlayConfig) => void;
}

type CanvasMode = 'HEATMAP_CANDLES' | 'FOOTPRINT_MATRIX' | 'VOLUME_PROFILE_DEEP';

export const MainOrderflowCanvas: React.FC<MainOrderflowCanvasProps> = ({
  symbol,
  tickSize,
  klines,
  volumeProfile,
  fib,
  walls,
  tradeSetup,
  overlays,
  onToggleOverlay,
}) => {
  const [mode, setMode] = useState<CanvasMode>('HEATMAP_CANDLES');
  const [visibleBars, setVisibleBars] = useState<number>(44);
  const [hoveredBarIdx, setHoveredBarIdx] = useState<number | null>(null);
  const [hoveredPrice, setHoveredPrice] = useState<number | null>(null);
  const [selectedFootprintCount, setSelectedFootprintCount] = useState<number>(10);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const [dimensions, setDimensions] = useState({ width: 920, height: 470 });

  useEffect(() => {
    const updateSize = () => {
      if (containerRef.current) {
        const rect = containerRef.current.getBoundingClientRect();
        setDimensions({
          width: Math.max(320, Math.floor(rect.width)),
          height: Math.max(380, Math.floor(rect.height)),
        });
      }
    };
    updateSize();
    const observer = new ResizeObserver(updateSize);
    if (containerRef.current) observer.observe(containerRef.current);
    window.addEventListener('resize', updateSize);
    return () => {
      observer.disconnect();
      window.removeEventListener('resize', updateSize);
    };
  }, []);

  const displayedKlines = klines.slice(-visibleBars);
  const latestBar = displayedKlines[displayedKlines.length - 1];
  const inspectedBar =
    hoveredBarIdx !== null && displayedKlines[hoveredBarIdx]
      ? displayedKlines[hoveredBarIdx]
      : latestBar;

  // Draw High-DPI HTML5 Canvas for HEATMAP_CANDLES mode
  useEffect(() => {
    if (mode !== 'HEATMAP_CANDLES') return;
    const canvas = canvasRef.current;
    if (!canvas || displayedKlines.length === 0) return;

    const dpr = window.devicePixelRatio || 1;
    const { width, height } = dimensions;
    canvas.width = width * dpr;
    canvas.height = height * dpr;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.save();
    ctx.scale(dpr, dpr);

    // Clear obsidian background
    ctx.fillStyle = '#07090E';
    ctx.fillRect(0, 0, width, height);

    const rightAxisWidth = 78;
    const vpProfileWidth = overlays.showVolumeProfile ? Math.min(115, width * 0.14) : 0;
    const chartRight = width - rightAxisWidth;
    const candleAreaRight = chartRight - (overlays.showTradeSetup && tradeSetup.status === 'ACTIONABLE' ? 76 : 16);
    const padTop = 22;
    const padBottom = 26;
    const plotHeight = height - padTop - padBottom;
    const plotWidth = Math.max(100, candleAreaRight - 12);

    // Determine price bounds including klines + tradeSetup levels if active
    let minP = Infinity;
    let maxP = -Infinity;
    for (const k of displayedKlines) {
      if (k.low < minP) minP = k.low;
      if (k.high > maxP) maxP = k.high;
    }
    if (overlays.showTradeSetup && tradeSetup && tradeSetup.status === 'ACTIONABLE') {
      minP = Math.min(minP, tradeSetup.stopLoss, tradeSetup.tp1, tradeSetup.tp2);
      maxP = Math.max(maxP, tradeSetup.stopLoss, tradeSetup.tp1, tradeSetup.tp2);
    }
    const padRange = (maxP - minP) * 0.07 || maxP * 0.005;
    minP -= padRange;
    maxP += padRange;
    const priceSpan = Math.max(maxP - minP, 1e-8);

    const priceToY = (p: number) => padTop + ((maxP - p) / priceSpan) * plotHeight;
    const yToPrice = (y: number) => maxP - ((y - padTop) / plotHeight) * priceSpan;

    const barStep = plotWidth / displayedKlines.length;
    const barWidth = Math.max(3, Math.min(18, barStep * 0.64));

    // 1. RENDER LIQUIDITY HEATMAP LAYER
    if (overlays.showHeatmap) {
      displayedKlines.forEach((k, i) => {
        const x = 10 + i * barStep;
        const cells = k.heatmapSlice;
        if (!cells || cells.length === 0) return;

        for (let c = 0; c < cells.length; c++) {
          const cell = cells[c];
          const nextPrice =
            c < cells.length - 1
              ? cells[c + 1].price
              : cell.price + (cell.price - (cells[c - 1]?.price || cell.price * 0.999));
          const y1 = priceToY(nextPrice);
          const y2 = priceToY(cell.price);
          const cellH = Math.max(2, Math.abs(y2 - y1) + 1);

          const intensity = cell.intensity;
          if (intensity < 0.12) continue;

          // Thermal Colormap: Deep Indigo -> Royal Blue -> Electric Cyan -> Solar Gold
          let fill = 'rgba(15, 23, 42, 0.2)';
          if (intensity > 0.84) {
            fill = `rgba(250, 204, 21, ${(0.28 + (intensity - 0.84) * 1.8).toFixed(2)})`; // Solar Gold Wall
          } else if (intensity > 0.66) {
            fill = `rgba(0, 240, 255, ${(0.16 + (intensity - 0.66) * 0.95).toFixed(2)})`; // Electric Cyan
          } else if (intensity > 0.42) {
            fill = `rgba(29, 78, 216, ${(0.12 + (intensity - 0.42) * 0.65).toFixed(2)})`; // Royal Blue
          } else {
            fill = `rgba(17, 24, 59, ${(intensity * 0.45).toFixed(2)})`;
          }

          ctx.fillStyle = fill;
          ctx.fillRect(x, Math.min(y1, y2), Math.ceil(barStep + 0.5), cellH);
        }
      });
    }

    // Subtle Grid Lines
    ctx.strokeStyle = 'rgba(30, 38, 56, 0.55)';
    ctx.lineWidth = 1;
    const gridSteps = 7;
    for (let g = 0; g <= gridSteps; g++) {
      const y = padTop + (plotHeight / gridSteps) * g;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(chartRight, y);
      ctx.stroke();

      const pLabel = yToPrice(y);
      ctx.fillStyle = '#64748B';
      ctx.font = '10px "JetBrains Mono", monospace';
      ctx.textAlign = 'left';
      ctx.fillText(formatPrice(pLabel, tickSize), chartRight + 6, y + 3);
    }

    // 2. RENDER AUTO-FIBONACCI LEVELS & GOLDEN POCKET (0.618 - 0.65)
    if (overlays.showFib && fib.levels.length > 0) {
      const gpHighY = priceToY(fib.goldenPocketHigh);
      const gpLowY = priceToY(fib.goldenPocketLow);
      ctx.fillStyle = 'rgba(234, 179, 8, 0.09)';
      ctx.fillRect(10, Math.min(gpHighY, gpLowY), chartRight - 10, Math.abs(gpLowY - gpHighY));

      fib.levels.forEach((lvl) => {
        if (lvl.price < minP || lvl.price > maxP) return;
        const y = priceToY(lvl.price);
        ctx.save();
        ctx.strokeStyle = lvl.isGoldenPocket
          ? 'rgba(250, 204, 21, 0.75)'
          : 'rgba(148, 163, 184, 0.28)';
        ctx.lineWidth = lvl.isGoldenPocket ? 1.3 : 1;
        ctx.setLineDash(lvl.isGoldenPocket ? [4, 3] : [2, 4]);
        ctx.beginPath();
        ctx.moveTo(10, y);
        ctx.lineTo(chartRight - vpProfileWidth, y);
        ctx.stroke();

        ctx.fillStyle = lvl.isGoldenPocket ? '#FACC15' : '#94A3B8';
        ctx.font = '9px "JetBrains Mono", monospace';
        ctx.textAlign = 'left';
        ctx.fillText(`FIB ${lvl.ratio.toFixed(3)}`, 14, y - 3);
        ctx.restore();
      });
    }

    // 3. RENDER VOLUME PROFILE HISTOGRAM (RIGHT-DOCKED) + POC / VAH / VAL
    if (overlays.showVolumeProfile && volumeProfile.rows.length > 0) {
      // Shaded 70% Value Area band across chart
      const vahY = priceToY(volumeProfile.vah);
      const valY = priceToY(volumeProfile.val);
      ctx.fillStyle = 'rgba(168, 85, 247, 0.045)';
      ctx.fillRect(0, Math.min(vahY, valY), chartRight, Math.abs(valY - vahY));

      // Render Horizontal Histogram Bars on Right Edge
      volumeProfile.rows.forEach((row) => {
        const yTop = priceToY(row.priceHigh);
        const yBot = priceToY(row.priceLow);
        const h = Math.max(2, Math.abs(yBot - yTop) - 1);
        const totalW = (row.pctOfMax / 100) * vpProfileWidth;
        const buyRatio = row.totalVolUSD > 0 ? row.buyVolUSD / row.totalVolUSD : 0.5;
        const buyW = totalW * buyRatio;
        const sellW = totalW - buyW;

        const xRight = chartRight - 2;
        // Sell portion
        ctx.fillStyle = row.isPOC
          ? 'rgba(245, 158, 11, 0.85)'
          : row.inValueArea
          ? 'rgba(255, 23, 68, 0.48)'
          : 'rgba(255, 23, 68, 0.22)';
        ctx.fillRect(xRight - totalW, Math.min(yTop, yBot), sellW, h);

        // Buy portion
        ctx.fillStyle = row.isPOC
          ? 'rgba(245, 158, 11, 0.95)'
          : row.inValueArea
          ? 'rgba(0, 230, 118, 0.52)'
          : 'rgba(0, 230, 118, 0.22)';
        ctx.fillRect(xRight - buyW, Math.min(yTop, yBot), buyW, h);
      });

      // Draw POC, VAH, VAL Horizontal Structural Lines
      const drawKeyLine = (
        price: number,
        color: string,
        label: string,
        dashed: boolean,
        lineWidth = 1.5
      ) => {
        if (price < minP || price > maxP) return;
        const y = priceToY(price);
        ctx.save();
        ctx.strokeStyle = color;
        ctx.lineWidth = lineWidth;
        if (dashed) ctx.setLineDash([5, 4]);
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(chartRight, y);
        ctx.stroke();

        // Axis Tag
        ctx.fillStyle = color;
        ctx.fillRect(chartRight, y - 8, rightAxisWidth, 16);
        ctx.fillStyle = '#07090E';
        ctx.font = 'bold 9.5px "JetBrains Mono", monospace';
        ctx.textAlign = 'left';
        ctx.fillText(`${label} ${formatPrice(price, tickSize)}`, chartRight + 3, y + 3);
        ctx.restore();
      };

      drawKeyLine(volumeProfile.vah, '#A855F7', 'VAH', true, 1.2);
      drawKeyLine(volumeProfile.val, '#A855F7', 'VAL', true, 1.2);
      drawKeyLine(volumeProfile.poc, '#F59E0B', 'POC', false, 1.8);
    }

    // 4. RENDER RESTING LIMIT WALLS & ICEBERG ABSORPTION ZONES
    if (overlays.showLimitWalls && walls.length > 0) {
      walls.slice(0, 6).forEach((wall) => {
        if (wall.price < minP || wall.price > maxP) return;
        if (!overlays.showIcebergs && wall.type === 'ICEBERG_ABSORPTION') return;
        const y = priceToY(wall.price);
        const isBid = wall.side === 'BID';

        ctx.save();
        ctx.strokeStyle =
          wall.type === 'ICEBERG_ABSORPTION'
            ? '#00F0FF'
            : isBid
            ? 'rgba(0, 230, 118, 0.7)'
            : 'rgba(255, 23, 68, 0.7)';
        ctx.lineWidth = wall.strength === 'EXTREME' ? 2 : 1.2;
        ctx.setLineDash(wall.type === 'ICEBERG_ABSORPTION' ? [2, 2] : [8, 3]);
        ctx.beginPath();
        ctx.moveTo(plotWidth * 0.45, y);
        ctx.lineTo(candleAreaRight, y);
        ctx.stroke();

        // Wall Label Pill
        const tagText =
          wall.type === 'ICEBERG_ABSORPTION'
            ? `ICEBERG ${wall.side} ${formatUSD(wall.sizeUSD)} (${wall.zScore.toFixed(1)}σ)`
            : `${wall.side} WALL ${formatUSD(wall.sizeUSD)} (${wall.zScore.toFixed(1)}σ)`;
        ctx.font = '9px "JetBrains Mono", monospace';
        const textW = ctx.measureText(tagText).width + 8;
        ctx.fillStyle =
          wall.type === 'ICEBERG_ABSORPTION'
            ? 'rgba(0, 240, 255, 0.18)'
            : isBid
            ? 'rgba(0, 230, 118, 0.16)'
            : 'rgba(255, 23, 68, 0.16)';
        ctx.fillRect(plotWidth * 0.45, y - 12, textW, 12);
        ctx.fillStyle =
          wall.type === 'ICEBERG_ABSORPTION'
            ? '#00F0FF'
            : isBid
            ? '#00E676'
            : '#FF1744';
        ctx.fillText(tagText, plotWidth * 0.45 + 4, y - 3);
        ctx.restore();
      });
    }

    // 5. RENDER SESSION VWAP & ±1σ BANDS
    if (overlays.showVWAP && displayedKlines.length > 1) {
      const drawCurve = (
        getter: (k: KlineOrderflow) => number,
        color: string,
        lineWidth: number,
        dashed = false
      ) => {
        ctx.save();
        ctx.strokeStyle = color;
        ctx.lineWidth = lineWidth;
        if (dashed) ctx.setLineDash([3, 3]);
        ctx.beginPath();
        displayedKlines.forEach((k, idx) => {
          const x = 10 + idx * barStep + barStep / 2;
          const y = priceToY(getter(k));
          if (idx === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        });
        ctx.stroke();
        ctx.restore();
      };

      drawCurve((k) => k.vwapUpper1, 'rgba(56, 189, 248, 0.42)', 1, true);
      drawCurve((k) => k.vwapLower1, 'rgba(56, 189, 248, 0.42)', 1, true);
      drawCurve((k) => k.vwap, '#38BDF8', 1.8, false);
    }

    // 6. RENDER CANDLESTICKS + FOOTPRINT IMBALANCE DOTS + BAR POC DOTS
    displayedKlines.forEach((k, idx) => {
      const centerX = 10 + idx * barStep + barStep / 2;
      const openY = priceToY(k.open);
      const closeY = priceToY(k.close);
      const highY = priceToY(k.high);
      const lowY = priceToY(k.low);
      const isBull = k.close >= k.open;
      const color = isBull ? '#00E676' : '#FF1744';

      // Wick
      ctx.strokeStyle = color;
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(centerX, highY);
      ctx.lineTo(centerX, lowY);
      ctx.stroke();

      // Body
      const bodyTop = Math.min(openY, closeY);
      const bodyH = Math.max(2, Math.abs(closeY - openY));
      ctx.fillStyle = isBull ? 'rgba(0, 230, 118, 0.88)' : 'rgba(255, 23, 68, 0.88)';
      ctx.fillRect(centerX - barWidth / 2, bodyTop, barWidth, bodyH);

      // Internal Bar POC marker (Gold Tick inside candle)
      const pocY = priceToY(k.pocPrice);
      ctx.fillStyle = '#FACC15';
      ctx.fillRect(centerX - barWidth / 2, pocY - 1, barWidth, 2);

      // Footprint 300% Imbalance markers on candles
      if (overlays.showFootprintImbalances) {
        k.footprint.forEach((fp) => {
          if (fp.imbalanceAsk || fp.imbalanceBid) {
            const fpY = priceToY(fp.price);
            ctx.beginPath();
            ctx.arc(
              centerX + (fp.imbalanceAsk ? barWidth / 2 + 2.5 : -barWidth / 2 - 2.5),
              fpY,
              2.2,
              0,
              Math.PI * 2
            );
            ctx.fillStyle = fp.imbalanceAsk ? '#00F0FF' : '#FF007A';
            ctx.fill();
          }
        });
      }

      // Time axis labels every 8 bars
      if (idx % 8 === 0 || idx === displayedKlines.length - 1) {
        const d = new Date(k.time);
        const label = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
        ctx.fillStyle = '#64748B';
        ctx.font = '9.5px "JetBrains Mono", monospace';
        ctx.textAlign = 'center';
        ctx.fillText(label, centerX, height - 8);
      }
    });

    // 7. RENDER TRADE SETUP PROJECTION BOX ONLY WHEN THE FULL EVIDENCE GATE PASSES
    if (overlays.showTradeSetup && tradeSetup && tradeSetup.status === 'ACTIONABLE') {
      const boxLeft = candleAreaRight - 6;
      const boxWidth = Math.max(58, chartRight - vpProfileWidth - boxLeft - 4);
      const entryY = priceToY(tradeSetup.entryPrice);
      const slY = priceToY(tradeSetup.stopLoss);
      const tp1Y = priceToY(tradeSetup.tp1);
      const tp2Y = priceToY(tradeSetup.tp2);

      // Risk Zone (Entry to SL)
      ctx.fillStyle = 'rgba(255, 23, 68, 0.16)';
      ctx.fillRect(boxLeft, Math.min(entryY, slY), boxWidth, Math.abs(slY - entryY));
      ctx.strokeStyle = '#FF1744';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(boxLeft, slY);
      ctx.lineTo(boxLeft + boxWidth, slY);
      ctx.stroke();

      // Reward Zone (Entry to TP2)
      ctx.fillStyle = 'rgba(0, 230, 118, 0.15)';
      ctx.fillRect(boxLeft, Math.min(entryY, tp2Y), boxWidth, Math.abs(tp2Y - entryY));

      // TP1 dashed line
      ctx.save();
      ctx.strokeStyle = '#00E676';
      ctx.setLineDash([3, 3]);
      ctx.beginPath();
      ctx.moveTo(boxLeft, tp1Y);
      ctx.lineTo(boxLeft + boxWidth, tp1Y);
      ctx.stroke();
      ctx.restore();

      // TP2 solid line
      ctx.strokeStyle = '#00E676';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(boxLeft, tp2Y);
      ctx.lineTo(boxLeft + boxWidth, tp2Y);
      ctx.stroke();

      // Entry Line
      ctx.strokeStyle = '#00F0FF';
      ctx.lineWidth = 1.8;
      ctx.beginPath();
      ctx.moveTo(boxLeft - 25, entryY);
      ctx.lineTo(boxLeft + boxWidth, entryY);
      ctx.stroke();

      // Labels on Projection Box
      ctx.font = 'bold 9px "JetBrains Mono", monospace';
      ctx.textAlign = 'left';
      ctx.fillStyle = '#00F0FF';
      ctx.fillText(`ENTRY`, boxLeft + 3, entryY - 3);
      ctx.fillStyle = '#00E676';
      ctx.fillText(`TP2 (${tradeSetup.rr2}R)`, boxLeft + 3, tp2Y + (tradeSetup.direction === 'LONG' ? 10 : -4));
      ctx.fillStyle = '#FF1744';
      ctx.fillText(`SL`, boxLeft + 3, slY + (tradeSetup.direction === 'LONG' ? -4 : 10));
    }

    // 8. CURRENT PRICE LINE & AXIS TAG
    if (latestBar) {
      const curY = priceToY(latestBar.close);
      const isUp = latestBar.close >= latestBar.open;
      ctx.save();
      ctx.strokeStyle = isUp ? '#00E676' : '#FF1744';
      ctx.lineWidth = 1;
      ctx.setLineDash([2, 2]);
      ctx.beginPath();
      ctx.moveTo(0, curY);
      ctx.lineTo(chartRight, curY);
      ctx.stroke();

      ctx.fillStyle = isUp ? '#00E676' : '#FF1744';
      ctx.fillRect(chartRight, curY - 9, rightAxisWidth, 18);
      ctx.fillStyle = '#07090E';
      ctx.font = 'bold 10px "JetBrains Mono", monospace';
      ctx.textAlign = 'left';
      ctx.fillText(formatPrice(latestBar.close, tickSize), chartRight + 4, curY + 3.5);
      ctx.restore();
    }

    // 9. CROSSHAIR OVERLAY
    if (hoveredBarIdx !== null && displayedKlines[hoveredBarIdx]) {
      const cx = 10 + hoveredBarIdx * barStep + barStep / 2;
      ctx.save();
      ctx.strokeStyle = 'rgba(241, 245, 249, 0.35)';
      ctx.lineWidth = 1;
      ctx.setLineDash([3, 3]);
      ctx.beginPath();
      ctx.moveTo(cx, padTop);
      ctx.lineTo(cx, height - padBottom);
      ctx.stroke();
      ctx.restore();
    }

    ctx.restore();
  }, [
    mode,
    dimensions,
    displayedKlines,
    overlays,
    volumeProfile,
    fib,
    walls,
    tradeSetup,
    tickSize,
    hoveredBarIdx,
    hoveredPrice,
    latestBar,
  ]);

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas || displayedKlines.length === 0) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const rightAxisWidth = 78;
    const chartRight = dimensions.width - rightAxisWidth;
    const candleAreaRight = chartRight - (overlays.showTradeSetup && tradeSetup.status === 'ACTIONABLE' ? 76 : 16);
    const plotWidth = Math.max(100, candleAreaRight - 12);
    const barStep = plotWidth / displayedKlines.length;

    const idx = Math.floor((x - 10) / barStep);
    if (idx >= 0 && idx < displayedKlines.length) {
      setHoveredBarIdx(idx);
    } else {
      setHoveredBarIdx(null);
    }
    setHoveredPrice(y);
  };

  const footprintBars = klines.slice(-selectedFootprintCount);

  return (
    <div className="flex flex-col bg-[#0B0E17] border border-[#1E2638] rounded-sm overflow-hidden">
      {/* Top Mode & Layer Control Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-2 px-3 py-2 bg-[#111622] border-b border-[#1E2638]">
        {/* Primary View Mode Tabs */}
        <div className="flex items-center gap-1 bg-[#07090E] p-0.5 rounded border border-[#1E2638]">
          <button
            onClick={() => setMode('HEATMAP_CANDLES')}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-mono-tabular transition-all cursor-pointer ${
              mode === 'HEATMAP_CANDLES'
                ? 'bg-[#00F0FF]/15 text-[#00F0FF] border border-[#00F0FF]/40 font-semibold'
                : 'text-[#94A3B8] hover:text-[#F1F5F9]'
            }`}
          >
            <Flame className="w-3.5 h-3.5" />
            <span>LIQUIDITY HEATMAP + VP</span>
          </button>

          <button
            onClick={() => setMode('FOOTPRINT_MATRIX')}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-mono-tabular transition-all cursor-pointer ${
              mode === 'FOOTPRINT_MATRIX'
                ? 'bg-[#00F0FF]/15 text-[#00F0FF] border border-[#00F0FF]/40 font-semibold'
                : 'text-[#94A3B8] hover:text-[#F1F5F9]'
            }`}
          >
            <Grid className="w-3.5 h-3.5" />
            <span>FOOTPRINT CLUSTERS (BID×ASK)</span>
          </button>

          <button
            onClick={() => setMode('VOLUME_PROFILE_DEEP')}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-mono-tabular transition-all cursor-pointer ${
              mode === 'VOLUME_PROFILE_DEEP'
                ? 'bg-[#00F0FF]/15 text-[#00F0FF] border border-[#00F0FF]/40 font-semibold'
                : 'text-[#94A3B8] hover:text-[#F1F5F9]'
            }`}
          >
            <BarChart2 className="w-3.5 h-3.5" />
            <span>VOLUME PROFILE & FIB</span>
          </button>
        </div>

        {/* Layer Toggle Pills (When in Heatmap/Candle Mode) */}
        {mode === 'HEATMAP_CANDLES' && (
          <div className="flex flex-wrap items-center gap-1.5">
            {(
              [
                { key: 'showHeatmap', label: 'Heatmap', color: 'text-[#00F0FF]' },
                { key: 'showVolumeProfile', label: 'POC/VAH/VAL', color: 'text-[#F59E0B]' },
                { key: 'showVWAP', label: 'VWAP ±1σ', color: 'text-[#38BDF8]' },
                { key: 'showFib', label: 'Auto-Fib', color: 'text-[#FACC15]' },
                { key: 'showLimitWalls', label: 'Limit/Ice Walls', color: 'text-[#00E676]' },
                { key: 'showTradeSetup', label: 'Setup Target', color: 'text-[#A855F7]' },
              ] as const
            ).map((item) => {
              const active = overlays[item.key];
              return (
                <button
                  key={item.key}
                  onClick={() => onToggleOverlay(item.key)}
                  className={`flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-mono-tabular border transition-colors cursor-pointer ${
                    active
                      ? `bg-[#161D2E] border-[#2D3A54] ${item.color}`
                      : 'bg-[#07090E] border-[#1E2638] text-[#64748B] opacity-60'
                  }`}
                >
                  <Eye className="w-3 h-3" />
                  <span>{item.key === 'showTradeSetup' && tradeSetup.status === 'WAIT' ? 'Setup Locked' : item.label}</span>
                </button>
              );
            })}

            {/* Zoom Bars Control */}
            <div className="flex items-center gap-0.5 ml-1 bg-[#07090E] border border-[#1E2638] rounded px-1 py-0.5">
              <button
                onClick={() => setVisibleBars((v) => Math.max(24, v - 10))}
                title="Zoom In Candles"
                className="p-0.5 text-[#94A3B8] hover:text-[#00F0FF] cursor-pointer"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setVisibleBars((v) => Math.min(64, v + 10))}
                title="Zoom Out Candles"
                className="p-0.5 text-[#94A3B8] hover:text-[#00F0FF] cursor-pointer"
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {mode === 'FOOTPRINT_MATRIX' && (
          <div className="flex items-center gap-2 text-xs font-mono-tabular">
            <span className="text-[#94A3B8] text-[11px]">Cluster Columns:</span>
            {[6, 8, 10, 12].map((cnt) => (
              <button
                key={cnt}
                onClick={() => setSelectedFootprintCount(cnt)}
                className={`px-2 py-0.5 rounded border cursor-pointer ${
                  selectedFootprintCount === cnt
                    ? 'bg-[#00F0FF]/20 border-[#00F0FF] text-[#00F0FF]'
                    : 'bg-[#07090E] border-[#1E2638] text-[#64748B]'
                }`}
              >
                {cnt} Bars
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Live Inspected Bar Telemetry Strip */}
      {inspectedBar && (
        <div className="flex flex-wrap items-center justify-between gap-2 px-3 py-1.5 bg-[#07090E] border-b border-[#1E2638] text-[11px] font-mono-tabular">
          <div className="flex flex-wrap items-center gap-3">
            <span className="text-[#94A3B8] font-semibold">{symbol}</span>
            <span>
              <span className="text-[#64748B]">O:</span>{' '}
              <span className="text-[#F1F5F9]">{formatPrice(inspectedBar.open, tickSize)}</span>
            </span>
            <span>
              <span className="text-[#64748B]">H:</span>{' '}
              <span className="text-[#F1F5F9]">{formatPrice(inspectedBar.high, tickSize)}</span>
            </span>
            <span>
              <span className="text-[#64748B]">L:</span>{' '}
              <span className="text-[#F1F5F9]">{formatPrice(inspectedBar.low, tickSize)}</span>
            </span>
            <span>
              <span className="text-[#64748B]">C:</span>{' '}
              <span
                className={
                  inspectedBar.close >= inspectedBar.open ? 'text-[#00E676]' : 'text-[#FF1744]'
                }
              >
                {formatPrice(inspectedBar.close, tickSize)}
              </span>
            </span>
            <span className="h-3 w-[1px] bg-[#1E2638]" />
            <span>
              <span className="text-[#64748B]">Bar Δ:</span>{' '}
              <span className={inspectedBar.delta >= 0 ? 'text-[#00E676]' : 'text-[#FF1744]'}>
                {inspectedBar.delta >= 0 ? '+' : ''}
                {formatUSD(inspectedBar.delta)}
              </span>
            </span>
            <span>
              <span className="text-[#64748B]">CVD:</span>{' '}
              <span className={inspectedBar.cvd >= 0 ? 'text-[#00F0FF]' : 'text-[#FF1744]'}>
                {inspectedBar.cvd >= 0 ? '+' : ''}
                {formatUSD(inspectedBar.cvd)}
              </span>
            </span>
            <span>
              <span className="text-[#64748B]">Bar POC:</span>{' '}
              <span className="text-[#F59E0B]">{formatPrice(inspectedBar.pocPrice, tickSize)}</span>
            </span>
            <span>
              <span className="text-[#64748B]">OI:</span>{' '}
              <span className="text-[#F1F5F9]">{formatUSD(inspectedBar.openInterestUSD)}</span>
            </span>
          </div>

          {/* Thermal Legend */}
          <div className="hidden lg:flex items-center gap-2 text-[10px] text-[#94A3B8]">
            <span>Liquidity Depth:</span>
            <div className="flex items-center gap-1">
              <span className="w-3 h-2 rounded-xs bg-[#11183B]" />
              <span>Low</span>
              <span className="w-3 h-2 rounded-xs bg-[#1D4ED8]" />
              <span>Med</span>
              <span className="w-3 h-2 rounded-xs bg-[#00F0FF]" />
              <span>High</span>
              <span className="w-3 h-2 rounded-xs bg-[#FACC15]" />
              <span className="text-[#FACC15] font-semibold">Wall (≥2.5σ)</span>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 1: INTERACTIVE LIQUIDITY HEATMAP + CANDLES + VP CANVAS */}
      {mode === 'HEATMAP_CANDLES' && (
        <div
          ref={containerRef}
          className="relative w-full h-[460px] bg-[#07090E] select-none overflow-hidden"
        >
          <canvas
            ref={canvasRef}
            onMouseMove={handleMouseMove}
            onMouseLeave={() => {
              setHoveredBarIdx(null);
              setHoveredPrice(null);
            }}
            className="w-full h-full block cursor-crosshair"
          />

          {/* Floating Key Levels Legend Pill */}
          <div className="absolute top-2.5 left-3 flex flex-wrap items-center gap-2 pointer-events-none">
            <div className="bg-[#0B0E17]/90 border border-[#1E2638] rounded px-2 py-1 text-[10px] font-mono-tabular flex items-center gap-2">
              <span className="inline-block w-2 h-2 rounded-full bg-[#F59E0B]" />
              <span className="text-[#94A3B8]">POC:</span>
              <span className="text-[#F59E0B] font-bold">
                ${formatPrice(volumeProfile.poc, tickSize)}
              </span>
            </div>
            <div className="bg-[#0B0E17]/90 border border-[#1E2638] rounded px-2 py-1 text-[10px] font-mono-tabular flex items-center gap-2">
              <span className="inline-block w-2 h-2 rounded-full bg-[#A855F7]" />
              <span className="text-[#94A3B8]">VA (70%):</span>
              <span className="text-[#E2E8F0]">
                ${formatPrice(volumeProfile.val, tickSize)} – ${formatPrice(volumeProfile.vah, tickSize)}
              </span>
            </div>
            <div className="bg-[#0B0E17]/90 border border-[#1E2638] rounded px-2 py-1 text-[10px] font-mono-tabular flex items-center gap-2">
              <span className="inline-block w-2 h-2 rounded-full bg-[#38BDF8]" />
              <span className="text-[#94A3B8]">VWAP:</span>
              <span className="text-[#38BDF8] font-bold">
                ${formatPrice(latestBar?.vwap || 0, tickSize)}
              </span>
            </div>
            <div className="bg-[#0B0E17]/90 border border-[#1E2638] rounded px-2 py-1 text-[10px] font-mono-tabular flex items-center gap-2">
              <span className="inline-block w-2 h-2 rounded-full bg-[#FACC15]" />
              <span className="text-[#94A3B8]">Fib 0.618 GP:</span>
              <span className="text-[#FACC15] font-bold">
                ${formatPrice(fib.goldenPocketHigh, tickSize)}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 2: FOOTPRINT CLUSTER MATRIX (BID x ASK + IMBALANCES + POC) */}
      {mode === 'FOOTPRINT_MATRIX' && (
        <div className="w-full h-[460px] bg-[#07090E] flex flex-col justify-between overflow-x-auto p-3">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-3 text-xs font-mono-tabular">
              <span className="text-[#00F0FF] font-semibold flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" />
                EXOCLUSTER FOOTPRINT MATRIX (BID SELL × ASK BUY)
              </span>
              <span className="text-[11px] text-[#94A3B8]">
                <span className="inline-block w-2 h-2 bg-[#00E676] rounded-xs mr-1" />
                Ask Imbalance (≥300%)
              </span>
              <span className="text-[11px] text-[#94A3B8]">
                <span className="inline-block w-2 h-2 bg-[#FF1744] rounded-xs mr-1" />
                Bid Imbalance (≥300%)
              </span>
              <span className="text-[11px] text-[#94A3B8]">
                <span className="inline-block w-2 h-2 border border-[#F59E0B] rounded-xs mr-1" />
                Candle POC
              </span>
            </div>
          </div>

          {/* Footprint Columns Grid */}
          <div className="grid grid-flow-col auto-cols-[minmax(132px,1fr)] gap-1.5 flex-1 overflow-x-auto pb-1">
            {footprintBars.map((bar) => {
              const isBull = bar.close >= bar.open;
              const d = new Date(bar.time);
              const timeLabel = `${String(d.getHours()).padStart(2, '0')}:${String(
                d.getMinutes()
              ).padStart(2, '0')}`;
              const rowsReversed = [...bar.footprint].reverse();
              const maxClusterVol = Math.max(...bar.footprint.map((r) => r.totalVol), 1);

              return (
                <div
                  key={bar.time}
                  className="flex flex-col justify-between bg-[#0B0E17] border border-[#1E2638] rounded-xs p-1.5"
                >
                  {/* Candle Header */}
                  <div className="flex items-center justify-between border-b border-[#1E2638] pb-1 mb-1 text-[10px] font-mono-tabular">
                    <span className="text-[#94A3B8]">{timeLabel}</span>
                    <span
                      className={`px-1 rounded font-bold ${
                        isBull
                          ? 'bg-[#00E676]/15 text-[#00E676]'
                          : 'bg-[#FF1744]/15 text-[#FF1744]'
                      }`}
                    >
                      {formatPrice(bar.close, tickSize)}
                    </span>
                  </div>

                  {/* 7 Internal Price Cluster Rows (High to Low) */}
                  <div className="flex flex-col gap-1 my-auto">
                    {rowsReversed.map((fp, rIdx) => {
                      const volPct = (fp.totalVol / maxClusterVol) * 100;
                      return (
                        <div
                          key={rIdx}
                          className={`relative rounded-xs px-1 py-0.5 text-[10px] font-mono-tabular border transition-colors ${
                            fp.isPOC
                              ? 'border-[#F59E0B] bg-[#F59E0B]/10 shadow-[0_0_6px_rgba(245,158,11,0.2)]'
                              : 'border-[#1E2638]/60 bg-[#111622]/70'
                          }`}
                        >
                          {/* Background Volume Intensity Fill */}
                          <div
                            className={`absolute inset-y-0 left-0 opacity-20 pointer-events-none ${
                              fp.delta >= 0 ? 'bg-[#00E676]' : 'bg-[#FF1744]'
                            }`}
                            style={{ width: `${Math.min(100, volPct)}%` }}
                          />

                          <div className="relative flex items-center justify-between text-[9px] text-[#64748B] mb-0.5">
                            <span>{formatPrice(fp.price, tickSize)}</span>
                            {fp.isPOC && (
                              <span className="text-[#F59E0B] font-bold">POC</span>
                            )}
                          </div>

                          <div className="relative flex items-center justify-between gap-1 font-mono-tabular text-[10px]">
                            {/* Bid Vol (Aggressive Sell) */}
                            <span
                              className={
                                fp.imbalanceBid
                                  ? 'text-[#FF1744] font-bold bg-[#FF1744]/20 px-1 rounded-xs'
                                  : 'text-[#94A3B8]'
                              }
                            >
                              {formatUSD(fp.bidVol).replace('$', '')}
                            </span>
                            <span className="text-[#475569]">×</span>
                            {/* Ask Vol (Aggressive Buy) */}
                            <span
                              className={
                                fp.imbalanceAsk
                                  ? 'text-[#00E676] font-bold bg-[#00E676]/20 px-1 rounded-xs'
                                  : 'text-[#94A3B8]'
                              }
                            >
                              {formatUSD(fp.askVol).replace('$', '')}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Cluster Footer Summary Table (Delta, CVD, Vol, Unfinished Auction) */}
                  <div className="mt-1.5 pt-1 border-t border-[#1E2638] space-y-0.5 text-[10px] font-mono-tabular">
                    <div className="flex justify-between">
                      <span className="text-[#64748B]">Delta:</span>
                      <span
                        className={`font-bold ${
                          bar.delta >= 0 ? 'text-[#00E676]' : 'text-[#FF1744]'
                        }`}
                      >
                        {bar.delta >= 0 ? '+' : ''}
                        {formatUSD(bar.delta)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#64748B]">CVD:</span>
                      <span className="text-[#00F0FF]">{formatUSD(bar.cvd)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#64748B]">Vol:</span>
                      <span className="text-[#F1F5F9]">{formatUSD(bar.quoteVolume)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#64748B]">Auction:</span>
                      <span className="text-[#F59E0B]">
                        {bar.unfinishedAuctionHigh
                          ? 'UNFIN HIGH'
                          : bar.unfinishedAuctionLow
                          ? 'UNFIN LOW'
                          : 'COMPLETE'}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* VIEW 3: VOLUME PROFILE (POC / VAH / VAL) & FIBONACCI ARCHITECT */}
      {mode === 'VOLUME_PROFILE_DEEP' && (
        <div className="w-full h-[460px] bg-[#07090E] grid grid-cols-1 lg:grid-cols-12 gap-3 p-3 overflow-y-auto">
          {/* Left 7 Cols: High-Resolution Volume Profile Histogram */}
          <div className="lg:col-span-7 bg-[#0B0E17] border border-[#1E2638] rounded p-3 flex flex-col">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-[#F59E0B]" />
                <span className="font-display font-bold text-xs uppercase tracking-wider text-[#F1F5F9]">
                  Session Volume Profile Distribution (70% Value Area)
                </span>
              </div>
              <span className="text-[11px] font-mono-tabular text-[#94A3B8]">
                Total Session Vol: {formatUSD(volumeProfile.totalVolumeUSD)}
              </span>
            </div>

            <div className="flex-1 overflow-y-auto space-y-1 pr-1">
              {[...volumeProfile.rows].reverse().map((row, idx) => {
                const buyPct =
                  row.totalVolUSD > 0 ? (row.buyVolUSD / row.totalVolUSD) * row.pctOfMax : 0;
                const sellPct = row.pctOfMax - buyPct;
                return (
                  <div
                    key={idx}
                    className={`flex items-center gap-2 text-[10px] font-mono-tabular py-0.5 px-1.5 rounded ${
                      row.isPOC
                        ? 'bg-[#F59E0B]/15 border border-[#F59E0B]/60'
                        : row.isVAH || row.isVAL
                        ? 'bg-[#A855F7]/15 border border-[#A855F7]/50'
                        : row.inValueArea
                        ? 'bg-[#111622]'
                        : 'opacity-55'
                    }`}
                  >
                    <span className="w-20 text-[#E2E8F0] font-semibold">
                      ${formatPrice(row.price, tickSize)}
                    </span>

                    <div className="flex-1 h-3 bg-[#07090E] rounded-xs overflow-hidden flex items-center">
                      <div
                        className="h-full bg-[#00E676]"
                        style={{ width: `${buyPct}%` }}
                      />
                      <div
                        className="h-full bg-[#FF1744]"
                        style={{ width: `${sellPct}%` }}
                      />
                    </div>

                    <span
                      className={`w-16 text-right ${
                        row.deltaUSD >= 0 ? 'text-[#00E676]' : 'text-[#FF1744]'
                      }`}
                    >
                      {row.deltaUSD >= 0 ? '+' : ''}
                      {formatUSD(row.deltaUSD)}
                    </span>

                    <span className="w-12 text-right font-bold">
                      {row.isPOC ? (
                        <span className="text-[#F59E0B]">POC</span>
                      ) : row.isVAH ? (
                        <span className="text-[#A855F7]">VAH</span>
                      ) : row.isVAL ? (
                        <span className="text-[#A855F7]">VAL</span>
                      ) : row.inValueArea ? (
                        <span className="text-[#64748B]">VA</span>
                      ) : (
                        ''
                      )}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right 5 Cols: Auto-Fibonacci + Session VWAP Bands Table */}
          <div className="lg:col-span-5 flex flex-col gap-3">
            {/* Auto-Fibonacci Matrix */}
            <div className="bg-[#0B0E17] border border-[#1E2638] rounded p-3 flex-1">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-1.5">
                  <Target className="w-4 h-4 text-[#FACC15]" />
                  <span className="font-display font-bold text-xs uppercase tracking-wider text-[#F1F5F9]">
                    Auto-Fibonacci Retracement Levels
                  </span>
                </div>
                <span className="text-[10px] font-mono-tabular px-1.5 py-0.5 rounded bg-[#FACC15]/15 text-[#FACC15]">
                  {fib.trend} IMPULSE
                </span>
              </div>

              <div className="space-y-1.5 font-mono-tabular text-xs">
                {fib.levels.map((lvl) => {
                  const distPct =
                    latestBar && latestBar.close > 0
                      ? ((lvl.price - latestBar.close) / latestBar.close) * 100
                      : 0;
                  return (
                    <div
                      key={lvl.ratio}
                      className={`flex items-center justify-between px-2.5 py-1.5 rounded border ${
                        lvl.isGoldenPocket
                          ? 'bg-[#FACC15]/15 border-[#FACC15]/50 text-[#FACC15]'
                          : 'bg-[#111622] border-[#1E2638] text-[#E2E8F0]'
                      }`}
                    >
                      <span>{lvl.label}</span>
                      <div className="flex items-center gap-3">
                        <span className="font-bold">${formatPrice(lvl.price, tickSize)}</span>
                        <span
                          className={`text-[10px] ${
                            distPct >= 0 ? 'text-[#00E676]' : 'text-[#FF1744]'
                          }`}
                        >
                          {distPct >= 0 ? '+' : ''}
                          {distPct.toFixed(2)}%
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Session VWAP Standard Deviation Bands */}
            {latestBar && (
              <div className="bg-[#0B0E17] border border-[#1E2638] rounded p-3">
                <div className="flex items-center gap-1.5 mb-2">
                  <ShieldAlert className="w-4 h-4 text-[#38BDF8]" />
                  <span className="font-display font-bold text-xs uppercase tracking-wider text-[#F1F5F9]">
                    Session VWAP & Volatility Bands (±1σ / ±2σ)
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-1.5 font-mono-tabular text-xs">
                  <div className="bg-[#111622] border border-[#1E2638] rounded p-2 flex justify-between">
                    <span className="text-[#94A3B8]">VWAP +2σ:</span>
                    <span className="text-[#FF1744] font-semibold">
                      ${formatPrice(latestBar.vwapUpper2, tickSize)}
                    </span>
                  </div>
                  <div className="bg-[#111622] border border-[#1E2638] rounded p-2 flex justify-between">
                    <span className="text-[#94A3B8]">VWAP +1σ:</span>
                    <span className="text-[#F59E0B] font-semibold">
                      ${formatPrice(latestBar.vwapUpper1, tickSize)}
                    </span>
                  </div>
                  <div className="col-span-2 bg-[#38BDF8]/15 border border-[#38BDF8]/40 rounded p-2 flex justify-between">
                    <span className="text-[#38BDF8] font-bold">SESSION VWAP (Mean):</span>
                    <span className="text-[#38BDF8] font-bold">
                      ${formatPrice(latestBar.vwap, tickSize)}
                    </span>
                  </div>
                  <div className="bg-[#111622] border border-[#1E2638] rounded p-2 flex justify-between">
                    <span className="text-[#94A3B8]">VWAP -1σ:</span>
                    <span className="text-[#00E676] font-semibold">
                      ${formatPrice(latestBar.vwapLower1, tickSize)}
                    </span>
                  </div>
                  <div className="bg-[#111622] border border-[#1E2638] rounded p-2 flex justify-between">
                    <span className="text-[#94A3B8]">VWAP -2σ:</span>
                    <span className="text-[#00F0FF] font-semibold">
                      ${formatPrice(latestBar.vwapLower2, tickSize)}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
