import React, { useState } from 'react';
import {
  Crosshair,
  ShieldAlert,
  Target,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  Calculator,
  Sparkles,
  ArrowUpRight,
  ArrowDownRight,
} from 'lucide-react';
import { TradeSetup } from '../types/orderflow';
import { formatPrice, formatUSD } from '../services/orderflowEngine';

interface TradeSetupCardProps {
  setup: TradeSetup;
  tickSize: number;
  baseAsset: string;
}

export const TradeSetupCard: React.FC<TradeSetupCardProps> = ({
  setup,
  tickSize,
  baseAsset,
}) => {
  const [copied, setCopied] = useState(false);
  const [showSizer, setShowSizer] = useState(false);
  const [accountSizeUSD, setAccountSizeUSD] = useState<number>(10000);
  const [riskPerTradePct, setRiskPerTradePct] = useState<number>(1.0);

  const isLong = setup.direction === 'LONG';
  const isWait = setup.status === 'WAIT';

  // Position sizer math
  const dollarRisk = accountSizeUSD * (riskPerTradePct / 100);
  const stopDistancePct = Math.max(setup.riskPct / 100, 0.0005);
  const positionNotionalUSD = dollarRisk / stopDistancePct;
  const positionContracts = setup.entryPrice > 0 ? positionNotionalUSD / setup.entryPrice : 0;
  const effectiveLeverage = accountSizeUSD > 0 ? positionNotionalUSD / accountSizeUSD : 1;
  const expectedProfitTP2 = dollarRisk * setup.rr2;

  const handleCopySetup = () => {
    const text = [
      `=== KRONOS PRE-TRADE DECISION: ${setup.symbol} (${setup.timeframe}) ===`,
      `STATUS: ${setup.status}${setup.status === 'WAIT' ? ' — LEVELS ARE CONDITIONAL, NOT AN ACTIVE TRADE' : ''}`,
      `DIRECTION BIAS: ${setup.direction} | GRADE: ${setup.setupGrade} (${setup.confidence}% Confluence)`,
      `FACTORS: ${setup.factorsAligned}/${setup.factorsEvaluated} aligned | Bias score ${setup.biasScore}`,
      `BLOCKERS: ${setup.blockedReasons.length ? setup.blockedReasons.join(' | ') : 'None — all execution gates passed'}`,
      `ENTRY TYPE: ${setup.entryType} (${setup.entryOrderType})`,
      `ENTRY PRICE: $${formatPrice(setup.entryPrice, tickSize)} (Zone: $${formatPrice(setup.entryZone[0], tickSize)} - $${formatPrice(setup.entryZone[1], tickSize)})`,
      `STOP LOSS (SL): $${formatPrice(setup.stopLoss, tickSize)} (-${setup.riskPct}%) [${setup.stopLossReason}]`,
      `TAKE PROFIT 1 (TP1): $${formatPrice(setup.tp1, tickSize)} (${setup.rr1}R) [${setup.tp1Reason}]`,
      `TAKE PROFIT 2 (TP2): $${formatPrice(setup.tp2, tickSize)} (${setup.rr2}R) [${setup.tp2Reason}]`,
      `TAKE PROFIT 3 (TP3): $${formatPrice(setup.tp3, tickSize)} (${setup.rr3}R) [${setup.tp3Reason}]`,
      `RISK/REWARD (TP2): 1 : ${setup.rr2}`,
      `THESIS: ${setup.thesisSummary}`,
    ].join('\n');
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Visual R:R Ratio Bar proportions
  const totalParts = 1 + Math.max(setup.rr2, 1);
  const riskBarWidth = (1 / totalParts) * 100;
  const rewardBarWidth = 100 - riskBarWidth;

  return (
    <div
      className={`bg-[#0B0E17] border rounded-sm overflow-hidden flex flex-col ${
        isWait
          ? 'border-[#F59E0B]/45 shadow-[0_0_24px_rgba(245,158,11,0.06)]'
          : isLong
          ? 'border-[#00E676]/40 shadow-[0_0_24px_rgba(0,230,118,0.06)]'
          : 'border-[#FF1744]/40 shadow-[0_0_24px_rgba(255,23,68,0.06)]'
      }`}
    >
      {/* Top Header Banner */}
      <div
        className={`px-3.5 py-2.5 border-b flex items-center justify-between ${
          isWait
            ? 'bg-gradient-to-r from-[#F59E0B]/15 via-[#111622] to-[#111622] border-[#F59E0B]/30'
            : isLong
            ? 'bg-gradient-to-r from-[#00E676]/15 via-[#111622] to-[#111622] border-[#00E676]/30'
            : 'bg-gradient-to-r from-[#FF1744]/15 via-[#111622] to-[#111622] border-[#FF1744]/30'
        }`}
      >
        <div className="flex items-center gap-2">
          <div
            className={`w-7 h-7 rounded flex items-center justify-center font-bold ${
              isWait
                ? 'bg-[#F59E0B] text-[#07090E]'
                : isLong
                ? 'bg-[#00E676] text-[#07090E]'
                : 'bg-[#FF1744] text-[#F1F5F9]'
            }`}
          >
            {isWait ? (
              <ShieldAlert className="w-4 h-4" />
            ) : isLong ? (
              <ArrowUpRight className="w-4 h-4" />
            ) : (
              <ArrowDownRight className="w-4 h-4" />
            )}
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-display font-bold text-xs uppercase tracking-wider text-[#F1F5F9]">
                {isWait ? 'PRE-TRADE DECISION: WAIT' : 'ACTIONABLE TRADE SETUP'}
              </span>
              <span
                className={`text-[10px] font-mono-tabular font-bold px-1.5 py-0.5 rounded ${
                  isWait
                    ? 'bg-[#F59E0B] text-[#07090E]'
                    : isLong
                    ? 'bg-[#00E676] text-[#07090E]'
                    : 'bg-[#FF1744] text-[#F1F5F9]'
                }`}
              >
                {isWait ? `${setup.direction} BIAS / NO TRADE` : setup.direction}
              </span>
              <span className="text-[10px] font-mono-tabular font-bold px-1.5 py-0.5 rounded bg-[#00F0FF]/20 text-[#00F0FF] border border-[#00F0FF]/40">
                GRADE {setup.setupGrade}
              </span>
            </div>
            <p className="text-[10px] font-mono-tabular text-[#94A3B8] mt-0.5">
              {setup.entryType}
            </p>
          </div>
        </div>

        {/* Confidence & Copy Action */}
        <div className="flex items-center gap-1.5">
          <div className="text-right mr-1">
            <div className="text-[9px] uppercase text-[#64748B]">Confluence</div>
            <div className="font-mono-tabular font-bold text-xs text-[#00F0FF]">
              {setup.confidence}%
            </div>
          </div>

          <button
            onClick={() => setShowSizer((s) => !s)}
            title="Toggle Risk & Position Size Calculator"
            className={`p-1.5 rounded border transition-colors cursor-pointer ${
              showSizer
                ? 'bg-[#00F0FF]/20 border-[#00F0FF] text-[#00F0FF]'
                : 'bg-[#07090E] border-[#1E2638] text-[#94A3B8] hover:text-[#F1F5F9]'
            }`}
          >
            <Calculator className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={handleCopySetup}
            title="Copy Execution Plan"
            className="flex items-center gap-1 px-2 py-1 rounded bg-[#07090E] hover:bg-[#1E2638] border border-[#1E2638] text-[10px] font-mono-tabular text-[#E2E8F0] transition-colors cursor-pointer"
          >
            {copied ? (
              <>
                <Check className="w-3 h-3 text-[#00E676]" />
                <span className="text-[#00E676]">COPIED</span>
              </>
            ) : (
              <>
                <Copy className="w-3 h-3 text-[#00F0FF]" />
                <span>COPY</span>
              </>
            )}
          </button>
        </div>
      </div>

      {isWait && (
        <div className="mx-3 mt-3 rounded border border-[#F59E0B]/40 bg-[#F59E0B]/10 p-2.5">
          <div className="flex items-center gap-1.5 text-[10px] font-mono-tabular font-bold text-[#F59E0B] mb-1.5">
            <ShieldAlert className="w-3.5 h-3.5" />
            NO TRADE — {setup.blockedReasons.length} GATE{setup.blockedReasons.length === 1 ? '' : 'S'} NOT CLEARED
          </div>
          <ul className="space-y-1">
            {setup.blockedReasons.map((reason, index) => (
              <li key={index} className="flex items-start gap-1.5 text-[10px] leading-snug text-[#CBD5E1]">
                <span className="text-[#F59E0B] font-mono-tabular shrink-0">{String(index + 1).padStart(2, '0')}</span>
                <span>{reason}</span>
              </li>
            ))}
          </ul>
          <p className="text-[9px] font-mono-tabular text-[#94A3B8] mt-2 border-t border-[#F59E0B]/20 pt-1.5">
            Entry / SL / TP below are conditional watch levels only. Minimum TP2 R:R: {setup.minimumRR.toFixed(2)}.
          </p>
        </div>
      )}

      {/* Core Execution Parameters: ENTRY, STOP LOSS, TP1, TP2, TP3, R:R */}
      <div className="p-3 space-y-3">
        {/* Entry Type & Order Execution Box */}
        <div className="grid grid-cols-2 gap-2">
          <div className="bg-[#111622] border border-[#00F0FF]/40 rounded p-2.5">
            <div className="flex items-center justify-between text-[10px] font-mono-tabular text-[#00F0FF] mb-0.5">
              <span className="flex items-center gap-1 font-semibold">
                <Crosshair className="w-3 h-3" />
                {isWait ? 'CONDITIONAL ENTRY' : `ENTRY (${setup.entryOrderType})`}
              </span>
              <span>{isWait ? 'WATCH ONLY' : 'OPTIMAL'}</span>
            </div>
            <div className="font-mono-tabular font-bold text-base text-[#F1F5F9]">
              ${formatPrice(setup.entryPrice, tickSize)}
            </div>
            <div className="text-[10px] font-mono-tabular text-[#64748B] mt-0.5">
              Zone: ${formatPrice(setup.entryZone[0], tickSize)} – $
              {formatPrice(setup.entryZone[1], tickSize)}
            </div>
          </div>

          <div className="bg-[#111622] border border-[#FF1744]/40 rounded p-2.5">
            <div className="flex items-center justify-between text-[10px] font-mono-tabular text-[#FF1744] mb-0.5">
              <span className="flex items-center gap-1 font-semibold">
                <ShieldAlert className="w-3 h-3" />
                STOP LOSS (SL)
              </span>
              <span>-{setup.riskPct}% RISK</span>
            </div>
            <div className="font-mono-tabular font-bold text-base text-[#FF1744]">
              ${formatPrice(setup.stopLoss, tickSize)}
            </div>
            <div className="text-[10px] text-[#94A3B8] truncate mt-0.5" title={setup.stopLossReason}>
              {setup.stopLossReason}
            </div>
          </div>
        </div>

        {/* Take Profit Targets Ladder (TP1, TP2, TP3) */}
        <div className="space-y-1.5">
          {[
            {
              label: 'TP1 (Conservative / Scale 40%)',
              price: setup.tp1,
              rr: setup.rr1,
              reason: setup.tp1Reason,
              badgeClass: 'bg-[#00E676]/15 text-[#00E676] border-[#00E676]/30',
            },
            {
              label: 'TP2 (Primary Structural Target / 40%)',
              price: setup.tp2,
              rr: setup.rr2,
              reason: setup.tp2Reason,
              badgeClass: 'bg-[#00E676]/25 text-[#00E676] border-[#00E676]/60',
            },
            {
              label: 'TP3 (Runner Liquidity Sweep / 20%)',
              price: setup.tp3,
              rr: setup.rr3,
              reason: setup.tp3Reason,
              badgeClass: 'bg-[#00F0FF]/20 text-[#00F0FF] border-[#00F0FF]/40',
            },
          ].map((tp, idx) => (
            <div
              key={idx}
              className="flex items-center justify-between px-2.5 py-1.5 rounded bg-[#111622] border border-[#1E2638] hover:border-[#00E676]/40 transition-colors"
            >
              <div className="min-w-0 pr-2">
                <div className="flex items-center gap-1.5">
                  <Target className="w-3 h-3 text-[#00E676] shrink-0" />
                  <span className="text-[11px] font-mono-tabular font-semibold text-[#F1F5F9]">
                    {tp.label}
                  </span>
                </div>
                <p className="text-[10px] text-[#94A3B8] truncate pl-4">{tp.reason}</p>
              </div>

              <div className="text-right shrink-0">
                <div className="font-mono-tabular font-bold text-xs text-[#00E676]">
                  ${formatPrice(tp.price, tickSize)}
                </div>
                <span
                  className={`inline-block text-[9px] font-mono-tabular font-bold px-1.5 py-0.2 rounded border ${tp.badgeClass}`}
                >
                  {tp.rr}R R:R
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Visual Risk-to-Reward (R:R) Ratio Bar */}
        <div className="bg-[#07090E] border border-[#1E2638] rounded p-2.5">
          <div className="flex items-center justify-between text-[11px] font-mono-tabular mb-1.5">
            <span className="text-[#94A3B8]">
              RISK / REWARD RATIO:{' '}
              <strong className="text-[#00F0FF]">1 : {setup.rr2}</strong> (TP2)
            </span>
            <span className="text-[#00E676] font-semibold">
              +{setup.rewardPct}% vs -{setup.riskPct}%
            </span>
          </div>

          <div className="w-full h-3 rounded-xs overflow-hidden flex border border-[#1E2638]">
            <div
              style={{ width: `${riskBarWidth}%` }}
              className="h-full bg-[#FF1744] flex items-center justify-center text-[9px] font-mono-tabular font-bold text-[#F1F5F9]"
            >
              1R
            </div>
            <div
              style={{ width: `${rewardBarWidth}%` }}
              className="h-full bg-gradient-to-r from-[#00E676]/80 to-[#00F0FF] flex items-center justify-center text-[9px] font-mono-tabular font-bold text-[#07090E]"
            >
              {setup.rr2}R REWARD POTENTIAL
            </div>
          </div>
        </div>

        {/* Optional Interactive Position Size & Risk Calculator */}
        {showSizer && (
          <div className="bg-[#07090E] border border-[#00F0FF]/40 rounded p-2.5 space-y-2">
            <div className="flex items-center justify-between text-[11px] font-mono-tabular text-[#00F0FF]">
              <span className="font-bold flex items-center gap-1">
                <Calculator className="w-3.5 h-3.5" />
                POSITION SIZE & R:R CALCULATOR
              </span>
              <span className="text-[10px] text-[#94A3B8]">
                Lev: {effectiveLeverage.toFixed(1)}x
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs font-mono-tabular">
              <div>
                <label className="text-[10px] text-[#64748B] block mb-0.5">
                  Account Equity ($)
                </label>
                <input
                  type="number"
                  value={accountSizeUSD}
                  onChange={(e) => setAccountSizeUSD(Math.max(100, Number(e.target.value)))}
                  className="w-full bg-[#111622] border border-[#1E2638] rounded px-2 py-1 text-xs text-[#F1F5F9]"
                />
              </div>
              <div>
                <label className="text-[10px] text-[#64748B] block mb-0.5">
                  Risk Per Trade (%)
                </label>
                <input
                  type="number"
                  step="0.25"
                  value={riskPerTradePct}
                  onChange={(e) =>
                    setRiskPerTradePct(Math.min(10, Math.max(0.1, Number(e.target.value))))
                  }
                  className="w-full bg-[#111622] border border-[#1E2638] rounded px-2 py-1 text-xs text-[#F1F5F9]"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-1.5 pt-1 text-[10px] font-mono-tabular">
              <div className="bg-[#111622] p-1.5 rounded border border-[#1E2638]">
                <span className="text-[#64748B] block">Position Size</span>
                <span className="text-[#F1F5F9] font-bold">
                  {formatUSD(positionNotionalUSD)}
                </span>
                <span className="text-[#94A3B8] block text-[9px]">
                  {positionContracts.toFixed(3)} {baseAsset}
                </span>
              </div>
              <div className="bg-[#111622] p-1.5 rounded border border-[#1E2638]">
                <span className="text-[#64748B] block">1R Risk ($)</span>
                <span className="text-[#FF1744] font-bold">-${dollarRisk.toFixed(0)}</span>
              </div>
              <div className="bg-[#111622] p-1.5 rounded border border-[#1E2638]">
                <span className="text-[#64748B] block">TP2 Profit ($)</span>
                <span className="text-[#00E676] font-bold">
                  +${expectedProfitTP2.toFixed(0)}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Quantitative Thesis Summary */}
        <div className="bg-[#111622]/70 border border-[#1E2638] rounded p-2.5 text-[11px] text-[#CBD5E1] leading-relaxed">
          <div className="flex items-center gap-1 text-[10px] font-mono-tabular uppercase text-[#00F0FF] font-semibold mb-1">
            <Sparkles className="w-3 h-3" />
            <span>Synthesized Orderflow Thesis</span>
          </div>
          {setup.thesisSummary}
        </div>

        {/* 6-Factor Quantitative Confluence Checklist */}
        <div>
          <div className="flex items-center justify-between text-[10px] font-mono-tabular uppercase tracking-wider text-[#94A3B8] mb-1.5">
            <span>All-Factor Execution Checklist • Bias {setup.biasScore >= 0 ? '+' : ''}{setup.biasScore}</span>
            <span className="text-[#00F0FF]">
              {setup.confluenceFactors.filter((f) => f.passed).length}/
              {setup.confluenceFactors.length} Aligned
            </span>
          </div>

          <div className="space-y-1.5 max-h-64 overflow-y-auto pr-0.5">
            {setup.confluenceFactors.map((factor) => (
              <div
                key={factor.id}
                className={`p-2 rounded border text-xs transition-colors ${
                  factor.passed
                    ? 'bg-[#111622] border-[#1E2638]'
                    : 'bg-[#07090E] border-[#1E2638]/60 opacity-75'
                }`}
              >
                <div className="flex items-center justify-between gap-2 mb-0.5">
                  <div className="flex items-center gap-1.5">
                    {factor.passed ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#00E676] shrink-0" />
                    ) : (
                      <AlertCircle className="w-3.5 h-3.5 text-[#F59E0B] shrink-0" />
                    )}
                    <span className="font-semibold text-[11px] text-[#F1F5F9]">
                      {factor.title}
                    </span>
                    <span className={`text-[9px] font-mono-tabular px-1 rounded ${factor.weight > 0 ? 'bg-[#07090E] text-[#64748B]' : 'bg-[#F59E0B]/15 text-[#F59E0B]'}`}>
                      {factor.weight > 0 ? `W${factor.weight}` : 'NO DATA'}
                    </span>
                  </div>

                  <span
                    className={`text-[10px] font-mono-tabular font-bold px-1.5 py-0.2 rounded ${
                      factor.signal === 'BULLISH'
                        ? 'bg-[#00E676]/15 text-[#00E676]'
                        : factor.signal === 'BEARISH'
                        ? 'bg-[#FF1744]/15 text-[#FF1744]'
                        : 'bg-[#1E2638] text-[#94A3B8]'
                    }`}
                  >
                    {factor.metricValue}
                  </span>
                </div>
                <p className="text-[10px] text-[#94A3B8] pl-5 leading-snug">
                  {factor.detail}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
