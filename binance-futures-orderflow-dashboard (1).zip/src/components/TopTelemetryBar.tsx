import React, { useState, useRef, useEffect } from 'react';
import {
  Search,
  Activity,
  ChevronDown,
  RefreshCw,
  Wifi,
  Layers,
  TrendingUp,
  TrendingDown,
} from 'lucide-react';
import {
  AssetTicker,
  Timeframe,
  VolumeProfileData,
} from '../types/orderflow';
import { DEFAULT_FUTURES_ASSETS } from '../services/binanceFuturesService';
import { formatPrice, formatUSD } from '../services/orderflowEngine';

interface TopTelemetryBarProps {
  ticker: AssetTicker;
  timeframe: Timeframe;
  onSelectSymbol: (symbol: string) => void;
  onSelectTimeframe: (tf: Timeframe) => void;
  allSymbols: string[];
  volumeProfile: VolumeProfileData;
  currentVWAP: number;
  currentCVD: number;
  connectionSource: 'BINANCE_FAPI_LIVE' | 'BINANCE_VISION_MIRROR' | 'SYNTHETIC_FALLBACK';
  wsConnected: boolean;
  onRefresh: () => void;
  isLoading: boolean;
}

const TIMEFRAMES: Timeframe[] = ['1m', '5m', '15m', '1h', '4h'];
const CATEGORIES = ['ALL', 'LAYER-1', 'DEFI', 'AI & INFRA', 'MEME'] as const;

export const TopTelemetryBar: React.FC<TopTelemetryBarProps> = ({
  ticker,
  timeframe,
  onSelectSymbol,
  onSelectTimeframe,
  allSymbols,
  volumeProfile,
  currentVWAP,
  currentCVD,
  connectionSource,
  wsConnected,
  onRefresh,
  isLoading,
}) => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<(typeof CATEGORIES)[number]>('ALL');
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filteredCurated = DEFAULT_FUTURES_ASSETS.filter((item) => {
    const matchesCat = activeCategory === 'ALL' || item.category === activeCategory;
    const matchesSearch =
      item.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  // Also match any symbol from Binance exchangeInfo when user types in search
  const extraMatches =
    searchQuery.trim().length >= 1
      ? allSymbols
          .filter(
            (s) =>
              s.toLowerCase().includes(searchQuery.toLowerCase()) &&
              !DEFAULT_FUTURES_ASSETS.some((d) => d.symbol === s)
          )
          .slice(0, 20)
      : [];

  const isPositive24h = ticker.priceChangePct24h >= 0;

  return (
    <header className="w-full bg-[#0B0E17] border-b border-[#1E2638] px-3 py-2 select-none z-30">
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Left: Brand + Asset Selector + Timeframes */}
        <div className="flex items-center gap-2.5">
          {/* Terminal Logo */}
          <div className="flex items-center gap-2 pr-2.5 border-r border-[#1E2638]">
            <div className="w-7 h-7 rounded bg-[#00F0FF]/10 border border-[#00F0FF]/40 flex items-center justify-center shadow-[0_0_12px_rgba(0,240,255,0.2)]">
              <Layers className="w-4 h-4 text-[#00F0FF]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-display font-bold text-xs tracking-wider text-[#F1F5F9]">
                  KRONOS
                </span>
                <span className="text-[9px] font-mono-tabular px-1 py-0.2 bg-[#00F0FF]/15 text-[#00F0FF] border border-[#00F0FF]/30 rounded">
                  ORDERFLOW
                </span>
              </div>
              <p className="text-[10px] text-[#64748B] leading-none mt-0.5">
                BINANCE USDT-M PERP
              </p>
            </div>
          </div>

          {/* Asset Dropdown Trigger */}
          <div className="relative" ref={dropdownRef}>
            <button
              onClick={() => setDropdownOpen((o) => !o)}
              className="flex items-center gap-2.5 bg-[#111622] hover:bg-[#161D2E] border border-[#1E2638] hover:border-[#00F0FF]/50 rounded px-3 py-1.5 transition-colors cursor-pointer"
            >
              <div className="text-left">
                <div className="flex items-center gap-1.5">
                  <span className="font-display font-bold text-sm text-[#F1F5F9] tracking-tight">
                    {ticker.symbol}
                  </span>
                  <span className="text-[10px] font-mono-tabular px-1.5 py-0.5 rounded bg-[#1E2638] text-[#94A3B8]">
                    PERP
                  </span>
                </div>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-[#94A3B8]" />
            </button>

            {dropdownOpen && (
              <div className="absolute left-0 mt-1.5 w-80 bg-[#0F1420] border border-[#28324B] rounded-md shadow-2xl z-50 overflow-hidden">
                <div className="p-2.5 border-b border-[#1E2638]">
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 text-[#64748B] absolute left-2.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search any Binance Futures asset (e.g. SOL, PEPE, ARB)..."
                      className="w-full bg-[#07090E] border border-[#1E2638] focus:border-[#00F0FF] rounded pl-8 pr-3 py-1.5 text-xs text-[#F1F5F9] placeholder-[#64748B] focus:outline-none font-mono-tabular"
                      autoFocus
                    />
                  </div>
                  {/* Category Pills */}
                  <div className="flex items-center gap-1 mt-2 overflow-x-auto pb-0.5">
                    {CATEGORIES.map((cat) => (
                      <button
                        key={cat}
                        onClick={() => setActiveCategory(cat)}
                        className={`text-[10px] font-mono-tabular px-2 py-0.5 rounded cursor-pointer transition-colors whitespace-nowrap ${
                          activeCategory === cat
                            ? 'bg-[#00F0FF]/20 text-[#00F0FF] border border-[#00F0FF]/40'
                            : 'bg-[#111622] text-[#64748B] hover:text-[#94A3B8]'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="max-h-72 overflow-y-auto divide-y divide-[#1E2638]/50">
                  {filteredCurated.map((item) => {
                    const isSelected = item.symbol === ticker.symbol;
                    return (
                      <button
                        key={item.symbol}
                        onClick={() => {
                          onSelectSymbol(item.symbol);
                          setDropdownOpen(false);
                          setSearchQuery('');
                        }}
                        className={`w-full flex items-center justify-between px-3 py-2 text-left hover:bg-[#161D2E] transition-colors cursor-pointer ${
                          isSelected ? 'bg-[#00F0FF]/10' : ''
                        }`}
                      >
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-mono-tabular font-semibold text-xs text-[#F1F5F9]">
                              {item.symbol}
                            </span>
                            <span className="text-[9px] px-1 py-0.2 rounded bg-[#1E2638] text-[#94A3B8]">
                              {item.category}
                            </span>
                          </div>
                          <span className="text-[11px] text-[#64748B]">{item.name}</span>
                        </div>
                        <span className="text-[11px] font-mono-tabular text-[#00F0FF]">
                          Select →
                        </span>
                      </button>
                    );
                  })}

                  {extraMatches.length > 0 && (
                    <div className="px-3 py-1 bg-[#07090E] text-[10px] font-mono-tabular text-[#64748B] uppercase">
                      All Binance USDT-M Perpetuals ({extraMatches.length}+)
                    </div>
                  )}
                  {extraMatches.map((sym) => (
                    <button
                      key={sym}
                      onClick={() => {
                        onSelectSymbol(sym);
                        setDropdownOpen(false);
                        setSearchQuery('');
                      }}
                      className="w-full flex items-center justify-between px-3 py-1.5 text-left hover:bg-[#161D2E] transition-colors cursor-pointer"
                    >
                      <span className="font-mono-tabular font-medium text-xs text-[#F1F5F9]">
                        {sym}
                      </span>
                      <span className="text-[10px] font-mono-tabular text-[#94A3B8]">
                        USDT-M PERP
                      </span>
                    </button>
                  ))}

                  {filteredCurated.length === 0 && extraMatches.length === 0 && (
                    <div className="p-4 text-center">
                      <p className="text-xs text-[#94A3B8] mb-2">
                        Load custom Binance Futures contract:
                      </p>
                      <button
                        onClick={() => {
                          const formatted = searchQuery.toUpperCase().endsWith('USDT')
                            ? searchQuery.toUpperCase()
                            : `${searchQuery.toUpperCase()}USDT`;
                          onSelectSymbol(formatted);
                          setDropdownOpen(false);
                          setSearchQuery('');
                        }}
                        className="px-3 py-1 bg-[#00F0FF]/20 border border-[#00F0FF]/50 text-[#00F0FF] rounded text-xs font-mono-tabular cursor-pointer"
                      >
                        Load {searchQuery.toUpperCase()}USDT
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Timeframe Selector */}
          <div className="flex items-center bg-[#111622] border border-[#1E2638] rounded p-0.5">
            {TIMEFRAMES.map((tf) => (
              <button
                key={tf}
                onClick={() => onSelectTimeframe(tf)}
                className={`px-2.5 py-1 text-xs font-mono-tabular rounded transition-all cursor-pointer ${
                  timeframe === tf
                    ? 'bg-[#00F0FF] text-[#07090E] font-bold shadow-[0_0_8px_rgba(0,240,255,0.4)]'
                    : 'text-[#94A3B8] hover:text-[#F1F5F9]'
                }`}
              >
                {tf}
              </button>
            ))}
          </div>
        </div>

        {/* Center: High-Density Live Orderflow Telemetry Strip */}
        <div className="flex flex-wrap items-center gap-4 lg:gap-5 overflow-x-auto">
          {/* Last / Mark Price */}
          <div className="flex items-center gap-2">
            <div>
              <div className="text-[10px] uppercase tracking-wider text-[#64748B]">
                Mark Price
              </div>
              <div className="flex items-center gap-1.5">
                <span
                  className={`font-mono-tabular font-bold text-base ${
                    isPositive24h ? 'text-[#00E676]' : 'text-[#FF1744]'
                  }`}
                >
                  ${formatPrice(ticker.lastPrice, ticker.tickSize)}
                </span>
                <span
                  className={`inline-flex items-center gap-0.5 text-[11px] font-mono-tabular px-1.5 py-0.5 rounded ${
                    isPositive24h
                      ? 'bg-[#00E676]/15 text-[#00E676]'
                      : 'bg-[#FF1744]/15 text-[#FF1744]'
                  }`}
                >
                  {isPositive24h ? (
                    <TrendingUp className="w-3 h-3" />
                  ) : (
                    <TrendingDown className="w-3 h-3" />
                  )}
                  {isPositive24h ? '+' : ''}
                  {ticker.priceChangePct24h.toFixed(2)}%
                </span>
              </div>
            </div>
          </div>

          <div className="h-6 w-[1px] bg-[#1E2638] hidden sm:block" />

          {/* Open Interest */}
          <div>
            <div className="text-[10px] uppercase tracking-wider text-[#64748B]">
              Open Interest
            </div>
            <div className="font-mono-tabular text-xs font-semibold text-[#F1F5F9]">
              {ticker.openInterestUSD > 0 ? (
                <>
                  {formatUSD(ticker.openInterestUSD)}{' '}
                  <span className="text-[#64748B] font-normal">
                    ({formatUSD(ticker.openInterestContracts, true).replace('$', '')} {ticker.baseAsset})
                  </span>
                </>
              ) : (
                <span className="text-[#F59E0B]">UNAVAILABLE — TRADE GATE BLOCKED</span>
              )}
            </div>
          </div>

          {/* 24h Volume */}
          <div>
            <div className="text-[10px] uppercase tracking-wider text-[#64748B]">
              24h Futures Vol
            </div>
            <div className="font-mono-tabular text-xs font-semibold text-[#F1F5F9]">
              {formatUSD(ticker.volume24hUSD)}
            </div>
          </div>

          {/* Funding Rate */}
          <div>
            <div className="text-[10px] uppercase tracking-wider text-[#64748B]">
              Funding Rate
            </div>
            <div
              className={`font-mono-tabular text-xs font-semibold ${
                ticker.fundingRate >= 0 ? 'text-[#00E676]' : 'text-[#FF1744]'
              }`}
            >
              {ticker.fundingRate >= 0 ? '+' : ''}
              {(ticker.fundingRate * 100).toFixed(4)}%
            </div>
          </div>

          <div className="h-6 w-[1px] bg-[#1E2638] hidden md:block" />

          {/* Structural Key Levels: POC / VAH / VAL / VWAP */}
          <div className="hidden xl:flex items-center gap-3.5 bg-[#111622] border border-[#1E2638] rounded px-2.5 py-1">
            <div>
              <span className="text-[9px] uppercase tracking-wider text-[#F59E0B] block font-semibold">
                POC (Control)
              </span>
              <span className="font-mono-tabular text-xs font-bold text-[#F59E0B]">
                ${formatPrice(volumeProfile.poc, ticker.tickSize)}
              </span>
            </div>
            <div className="h-5 w-[1px] bg-[#1E2638]" />
            <div>
              <span className="text-[9px] uppercase tracking-wider text-[#A855F7] block font-semibold">
                VAH (70% High)
              </span>
              <span className="font-mono-tabular text-xs font-semibold text-[#E2E8F0]">
                ${formatPrice(volumeProfile.vah, ticker.tickSize)}
              </span>
            </div>
            <div className="h-5 w-[1px] bg-[#1E2638]" />
            <div>
              <span className="text-[9px] uppercase tracking-wider text-[#A855F7] block font-semibold">
                VAL (70% Low)
              </span>
              <span className="font-mono-tabular text-xs font-semibold text-[#E2E8F0]">
                ${formatPrice(volumeProfile.val, ticker.tickSize)}
              </span>
            </div>
            <div className="h-5 w-[1px] bg-[#1E2638]" />
            <div>
              <span className="text-[9px] uppercase tracking-wider text-[#38BDF8] block font-semibold">
                Session VWAP
              </span>
              <span className="font-mono-tabular text-xs font-semibold text-[#38BDF8]">
                ${formatPrice(currentVWAP, ticker.tickSize)}
              </span>
            </div>
            <div className="h-5 w-[1px] bg-[#1E2638]" />
            <div>
              <span className="text-[9px] uppercase tracking-wider text-[#94A3B8] block font-semibold">
                Session CVD
              </span>
              <span
                className={`font-mono-tabular text-xs font-semibold ${
                  currentCVD >= 0 ? 'text-[#00E676]' : 'text-[#FF1744]'
                }`}
              >
                {currentCVD >= 0 ? '+' : ''}
                {formatUSD(currentCVD)}
              </span>
            </div>
          </div>
        </div>

        {/* Right: Feed Status & Manual Sync */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 bg-[#111622] border border-[#1E2638] rounded px-2.5 py-1">
            <span
              className={`w-2 h-2 rounded-full ${
                wsConnected
                  ? 'bg-[#00E676] shadow-[0_0_8px_#00E676] animate-pulse'
                  : 'bg-[#F59E0B]'
              }`}
            />
            <Wifi className="w-3 h-3 text-[#00F0FF]" />
            <span className="text-[10px] font-mono-tabular text-[#94A3B8]">
              {connectionSource === 'BINANCE_FAPI_LIVE'
                ? 'FAPI LIVE'
                : connectionSource === 'BINANCE_VISION_MIRROR'
                ? 'SPOT MIRROR — OI BLOCK'
                : 'SYNTHETIC — NO TRADE'}
            </span>
          </div>

          <button
            onClick={onRefresh}
            disabled={isLoading}
            title="Resync Binance Futures Orderflow Snapshot"
            className="flex items-center gap-1 bg-[#111622] hover:bg-[#1E2638] border border-[#1E2638] rounded px-2.5 py-1 text-xs text-[#94A3B8] hover:text-[#F1F5F9] transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-[#00F0FF]' : ''}`} />
            <span className="hidden sm:inline text-[11px] font-mono-tabular">SYNC</span>
          </button>
        </div>
      </div>

      {/* Compact Secondary Bar for smaller viewports so POC/VAH/VAL/VWAP are always visible */}
      <div className="flex xl:hidden flex-wrap items-center justify-between gap-2 mt-2 pt-1.5 border-t border-[#1E2638]/70 text-[11px] font-mono-tabular">
        <div className="flex flex-wrap items-center gap-3">
          <span>
            <strong className="text-[#F59E0B]">POC:</strong> $
            {formatPrice(volumeProfile.poc, ticker.tickSize)}
          </span>
          <span>
            <strong className="text-[#A855F7]">VAH:</strong> $
            {formatPrice(volumeProfile.vah, ticker.tickSize)}
          </span>
          <span>
            <strong className="text-[#A855F7]">VAL:</strong> $
            {formatPrice(volumeProfile.val, ticker.tickSize)}
          </span>
          <span>
            <strong className="text-[#38BDF8]">VWAP:</strong> $
            {formatPrice(currentVWAP, ticker.tickSize)}
          </span>
          <span>
            <strong className="text-[#94A3B8]">CVD:</strong>{' '}
            <span className={currentCVD >= 0 ? 'text-[#00E676]' : 'text-[#FF1744]'}>
              {currentCVD >= 0 ? '+' : ''}
              {formatUSD(currentCVD)}
            </span>
          </span>
        </div>
        <div className="flex items-center gap-1 text-[10px] text-[#64748B]">
          <Activity className="w-3 h-3 text-[#00F0FF]" />
          <span>70% Value Area Active</span>
        </div>
      </div>
    </header>
  );
};
