import React, { useState } from 'react';
import { Activity, BarChart3, TrendingUp, Flame } from 'lucide-react';
import { KlineOrderflow, OIRegimeAnalysis } from '../types/orderflow';
import { formatUSD } from '../services/orderflowEngine';

interface SynchronizedSubChartsProps {
  klines: KlineOrderflow[];
  oiRegime: OIRegimeAnalysis;
}

export const SynchronizedSubCharts: React.FC<SynchronizedSubChartsProps> = ({
  klines,
  oiRegime,
}) => {
  const [activeView, setActiveView] = useState<'SPLIT' | 'CVD_ONLY' | 'OI_ONLY'>('SPLIT');

  const bars = klines.slice(-44);
  if (bars.length === 0) return null;

  // Compute scales for Delta & CVD
  const maxAbsDelta = Math.max(...bars.map((b) => Math.abs(b.delta)), 1);
  const minCVD = Math.min(...bars.map((b) => b.cvd));
  const maxCVD = Math.max(...bars.map((b) => b.cvd));
  const cvdRange = Math.max(maxCVD - minCVD, 1);

  // Compute scales for Open Interest
  const minOI = Math.min(...bars.map((b) => b.openInterestUSD));
  const maxOI = Math.max(...bars.map((b) => b.openInterestUSD));
  const oiRange = Math.max(maxOI - minOI, 1);
  const maxAbsOIDelta = Math.max(...bars.map((b) => Math.abs(b.oiDeltaUSD)), 1);

  const latest = bars[bars.length - 1];

  // Build SVG Polyline points for CVD
  const cvdPoints = bars
    .map((b, idx) => {
      const x = ((idx + 0.5) / bars.length) * 100;
      const y = 90 - ((b.cvd - minCVD) / cvdRange) * 78;
      return `${x.toFixed(2)},${y.toFixed(2)}`;
    })
    .join(' ');

  // Build SVG Polyline points for OI
  const oiPoints = bars
    .map((b, idx) => {
      const x = ((idx + 0.5) / bars.length) * 100;
      const y = 90 - ((b.openInterestUSD - minOI) / oiRange) * 78;
      return `${x.toFixed(2)},${y.toFixed(2)}`;
    })
    .join(' ');

  return (
    <div className="bg-[#0B0E17] border border-[#1E2638] rounded-sm overflow-hidden">
      {/* Sub-chart Header & Regime Telemetry */}
      <div className="flex flex-wrap items-center justify-between gap-2 px-3 py-1.5 bg-[#111622] border-b border-[#1E2638]">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-[#00F0FF]" />
            <span className="font-display font-bold text-xs uppercase tracking-wider text-[#F1F5F9]">
              CVD, Volume Delta & Open Interest Regime
            </span>
          </div>

          {/* Active Regime Pill */}
          <span
            className={`text-[10px] font-mono-tabular font-semibold px-2 py-0.5 rounded border ${
              oiRegime.regime === 'LONG_BUILD' || oiRegime.regime === 'SHORT_SQUEEZE'
                ? 'bg-[#00E676]/15 border-[#00E676]/40 text-[#00E676]'
                : oiRegime.regime === 'SHORT_BUILD' || oiRegime.regime === 'LONG_LIQUIDATION'
                ? 'bg-[#FF1744]/15 border-[#FF1744]/40 text-[#FF1744]'
                : 'bg-[#1E2638] border-[#334155] text-[#94A3B8]'
            }`}
          >
            {oiRegime.dataAvailable ? oiRegime.regimeLabel : 'OI DATA UNAVAILABLE — SETUP BLOCKED'}
          </span>

          {/* CVD Divergence Pill */}
          {oiRegime.cvdDivergence !== 'NONE' && (
            <span className="hidden md:inline-flex items-center gap-1 text-[10px] font-mono-tabular px-2 py-0.5 rounded bg-[#00F0FF]/15 border border-[#00F0FF]/40 text-[#00F0FF]">
              <Flame className="w-3 h-3" />
              {oiRegime.cvdDivergence.replace('_', ' ')}
            </span>
          )}
        </div>

        {/* Sub-Chart View Switcher */}
        <div className="flex items-center gap-1 bg-[#07090E] p-0.5 rounded border border-[#1E2638] text-[10px] font-mono-tabular">
          <button
            onClick={() => setActiveView('SPLIT')}
            className={`px-2 py-0.5 rounded cursor-pointer ${
              activeView === 'SPLIT'
                ? 'bg-[#00F0FF]/20 text-[#00F0FF] font-semibold'
                : 'text-[#64748B] hover:text-[#94A3B8]'
            }`}
          >
            SPLIT (CVD + OI)
          </button>
          <button
            onClick={() => setActiveView('CVD_ONLY')}
            className={`px-2 py-0.5 rounded cursor-pointer ${
              activeView === 'CVD_ONLY'
                ? 'bg-[#00F0FF]/20 text-[#00F0FF] font-semibold'
                : 'text-[#64748B] hover:text-[#94A3B8]'
            }`}
          >
            CVD & DELTA
          </button>
          <button
            onClick={() => setActiveView('OI_ONLY')}
            className={`px-2 py-0.5 rounded cursor-pointer ${
              activeView === 'OI_ONLY'
                ? 'bg-[#00F0FF]/20 text-[#00F0FF] font-semibold'
                : 'text-[#64748B] hover:text-[#94A3B8]'
            }`}
          >
            OPEN INTEREST
          </button>
        </div>
      </div>

      {/* Charts Container */}
      <div
        className={`grid grid-cols-1 ${
          activeView === 'SPLIT' ? 'lg:grid-cols-2 divide-y lg:divide-y-0 lg:divide-x' : ''
        } divide-[#1E2638] bg-[#07090E]`}
      >
        {/* PANE 1: BAR VOLUME DELTA + CUMULATIVE VOLUME DELTA (CVD) */}
        {(activeView === 'SPLIT' || activeView === 'CVD_ONLY') && (
          <div className="p-2.5 flex flex-col justify-between h-44 relative">
            <div className="flex items-center justify-between text-[11px] font-mono-tabular z-10">
              <div className="flex items-center gap-2">
                <BarChart3 className="w-3.5 h-3.5 text-[#00E676]" />
                <span className="text-[#F1F5F9] font-semibold">CVD & BAR DELTA</span>
                <span className="text-[#64748B]">|</span>
                <span className="text-[#94A3B8]">
                  Session Net Δ:{' '}
                  <strong
                    className={
                      oiRegime.netDeltaSessionUSD >= 0 ? 'text-[#00E676]' : 'text-[#FF1744]'
                    }
                  >
                    {oiRegime.netDeltaSessionUSD >= 0 ? '+' : ''}
                    {formatUSD(oiRegime.netDeltaSessionUSD)}
                  </strong>
                </span>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[#94A3B8]">
                  Taker B/S Ratio:{' '}
                  <strong className="text-[#00F0FF]">{oiRegime.buySellRatio.toFixed(2)}x</strong>
                </span>
              </div>
            </div>

            {/* Interactive SVG Histogram + CVD Line */}
            <div className="relative flex-1 my-1">
              <svg
                viewBox="0 0 100 100"
                preserveAspectRatio="none"
                className="w-full h-full overflow-visible"
              >
                {/* Zero baseline for Delta */}
                <line
                  x1="0"
                  y1="50"
                  x2="100"
                  y2="50"
                  stroke="#1E2638"
                  strokeWidth="0.6"
                  strokeDasharray="1,1"
                />

                {/* Per-Bar Volume Delta Histogram */}
                {bars.map((b, idx) => {
                  const barW = (100 / bars.length) * 0.68;
                  const x = (idx / bars.length) * 100 + (100 / bars.length - barW) / 2;
                  const normH = (Math.abs(b.delta) / maxAbsDelta) * 42;
                  const isPos = b.delta >= 0;
                  const y = isPos ? 50 - normH : 50;
                  return (
                    <rect
                      key={b.time}
                      x={x}
                      y={y}
                      width={barW}
                      height={Math.max(1.5, normH)}
                      fill={isPos ? 'rgba(0, 230, 118, 0.65)' : 'rgba(255, 23, 68, 0.65)'}
                    />
                  );
                })}

                {/* Cumulative Volume Delta (CVD) Smooth Line */}
                <polyline
                  fill="none"
                  stroke="#00F0FF"
                  strokeWidth="1.5"
                  points={cvdPoints}
                />
              </svg>
            </div>

            <div className="flex items-center justify-between text-[10px] font-mono-tabular text-[#64748B] border-t border-[#1E2638]/70 pt-1">
              <span>{oiRegime.divergenceDescription}</span>
              <span className="text-[#00F0FF] font-semibold">
                CVD: {latest.cvd >= 0 ? '+' : ''}
                {formatUSD(latest.cvd)}
              </span>
            </div>
          </div>
        )}

        {/* PANE 2: OPEN INTEREST + OI DELTA REGIME */}
        {(activeView === 'SPLIT' || activeView === 'OI_ONLY') && (
          <div className="p-2.5 flex flex-col justify-between h-44 relative">
            <div className="flex items-center justify-between text-[11px] font-mono-tabular z-10">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-3.5 h-3.5 text-[#A855F7]" />
                <span className="text-[#F1F5F9] font-semibold">OPEN INTEREST & OI DELTA</span>
                <span className="text-[#64748B]">|</span>
                <span className="text-[#94A3B8]">
                  20-Bar OI Δ:{' '}
                  <strong
                    className={oiRegime.oiChangeUSD >= 0 ? 'text-[#00E676]' : 'text-[#FF1744]'}
                  >
                    {oiRegime.oiChangeUSD >= 0 ? '+' : ''}
                    {formatUSD(oiRegime.oiChangeUSD)} ({oiRegime.oiChangePct >= 0 ? '+' : ''}
                    {oiRegime.oiChangePct.toFixed(2)}%)
                  </strong>
                </span>
              </div>

              <span className={`font-semibold ${oiRegime.dataAvailable ? 'text-[#A855F7]' : 'text-[#F59E0B]'}`}>
                {oiRegime.dataAvailable ? `Now: ${formatUSD(latest.openInterestUSD)}` : 'OI feed unavailable'}
              </span>
            </div>

            {/* Interactive SVG OI Delta Bars + OI Curve */}
            <div className="relative flex-1 my-1">
              <svg
                viewBox="0 0 100 100"
                preserveAspectRatio="none"
                className="w-full h-full overflow-visible"
              >
                <line
                  x1="0"
                  y1="55"
                  x2="100"
                  y2="55"
                  stroke="#1E2638"
                  strokeWidth="0.6"
                  strokeDasharray="1,1"
                />

                {/* Per-Bar OI Change Colored by Regime */}
                {bars.map((b, idx) => {
                  const barW = (100 / bars.length) * 0.68;
                  const x = (idx / bars.length) * 100 + (100 / bars.length - barW) / 2;
                  const normH = (Math.abs(b.oiDeltaUSD) / maxAbsOIDelta) * 38;
                  const isOIPos = b.oiDeltaUSD >= 0;
                  const isPriceUp = b.close >= b.open;
                  const y = isOIPos ? 55 - normH : 55;

                  // Color by 4-state derivatives matrix
                  let fill = 'rgba(0, 230, 118, 0.65)'; // Long Build
                  if (isOIPos && !isPriceUp) fill = 'rgba(255, 23, 68, 0.68)'; // Short Build
                  else if (!isOIPos && isPriceUp) fill = 'rgba(0, 240, 255, 0.65)'; // Short Squeeze
                  else if (!isOIPos && !isPriceUp) fill = 'rgba(245, 158, 11, 0.65)'; // Long Liq

                  return (
                    <rect
                      key={b.time}
                      x={x}
                      y={y}
                      width={barW}
                      height={Math.max(1.5, normH)}
                      fill={fill}
                    />
                  );
                })}

                {/* Historical Open Interest Curve */}
                <polyline
                  fill="none"
                  stroke="#A855F7"
                  strokeWidth="1.6"
                  points={oiPoints}
                />
              </svg>
            </div>

            {/* Legend for 4-State OI Regime Matrix */}
            <div className="flex flex-wrap items-center justify-between gap-2 text-[10px] font-mono-tabular text-[#94A3B8] border-t border-[#1E2638]/70 pt-1">
              <div className="flex items-center gap-2.5">
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-xs bg-[#00E676]" />
                  Long Build (P↑ OI↑)
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-xs bg-[#FF1744]" />
                  Short Build (P↓ OI↑)
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-xs bg-[#00F0FF]" />
                  Short Squeeze (P↑ OI↓)
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-xs bg-[#F59E0B]" />
                  Long Liq (P↓ OI↓)
                </span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
