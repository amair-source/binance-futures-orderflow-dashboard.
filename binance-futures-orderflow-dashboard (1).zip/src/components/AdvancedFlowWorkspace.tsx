import React from 'react';
import {
  Flame,
  Activity,
  Sigma,
  Waves,
  Radio,
  ShieldCheck,
  ArrowUpRight,
  ArrowDownRight,
  Database,
} from 'lucide-react';
import {
  GammaExposureData,
  HeatmapAnalysis,
  TapeAnalysis,
  TradeSetup,
  WhaleFlowAnalysis,
} from '../types/orderflow';
import { formatPrice, formatUSD } from '../services/orderflowEngine';

interface AdvancedFlowWorkspaceProps {
  heatmap: HeatmapAnalysis;
  tape: TapeAnalysis;
  whales: WhaleFlowAnalysis;
  gamma: GammaExposureData;
  setup: TradeSetup;
  tickSize: number;
}

export const AdvancedFlowWorkspace: React.FC<AdvancedFlowWorkspaceProps> = ({
  heatmap,
  tape,
  whales,
  gamma,
  setup,
  tickSize,
}) => {
  const heatTotal = heatmap.bidLiquidityUSD + heatmap.askLiquidityUSD || 1;
  const heatBidPct = (heatmap.bidLiquidityUSD / heatTotal) * 100;
  const tapeTotal = tape.buyVolumeUSD + tape.sellVolumeUSD || 1;
  const tapeBuyPct = (tape.buyVolumeUSD / tapeTotal) * 100;
  const whaleTotal = whales.buyVolumeUSD + whales.sellVolumeUSD || 1;
  const whaleBuyPct = (whales.buyVolumeUSD / whaleTotal) * 100;
  const maxGamma = Math.max(
    ...gamma.levels.map((l) => Math.max(Math.abs(l.callGexUSD), Math.abs(l.putGexUSD))),
    1
  );

  const tapeBull =
    tape.state === 'BUYERS_IN_CONTROL' || tape.state === 'BID_ABSORPTION';
  const tapeBear =
    tape.state === 'SELLERS_IN_CONTROL' || tape.state === 'ASK_ABSORPTION';

  return (
    <section className="border border-[#1E2638] rounded-sm bg-[#0B0E17] overflow-hidden">
      <div className="px-3 py-2 bg-[#111622] border-b border-[#1E2638] flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-[#00F0FF]" />
          <div>
            <h2 className="font-display font-bold text-xs uppercase tracking-wider text-[#F1F5F9]">
              Pre-Trade Evidence Matrix
            </h2>
            <p className="text-[10px] text-[#64748B] mt-0.5">
              Heatmap, tape, whales and gamma are scored inputs—not decorative panels.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 font-mono-tabular text-[10px]">
          <span className="px-2 py-1 rounded bg-[#07090E] border border-[#1E2638] text-[#94A3B8]">
            {setup.factorsEvaluated}/11 EVIDENCE GROUPS EVALUATED
          </span>
          <span
            className={`px-2 py-1 rounded border font-bold ${
              setup.status === 'ACTIONABLE'
                ? 'bg-[#00E676]/15 border-[#00E676]/40 text-[#00E676]'
                : 'bg-[#F59E0B]/15 border-[#F59E0B]/40 text-[#F59E0B]'
            }`}
          >
            {setup.status === 'ACTIONABLE' ? 'ALL GATES PASSED' : `${setup.blockedReasons.length} EXECUTION BLOCKS`}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 divide-y lg:divide-y-0 lg:divide-x divide-[#1E2638]">
        {/* HEATMAP LIQUIDITY PERSISTENCE */}
        <div className="p-3 min-w-0">
          <div className="flex items-center justify-between mb-2.5">
            <div className="flex items-center gap-1.5">
              <Flame className="w-4 h-4 text-[#FACC15]" />
              <h3 className="font-display font-bold text-xs uppercase tracking-wide text-[#F1F5F9]">
                Liquidity Heatmap Intelligence
              </h3>
            </div>
            <span className="text-[9px] font-mono-tabular px-1.5 py-0.5 rounded bg-[#FACC15]/15 text-[#FACC15] border border-[#FACC15]/30">
              24-BAR PERSISTENCE
            </span>
          </div>

          <div className="grid grid-cols-3 gap-1.5 mb-2 font-mono-tabular">
            <div className="bg-[#07090E] border border-[#1E2638] rounded p-1.5">
              <span className="text-[9px] text-[#64748B] block">BID LIQUIDITY</span>
              <span className="text-xs font-bold text-[#00E676]">{formatUSD(heatmap.bidLiquidityUSD)}</span>
            </div>
            <div className="bg-[#07090E] border border-[#1E2638] rounded p-1.5">
              <span className="text-[9px] text-[#64748B] block">ASK LIQUIDITY</span>
              <span className="text-xs font-bold text-[#FF1744]">{formatUSD(heatmap.askLiquidityUSD)}</span>
            </div>
            <div className="bg-[#07090E] border border-[#1E2638] rounded p-1.5">
              <span className="text-[9px] text-[#64748B] block">HEAT SKEW</span>
              <span className={`text-xs font-bold ${heatmap.imbalancePct >= 0 ? 'text-[#00E676]' : 'text-[#FF1744]'}`}>
                {heatmap.imbalancePct >= 0 ? '+' : ''}{heatmap.imbalancePct.toFixed(1)}%
              </span>
            </div>
          </div>

          <div className="h-1.5 w-full flex overflow-hidden rounded-xs bg-[#111622] mb-2.5">
            <div className="h-full bg-[#00E676]" style={{ width: `${heatBidPct}%` }} />
            <div className="h-full bg-[#FF1744]" style={{ width: `${100 - heatBidPct}%` }} />
          </div>

          <div className="grid grid-cols-[22px_1fr_58px_54px] gap-1.5 px-1 pb-1 text-[9px] font-mono-tabular text-[#64748B] border-b border-[#1E2638]">
            <span>SIDE</span><span>PRICE / LIQUIDITY</span><span className="text-right">PERSIST</span><span className="text-right">DIST</span>
          </div>
          <div className="space-y-1 mt-1.5 max-h-[176px] overflow-y-auto pr-0.5">
            {heatmap.zones.slice(0, 8).map((zone) => (
              <div key={zone.id} className="grid grid-cols-[22px_1fr_58px_54px] gap-1.5 items-center px-1 py-1 rounded bg-[#07090E] border border-[#1E2638]/70 font-mono-tabular text-[10px]">
                <span className={`font-bold ${zone.side === 'BID' ? 'text-[#00E676]' : 'text-[#FF1744]'}`}>{zone.side}</span>
                <div className="min-w-0">
                  <div className="flex items-center justify-between gap-1">
                    <span className="text-[#E2E8F0] font-semibold">${formatPrice(zone.price, tickSize)}</span>
                    <span className="text-[#94A3B8]">{formatUSD(zone.currentLiquidityUSD)}</span>
                  </div>
                  <div className="h-1 mt-1 rounded-xs bg-[#111622] overflow-hidden">
                    <div
                      className={`h-full ${zone.averageIntensity > 0.75 ? 'bg-[#FACC15]' : zone.side === 'BID' ? 'bg-[#00E676]' : 'bg-[#FF1744]'}`}
                      style={{ width: `${Math.min(100, zone.averageIntensity * 100)}%` }}
                    />
                  </div>
                </div>
                <span className="text-right text-[#00F0FF]">{zone.persistencePct.toFixed(0)}%</span>
                <span className={`text-right ${zone.distancePct >= 0 ? 'text-[#00E676]' : 'text-[#FF1744]'}`}>
                  {zone.distancePct >= 0 ? '+' : ''}{zone.distancePct.toFixed(2)}%
                </span>
              </div>
            ))}
            {heatmap.zones.length === 0 && (
              <div className="py-6 text-center text-xs text-[#64748B]">Building liquidity persistence observations…</div>
            )}
          </div>
          <p className="text-[9px] text-[#64748B] mt-2 leading-snug">{heatmap.modelLabel}. Historical resting liquidity is modeled; current L2 walls are depth-anchored.</p>
        </div>

        {/* TAPE + WHALE INTELLIGENCE */}
        <div className="p-3 min-w-0">
          <div className="flex items-center justify-between mb-2.5">
            <div className="flex items-center gap-1.5">
              <Activity className="w-4 h-4 text-[#00F0FF]" />
              <h3 className="font-display font-bold text-xs uppercase tracking-wide text-[#F1F5F9]">
                Aggressive Tape & Whale Flow
              </h3>
            </div>
            <span className={`text-[9px] font-mono-tabular px-1.5 py-0.5 rounded border ${tapeBull ? 'bg-[#00E676]/15 text-[#00E676] border-[#00E676]/30' : tapeBear ? 'bg-[#FF1744]/15 text-[#FF1744] border-[#FF1744]/30' : 'bg-[#111622] text-[#94A3B8] border-[#1E2638]'}`}>
              {tape.state.replace(/_/g, ' ')}
            </span>
          </div>

          <div className="grid grid-cols-4 gap-1.5 font-mono-tabular mb-2">
            <div className="bg-[#07090E] border border-[#1E2638] rounded p-1.5">
              <span className="text-[9px] text-[#64748B] block">TAPE Δ</span>
              <span className={`text-[11px] font-bold ${tape.netDeltaUSD >= 0 ? 'text-[#00E676]' : 'text-[#FF1744]'}`}>{formatUSD(tape.netDeltaUSD)}</span>
            </div>
            <div className="bg-[#07090E] border border-[#1E2638] rounded p-1.5">
              <span className="text-[9px] text-[#64748B] block">BUY / SELL</span>
              <span className="text-[11px] font-bold text-[#00F0FF]">{tape.buySellRatio.toFixed(2)}x</span>
            </div>
            <div className="bg-[#07090E] border border-[#1E2638] rounded p-1.5">
              <span className="text-[9px] text-[#64748B] block">PRINTS / MIN</span>
              <span className="text-[11px] font-bold text-[#E2E8F0]">{tape.tradesPerMinute.toFixed(0)}</span>
            </div>
            <div className="bg-[#07090E] border border-[#1E2638] rounded p-1.5">
              <span className="text-[9px] text-[#64748B] block">PRICE RESP.</span>
              <span className={`text-[11px] font-bold ${tape.priceChangePct >= 0 ? 'text-[#00E676]' : 'text-[#FF1744]'}`}>{tape.priceChangePct >= 0 ? '+' : ''}{tape.priceChangePct.toFixed(3)}%</span>
            </div>
          </div>

          <div className="flex justify-between text-[9px] font-mono-tabular mb-1">
            <span className="text-[#00E676]">LIFT ASK {formatUSD(tape.buyVolumeUSD)}</span>
            <span className="text-[#FF1744]">HIT BID {formatUSD(tape.sellVolumeUSD)}</span>
          </div>
          <div className="h-1.5 w-full flex overflow-hidden rounded-xs bg-[#111622] mb-1.5">
            <div className="h-full bg-[#00E676]" style={{ width: `${tapeBuyPct}%` }} />
            <div className="h-full bg-[#FF1744]" style={{ width: `${100 - tapeBuyPct}%` }} />
          </div>
          <p className="text-[10px] text-[#94A3B8] mb-2.5">{tape.stateLabel}. {tape.tradeCount} prints analyzed; average {formatUSD(tape.averageTradeUSD)}.</p>

          <div className="border border-[#A855F7]/30 bg-[#A855F7]/5 rounded p-2 mb-2">
            <div className="flex items-center justify-between mb-1.5">
              <span className="flex items-center gap-1.5 text-[10px] font-mono-tabular font-bold text-[#A855F7]">
                <Waves className="w-3.5 h-3.5" /> WHALE FLOW ≥ {formatUSD(whales.thresholdUSD)}
              </span>
              <span className={`text-[10px] font-mono-tabular font-bold ${whales.netDeltaUSD >= 0 ? 'text-[#00E676]' : 'text-[#FF1744]'}`}>
                NET {formatUSD(whales.netDeltaUSD)}
              </span>
            </div>
            <div className="grid grid-cols-3 gap-2 text-[10px] font-mono-tabular mb-1.5">
              <span className="text-[#94A3B8]"><strong className="text-[#00E676]">{whales.buyCount}</strong> buy prints</span>
              <span className="text-[#94A3B8]"><strong className="text-[#FF1744]">{whales.sellCount}</strong> sell prints</span>
              <span className="text-right text-[#94A3B8]"><strong className="text-[#F1F5F9]">{whales.whaleVolumePct.toFixed(1)}%</strong> volume</span>
            </div>
            <div className="h-1.5 w-full flex overflow-hidden rounded-xs bg-[#111622]">
              <div className="h-full bg-[#00E676]" style={{ width: `${whaleBuyPct}%` }} />
              <div className="h-full bg-[#FF1744]" style={{ width: `${100 - whaleBuyPct}%` }} />
            </div>
          </div>

          <div className="space-y-1">
            {whales.topPrints.slice(0, 4).map((trade) => (
              <div key={trade.id} className="grid grid-cols-[70px_1fr_70px_45px] items-center gap-1.5 px-1.5 py-1 rounded bg-[#07090E] border border-[#1E2638]/70 font-mono-tabular text-[10px]">
                <span className={`flex items-center gap-1 font-bold ${trade.isBuyerMaker ? 'text-[#FF1744]' : 'text-[#00E676]'}`}>
                  {trade.isBuyerMaker ? <ArrowDownRight className="w-3 h-3" /> : <ArrowUpRight className="w-3 h-3" />}
                  {trade.isBuyerMaker ? 'SELL' : 'BUY'}
                </span>
                <span className="text-[#E2E8F0]">${formatPrice(trade.price, tickSize)}</span>
                <span className={`text-right font-bold ${trade.notionalUSD >= whales.thresholdUSD ? 'text-[#A855F7]' : 'text-[#94A3B8]'}`}>{formatUSD(trade.notionalUSD)}</span>
                <span className="text-right text-[#64748B]">{new Date(trade.time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
              </div>
            ))}
          </div>
        </div>

        {/* GAMMA EXPOSURE */}
        <div className="p-3 min-w-0">
          <div className="flex items-center justify-between mb-2.5">
            <div className="flex items-center gap-1.5">
              <Sigma className="w-4 h-4 text-[#A855F7]" />
              <h3 className="font-display font-bold text-xs uppercase tracking-wide text-[#F1F5F9]">
                Gamma Exposure & Hedging Walls
              </h3>
            </div>
            <span className={`text-[9px] font-mono-tabular px-1.5 py-0.5 rounded border ${gamma.regime === 'POSITIVE_GAMMA' ? 'bg-[#00E676]/15 text-[#00E676] border-[#00E676]/30' : gamma.regime === 'NEGATIVE_GAMMA' ? 'bg-[#FF1744]/15 text-[#FF1744] border-[#FF1744]/30' : 'bg-[#111622] text-[#94A3B8] border-[#1E2638]'}`}>
              {gamma.regime.replace(/_/g, ' ')}
            </span>
          </div>

          <div className={`flex items-center gap-1.5 px-2 py-1.5 rounded border mb-2 text-[9px] font-mono-tabular ${gamma.isProxy ? 'bg-[#F59E0B]/10 border-[#F59E0B]/30 text-[#F59E0B]' : 'bg-[#00F0FF]/10 border-[#00F0FF]/30 text-[#00F0FF]'}`}>
            {gamma.isProxy ? <Radio className="w-3 h-3 shrink-0" /> : <Database className="w-3 h-3 shrink-0" />}
            <span>{gamma.sourceLabel}</span>
          </div>

          <div className="grid grid-cols-4 gap-1.5 mb-2 font-mono-tabular">
            <div className="col-span-2 bg-[#07090E] border border-[#1E2638] rounded p-1.5">
              <span className="text-[9px] text-[#64748B] block">NET GEX / 1% MOVE</span>
              <span className={`text-xs font-bold ${gamma.netGexUSD >= 0 ? 'text-[#00E676]' : 'text-[#FF1744]'}`}>{formatUSD(gamma.netGexUSD)}</span>
            </div>
            <div className="bg-[#07090E] border border-[#1E2638] rounded p-1.5">
              <span className="text-[9px] text-[#64748B] block">ATM IV</span>
              <span className="text-xs font-bold text-[#F1F5F9]">{gamma.atmIV.toFixed(1)}%</span>
            </div>
            <div className="bg-[#07090E] border border-[#1E2638] rounded p-1.5">
              <span className="text-[9px] text-[#64748B] block">FLIP DIST.</span>
              <span className="text-xs font-bold text-[#00F0FF]">{gamma.spotPrice > 0 ? `${(((gamma.gammaFlip - gamma.spotPrice) / gamma.spotPrice) * 100).toFixed(2)}%` : '—'}</span>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-1.5 mb-2 font-mono-tabular text-[10px]">
            <div className="bg-[#07090E] border border-[#1E2638] rounded p-1.5">
              <span className="text-[9px] text-[#64748B] block">GAMMA FLIP</span>
              <span className="text-[#00F0FF] font-semibold">${formatPrice(gamma.gammaFlip, tickSize)}</span>
            </div>
            <div className="bg-[#07090E] border border-[#1E2638] rounded p-1.5">
              <span className="text-[9px] text-[#64748B] block">CALL WALL</span>
              <span className="text-[#00E676] font-semibold">${formatPrice(gamma.callWall, tickSize)}</span>
            </div>
            <div className="bg-[#07090E] border border-[#1E2638] rounded p-1.5">
              <span className="text-[9px] text-[#64748B] block">PUT WALL</span>
              <span className="text-[#FF1744] font-semibold">${formatPrice(gamma.putWall, tickSize)}</span>
            </div>
          </div>

          <div className="grid grid-cols-[68px_1fr_56px] gap-1.5 px-1 pb-1 text-[9px] font-mono-tabular text-[#64748B] border-b border-[#1E2638]">
            <span>STRIKE</span><span className="text-center">PUT GEX ← 0 → CALL GEX</span><span className="text-right">NET GEX</span>
          </div>
          <div className="space-y-1 mt-1.5 max-h-[150px] overflow-y-auto pr-0.5">
            {gamma.levels.slice(0, 9).map((level) => {
              const callWidth = Math.min(48, (Math.abs(level.callGexUSD) / maxGamma) * 48);
              const putWidth = Math.min(48, (Math.abs(level.putGexUSD) / maxGamma) * 48);
              return (
                <div key={level.strike} className="grid grid-cols-[68px_1fr_56px] gap-1.5 items-center px-1 py-0.5 font-mono-tabular text-[9px]">
                  <span className="text-[#E2E8F0]">${formatPrice(level.strike, tickSize)}</span>
                  <div className="relative h-3 bg-[#07090E] rounded-xs overflow-hidden">
                    <div className="absolute left-1/2 inset-y-0 w-px bg-[#475569]" />
                    <div className="absolute top-0.5 bottom-0.5 bg-[#FF1744]/70" style={{ right: '50%', width: `${putWidth}%` }} />
                    <div className="absolute top-0.5 bottom-0.5 bg-[#00E676]/70" style={{ left: '50%', width: `${callWidth}%` }} />
                  </div>
                  <span className={`text-right font-semibold ${level.netGexUSD >= 0 ? 'text-[#00E676]' : 'text-[#FF1744]'}`}>{formatUSD(level.netGexUSD)}</span>
                </div>
              );
            })}
          </div>
          <p className="text-[9px] text-[#64748B] mt-2 leading-snug">{gamma.description}</p>
        </div>
      </div>
    </section>
  );
};
