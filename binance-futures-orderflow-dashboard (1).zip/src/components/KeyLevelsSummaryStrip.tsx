import React from 'react';
import { Compass } from 'lucide-react';
import {
  VolumeProfileData,
  FibonacciData,
  OrderbookWall,
} from '../types/orderflow';
import { DEFAULT_FUTURES_ASSETS } from '../services/binanceFuturesService';
import { formatPrice, formatUSD } from '../services/orderflowEngine';

interface KeyLevelsSummaryStripProps {
  symbol: string;
  lastPrice: number;
  tickSize: number;
  vwap: number;
  vwapUpper1: number;
  vwapLower1: number;
  volumeProfile: VolumeProfileData;
  fib: FibonacciData;
  walls: OrderbookWall[];
  onSelectSymbol: (sym: string) => void;
}

export const KeyLevelsSummaryStrip: React.FC<KeyLevelsSummaryStripProps> = ({
  symbol,
  lastPrice,
  tickSize,
  vwap,
  vwapUpper1,
  vwapLower1,
  volumeProfile,
  fib,
  walls,
  onSelectSymbol,
}) => {
  const topBidWall = walls.filter((w) => w.side === 'BID')[0];
  const topAskWall = walls.filter((w) => w.side === 'ASK')[0];
  const topIceberg = walls.find((w) => w.type === 'ICEBERG_ABSORPTION');

  const structuredLevels = [
    {
      label: 'VAH (70% Value High)',
      tag: 'VAH',
      price: volumeProfile.vah,
      color: 'text-[#A855F7]',
      badge: 'bg-[#A855F7]/15 text-[#A855F7] border-[#A855F7]/30',
      meta: '70% Vol Upper Bound',
    },
    {
      label: 'POC (Point of Control)',
      tag: 'POC',
      price: volumeProfile.poc,
      color: 'text-[#F59E0B]',
      badge: 'bg-[#F59E0B]/15 text-[#F59E0B] border-[#F59E0B]/40',
      meta: 'Max Session Volume Node',
    },
    {
      label: 'VAL (70% Value Low)',
      tag: 'VAL',
      price: volumeProfile.val,
      color: 'text-[#A855F7]',
      badge: 'bg-[#A855F7]/15 text-[#A855F7] border-[#A855F7]/30',
      meta: '70% Vol Lower Bound',
    },
    {
      label: 'Session VWAP',
      tag: 'VWAP',
      price: vwap,
      color: 'text-[#38BDF8]',
      badge: 'bg-[#38BDF8]/15 text-[#38BDF8] border-[#38BDF8]/40',
      meta: `±1σ: $${formatPrice(vwapLower1, tickSize)}–$${formatPrice(vwapUpper1, tickSize)}`,
    },
    {
      label: 'Fib 0.618 Golden Pocket',
      tag: 'FIB GP',
      price: fib.goldenPocketHigh,
      color: 'text-[#FACC15]',
      badge: 'bg-[#FACC15]/15 text-[#FACC15] border-[#FACC15]/40',
      meta: `${fib.trend} Retracement`,
    },
    {
      label: topAskWall ? 'Primary Ask Limit Wall' : 'Ask Wall Scanner',
      tag: topAskWall ? 'ASK WALL' : 'NO ASK WALL',
      price: topAskWall?.price || lastPrice,
      color: topAskWall ? 'text-[#FF1744]' : 'text-[#64748B]',
      badge: topAskWall
        ? 'bg-[#FF1744]/15 text-[#FF1744] border-[#FF1744]/40'
        : 'bg-[#111622] text-[#64748B] border-[#1E2638]',
      meta: topAskWall
        ? `${formatUSD(topAskWall.sizeUSD)} (${topAskWall.zScore.toFixed(1)}σ)`
        : 'No ≥1.65σ ask wall detected',
    },
    {
      label: topBidWall ? 'Primary Bid Limit Wall' : 'Bid Wall Scanner',
      tag: topBidWall ? 'BID WALL' : 'NO BID WALL',
      price: topBidWall?.price || lastPrice,
      color: topBidWall ? 'text-[#00E676]' : 'text-[#64748B]',
      badge: topBidWall
        ? 'bg-[#00E676]/15 text-[#00E676] border-[#00E676]/40'
        : 'bg-[#111622] text-[#64748B] border-[#1E2638]',
      meta: topBidWall
        ? `${formatUSD(topBidWall.sizeUSD)} (${topBidWall.zScore.toFixed(1)}σ)`
        : 'No ≥1.65σ bid wall detected',
    },
    {
      label: topIceberg ? 'Iceberg Absorption Candidate' : 'Iceberg Absorption Scanner',
      tag: topIceberg ? 'ICEBERG' : 'NO ICE',
      price: topIceberg?.price || lastPrice,
      color: topIceberg ? 'text-[#00F0FF]' : 'text-[#64748B]',
      badge: topIceberg
        ? 'bg-[#00F0FF]/15 text-[#00F0FF] border-[#00F0FF]/40'
        : 'bg-[#111622] text-[#64748B] border-[#1E2638]',
      meta: topIceberg
        ? `Taped ${formatUSD(topIceberg.absorbedUSD)} (${topIceberg.refillCount} prints)`
        : 'No qualified taped absorption',
    },
  ];

  return (
    <div className="bg-[#0B0E17] border border-[#1E2638] rounded-sm overflow-hidden">
      {/* Quick Asset Hotbar */}
      <div className="px-3 py-1.5 bg-[#111622] border-b border-[#1E2638] flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-1.5">
          <Compass className="w-3.5 h-3.5 text-[#00F0FF]" />
          <span className="font-display font-bold text-xs uppercase tracking-wider text-[#F1F5F9]">
            Structured Orderflow Key Levels Matrix
          </span>
        </div>

        <div className="flex items-center gap-1 overflow-x-auto">
          <span className="text-[10px] font-mono-tabular text-[#64748B] mr-1">
            Quick Switch:
          </span>
          {DEFAULT_FUTURES_ASSETS.slice(0, 10).map((asset) => (
            <button
              key={asset.symbol}
              onClick={() => onSelectSymbol(asset.symbol)}
              className={`px-2 py-0.5 rounded text-[10px] font-mono-tabular transition-colors cursor-pointer ${
                symbol === asset.symbol
                  ? 'bg-[#00F0FF] text-[#07090E] font-bold'
                  : 'bg-[#07090E] text-[#94A3B8] hover:text-[#F1F5F9] border border-[#1E2638]'
              }`}
            >
              {asset.baseAsset}
            </button>
          ))}
        </div>
      </div>

      {/* 8-Card Institutional Level Matrix */}
      <div className="grid grid-cols-2 sm:grid-cols-4 xl:grid-cols-8 divide-y sm:divide-y-0 sm:divide-x divide-[#1E2638]">
        {structuredLevels.map((lvl) => {
          const distPct =
            lastPrice > 0 ? ((lvl.price - lastPrice) / lastPrice) * 100 : 0;
          return (
            <div key={lvl.tag} className="p-2.5 bg-[#07090E]/60 hover:bg-[#111622]/70 transition-colors">
              <div className="flex items-center justify-between mb-1">
                <span
                  className={`text-[9px] font-mono-tabular font-bold px-1.5 py-0.2 rounded border ${lvl.badge}`}
                >
                  {lvl.tag}
                </span>
                <span
                  className={`text-[10px] font-mono-tabular font-semibold ${
                    distPct >= 0 ? 'text-[#00E676]' : 'text-[#FF1744]'
                  }`}
                >
                  {distPct >= 0 ? '+' : ''}
                  {distPct.toFixed(2)}%
                </span>
              </div>

              <div className={`font-mono-tabular font-bold text-xs ${lvl.color}`}>
                ${formatPrice(lvl.price, tickSize)}
              </div>

              <div className="text-[10px] text-[#64748B] truncate mt-0.5" title={lvl.meta}>
                {lvl.meta}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
